<?php
/*------------------------------------------------------------------------
# JoomSport Professional 
# ------------------------------------------------------------------------
# BearDev development company 
# Copyright (C) 2011 JoomSport.com. All Rights Reserved.
# @license - http://joomsport.com/news/license.html GNU/GPL
# Websites: http://www.JoomSport.com 
# Technical Support:  Forum - http://joomsport.com/helpdesk/
-------------------------------------------------------------------------*/
defined('_JEXEC') or die('Restricted access');
global $jsConfig;
?>
<div id="jsMatchViewID">
    <div class="jsMatchResultSection">
        <div class="jsMatchHeader clearfix">
            <div class="col-xs-4 col-sm-5">
                <div class="matchdtime row">
                    <?php
                    if ($rows->object->m_date && $rows->object->m_date != '0000-00-00') {
                        echo '<span class="glyphicon glyphicon-calendar"></span>';
                        if (preg_match('/^[0-9]{4}-(0[1-9]|1[0-2])-(0[1-9]|[1-2][0-9]|3[0-1])$/', $rows->object->m_date)) {
                            echo '<span>'. classJsportDate::getDate($rows->object->m_date, $rows->object->m_time) .'</span>';
                        } else {
                            echo '<span>'. $rows->object->m_date .'</span>';
                        }
                    }
                    ?>
                </div>
            </div>
            <div class="col-xs-4 col-sm-2 jscenter">
                <div>
                    <?php
                    if($jsConfig->get('enbl_mdname_on_match')){
                        echo $rows->object->m_name;
                    }
                    ?>
                </div>
            </div>
            <div class="col-xs-4 col-sm-5">
                <div class="matchvenue row">
                    <?php
                    if ($rows->object->m_location || $rows->object->venue_id) {
                        echo '<div><span>'.$rows->getLocation().'</span></div>';
                        echo '<span class="glyphicon glyphicon-map-marker"></span>';
                    }
                    ?>
                </div>
            </div>
        </div>
        <div class="jsMatchResults">
            <?php 
            global $jsConfig;
            $width = $jsConfig->get('set_emblemhgonmatch');
            $match = $rows;
            $partic_home = $match->getParticipantHome();
            $partic_away = $match->getParticipantAway();
            ?>

            <div class="row">
                <div class="jsMatchTeam jsMatchHomeTeam col-xs-6 col-sm-5 col-md-4">
                    <div class="row">
                        <div class="jsMatchEmbl jscenter col-md-5">
                            <?php echo $partic_home ? ($partic_home->getEmblem(true, 0, 'emblInline', $width)) : ''; ?>
                        </div>
                        <div class="jsMatchPartName col-md-7">
                            <div class="row">
                                <span>
                                    <?php echo ($partic_home) ? ($partic_home->getName(true)) : ''; ?>
                                </span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="jsMatchTeam jsMatchAwayTeam col-xs-6 col-sm-5 col-sm-offset-2 col-md-4 col-md-push-4">
                    <div class="row">
                        <div class="jsMatchEmbl jscenter col-md-5 col-md-push-7">
                            <?php echo $partic_away ? ($partic_away->getEmblem(true, 0, 'emblInline', $width)) : ''; ?>
                        </div>
                        <div class="jsMatchPartName col-md-7 col-md-pull-5">
                            <div class="row">
                                <span>
                                    <?php echo ($partic_away) ? ($partic_away->getName(true)) : ''; ?>
                                </span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="jsMatchScore col-xs-12 col-md-4 col-md-pull-4">
                    <?php if ($rows->object->is_extra) {
                        ?>
                        <div class="jsMatchExtraTime">
                            <img src="<?php echo JS_LIVE_ASSETS?>images/extra-t.png" alt="<?php echo classJsportLanguage::get('BLFA_TEAM_WON_ET');?>" title="<?php echo classJsportLanguage::get('BLFA_TEAM_WON_ET');?>" />
                        </div>
                        <?php
                    } ?>
                    <?php echo jsHelper::getScoreBigM($match); ?>
                </div>
            </div>

            <!-- MAPS -->
            <?php
            if (count($rows->lists['maps'])) {
                echo jsHelper::getMap($rows->lists['maps']);
            }
            ?>
        </div>
    </div>
    <div class="jsMatchContentSection clearfix">
        <?php
        $tabs = $rows->getTabs();
        jsHelperTabs::draw($tabs, $rows);
        ?>
    </div>

    <?php if (isset($lists['enbl_comments']) && $lists['enbl_comments']) {
        ?>
        <div>
            <div class="jsMatchStatHeader jscenter">
                <h3>
                    <?php echo classJsportLanguage::get('BLFA_COMMENTS'); ?>
                </h3>
            </div>

            <ul class="comments-box" id="all_comments">
                <?php
                jsHelper::JsCommentBox($lists['usr_comments'], $lists['canDeleteComments']);
                $link = JUri::base().'index.php?option=com_joomsport&controller=users&task=add_comment&format=row&tmpl=component';
                ?>
            </ul>
            <form action="<?php echo $link; ?>" method="POST" id="comForm" name="comForm">
                <div class="post-comment">
                    <textarea class="form-control" rows="3" name="addcomm" id="addcomm"></textarea>
                    <button type="submit" class="btn btn-default" id="submcom">
                        <span>
                            <b><?php echo classJsportLanguage::get('BLFA_POSTCOMMENT'); ?></b>
                        </span>
                    </button>
                    <input type="hidden" name="mid" value="<?php echo $rows->object->id; ?>" />
                </div>
            </form>
        </div>
        <?php
    }
    ?>
</div>