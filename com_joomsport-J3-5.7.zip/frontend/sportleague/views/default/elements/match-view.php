<?php
/*------------------------------------------------------------------------
# JoomSport Professional 
# ------------------------------------------------------------------------
# BearDev development company 
# Copyright (C) 2011 JoomSport.com. All Rights Reserved.
# @license - http://joomsport.com/news/license.html GNU/GPL
# Websites: http://www.JoomSport.com 
# Technical Support:  Forum - http://joomsport.com/helpdesk/
-------------------------------------------------------------------------*/
defined('_JEXEC') or die('Restricted access');

global $jsConfig;
$width = $jsConfig->get('teamlogo_height');
$match = $rows;
$opposite_events = $jsConfig->get('opposite_events');

if ($opposite_events) {
    $opposite_events = json_decode($opposite_events, true);
} else {
    $opposite_events = array();
}

$partic_home = $match->getParticipantHome();
$partic_away = $match->getParticipantAway();
$moptions = json_decode($match->object->options, true);
$jstimeline = json_decode($jsConfig->get('jstimeline',''));

if(isset($moptions['duration'])){
    $jstimeline->duration = $moptions['duration'];
}

require 'match_stat' . DIRECTORY_SEPARATOR . 'h2h_blocks.php';
?>

<div class="table-responsive">
    <?php
    if(isset($jstimeline->tldisplay) && $jstimeline->tldisplay == '1' && isset($jstimeline->duration) && $jstimeline->duration){
        $hmev = json_encode($rows->lists['m_events_home']);
        $awev = json_encode($rows->lists['m_events_away']);

        if(count($rows->lists['m_events_home']) || count(($rows->lists['m_events_away']))){
            ?>
            <div class="jsTimelineMatchDiv">
                <div class="jsMatchStatHeader jscenter">
                    <h3>
                        <?php echo classJsportLanguage::get('BL_PBL_TIMELINE'); ?>
                    </h3>
                </div>
                <div class="jsTimelineStats">
                    <div id="jsTimeLineDivHome"></div>
                    <div id="jsTimeLineDiv">
                        <div class="jsTimeLineDivInner">&nbsp;</div>
                        <div class="jsTimeLineDivInnerResTime"><?php echo $jstimeline->duration;?>'</div>
                    </div>
                    <div id="jsTimeLineDivAway"></div>
                </div>
                <script>
                    var jsLiveEvPath = '<?php echo JS_LIVE_URL_IMAGES_EVENTS;?>';
                    jQuery(document).on("ready", function(){
                        var hm = <?php echo $hmev;?>; 
                        var aw = <?php echo $awev;?>;
                        var duration = parseInt('<?php echo $jstimeline->duration;?>');
                        var stepJSD = jQuery('#jsTimeLineDiv').width()/duration;

                        calcJSTl(stepJSD,hm,aw);

                        jQuery(window).trigger('resize');
                        jQuery(window).resize(function(){
                            jQuery('#jsTimeLineDivHome').html('');
                            jQuery('#jsTimeLineDivAway').html('');
                            var stepJSD = jQuery('#jsTimeLineDiv').width()/duration;
                            calcJSTl(stepJSD,hm,aw);
                        });
                    });
                </script>
            </div>
            <?php
        }
    }
    ?>
    
    <div class="jsPlayerStatMatchDiv">
        <?php require_once 'player_stat' . DIRECTORY_SEPARATOR . 'match-view-player-stat.php'; ?>
    </div>
    
    <?php
    if (count($rows->lists['team_events'])) {
        ?>
        <div class="jsMatchStatMatchDiv">
            <div class="jsMatchStatHeader jscenter">
                <h3>
                    <?php echo classJsportLanguage::get('BLFA_MATCHSTATS'); ?>
                </h3>
            </div>
            <div class="jsTeamStat">
                <div class="jsOverflowHidden">
                    <div class="jstable">
                        <?php
                        for ($intP = 0; $intP < count($rows->lists['team_events']); ++$intP) {
                            $graph_sum = $rows->lists['team_events'][$intP]->home_value + $rows->lists['team_events'][$intP]->away_value;

                            if ($graph_sum) {
                                $graph_home = round(100 * $rows->lists['team_events'][$intP]->home_value / $graph_sum);
                                $graph_away = round(100 * $rows->lists['team_events'][$intP]->away_value / $graph_sum);
                            }
                            ?>
                            <div class="jstable-row jsColTeamEvents">
                                <div class="jstable-cell jsCol5">
                                    <div class="teamEventGraph clearfix">
                                        <div class="teamEventGraphHome" style="width:<?php echo $graph_home?>%">
                                            <span><?php echo $rows->lists['team_events'][$intP]->home_value; ?></span>
                                        </div>
                                    </div>
                                </div>
                                <div class="jstable-cell jsCol6">
                                    <div>
                                        <?php 
                                        echo $rows->lists['team_events'][$intP]->objEvent->getEmblem();
                                        echo '<span>'. $rows->lists['team_events'][$intP]->objEvent->getEventName() .'</span>';
                                        ?>
                                    </div>
                                </div>
                                <div class="jstable-cell jsCol5">
                                    <div class="teamEventGraph clearfix">
                                        <div class="teamEventGraphAway" style="width:<?php echo $graph_away?>%">
                                            <span><?php echo $rows->lists['team_events'][$intP]->away_value; ?></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php
                        }
                        ?>
                    </div>
                </div>
            </div>
        </div>
        <?php
    }
    ?>
    <?php
    if (jsHelper::getADF($rows->lists['ef'])) {
        ?>
        <div class="jsAdditionStatMatchDiv">
            <div class="jsMatchStatHeader jscenter">
                <h3>
                    <?php echo classJsportLanguage::get('BL_EBL_VAL'); ?>
                </h3>
            </div>
            <div class="jsMatchExtraFields">
                <?php
                $ef = $rows->lists['ef'];
                if (count($ef)) {
                    foreach ($ef as $key => $value) {
                        if ($value != null) {
                            echo '<div class="jsExtraField">';
                            echo  '<div class="jsLabelEField">'.$key.'</div>';
                            echo  '<div class="jsValueEField">'.$value.'</div>';
                            echo  '</div>';
                        }
                    }
                }
                ?>
            </div>
        </div>
        <?php
    }
    ?>
</div>