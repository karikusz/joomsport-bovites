<?php
/*------------------------------------------------------------------------
# JoomSport Professional 
# ------------------------------------------------------------------------
# BearDev development company 
# Copyright (C) 2011 JoomSport.com. All Rights Reserved.
# @license - http://joomsport.com/news/license.html GNU/GPL
# Websites: http://www.JoomSport.com 
# Technical Support:  Forum - http://joomsport.com/helpdesk/
-------------------------------------------------------------------------*/
// no direct access
defined('_JEXEC') or die;


$match = $rows;
$partic_home = $match->getParticipantHome();
$partic_away = $match->getParticipantAway();
?>
<?php if($rows->lists['boxscore_home']){?>
<div class="jsDivLineEmbl" style="padding-top:10px;">

    <?php echo $partic_home->getEmblem();?>
    <?php echo jsHelper::nameHTML($partic_home->getName(true));?>

</div>
<div style="padding-top:10px;">
    <?php echo $rows->lists['boxscore_home'];?>
</div>
<?php } ?>
<?php if($rows->lists['boxscore_away']){?>
<div class="jsDivLineEmbl" style="padding-top:10px;">

    <?php echo $partic_away->getEmblem();?>
    <?php echo jsHelper::nameHTML($partic_away->getName(true));?>

</div>
<div style="padding-top:10px;">
    <?php echo $rows->lists['boxscore_away'];?>
</div>
<?php } ?>