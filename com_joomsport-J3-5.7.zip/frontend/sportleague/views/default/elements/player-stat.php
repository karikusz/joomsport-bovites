<?php
/*------------------------------------------------------------------------
# JoomSport Professional 
# ------------------------------------------------------------------------
# BearDev development company 
# Copyright (C) 2011 JoomSport.com. All Rights Reserved.
# @license - http://joomsport.com/news/license.html GNU/GPL
# Websites: http://www.JoomSport.com 
# Technical Support:  Forum - http://joomsport.com/helpdesk/
-------------------------------------------------------------------------*/
defined('_JEXEC') or die('Restricted access');
?>
<div class="table-responsive">
<?php
    if (count($rows->lists['career'])) {
?>
  <table class="table table-striped jsTableCareer">
  <?php
  if (count($rows->lists['career_head'])) {
  ?>
    <thead>
        <tr>
        <?php
        $i = 0;

        foreach($rows->lists['career_head'] as $career) {
          if ($i == 0) {
            echo '<th width="15%">'.$career.'</th>';
          } else if ($i == 1 && !$rows->season_id) {
            echo '<th width="20%">'.$career.'</th>';
          } else {
            echo '<th width="5%">'.$career.'</th>';
          }
          $i++;
        }
        ?>
      </tr>
    </thead>
  <?php
  }
  ?>
  <tbody>
      <?php
        foreach($rows->lists['career'] as $career) {
        ?>
        <tr>
            <?php
            for($intA=0;$intA<count($career);$intA++){
                echo '<td>'.$career[$intA].'</td>';
            }
            ?>
        </tr>    

        <?php
        }
        
    ?>
  </tbody>
</table>
<?php
}
?>
</div>
<?php
if($rows->lists['career_matches']){
?>
<div class="center-block jscenter">
    <h3 class="jsCreerMatchStath3"><?php echo JText::_('BLFA_MATCHSTATBLOCK_TITLE');?></h3>
</div>
<div class="table-responsive">
    <div class="jstable jsMatchDivMain">
        <?php echo $rows->lists['career_matches'];?>
    </div>
</div>
<?php
}

if(isset($rows->lists['boxscore']) && $rows->lists['boxscore']){
    echo '<div class="center-block jscenter">
                    <h3 class="jsCreerMatchStath3">'.  JText::_('BLFA_BOXSCORE').'</h3>
                </div>';
    echo $rows->lists['boxscore'];
}
if(isset($rows->lists['boxscore_matches']) && $rows->lists['boxscore_matches']){
    echo '<div class="center-block jscenter">
                    <h3 class="jsCreerMatchStath3">'.JText::_('BLFA_BOXSCORE_MATCH').'</h3>
                </div>';
    echo $rows->lists['boxscore_matches'];
}
?>