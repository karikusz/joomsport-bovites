<?php
/**
 * WP-JoomSport
 * @author      BearDev
 * @package     JoomSport
 */

?>
<td class="jsMatchDate">
    <?=$match_date;?>
</td>
<td class="jsMatchTeamLogo">
    <?php
    if(is_object($LMpartic)){
        echo ($LMpartic->getEmblem());
    }
?>
</td>
<td class="jsMatchTeamName">
    <?php
    if(is_object($LMpartic)){
        echo  jsHelper::nameHTML($LMpartic->getName(true));
    }
    ?>
</td>
<td class="jsMatchPlayedStatus">
    <?=jsHelper::JsFormViewElement($lMatch, $partic_home->object->id);?>
</td>
<td class="jsMatchPlayedScore">
    <?=jsHelper::getScore($lMatch, '');?>
</td>
<td class="jsMatchPlace">
    <?=$lMatch->opposite?'<i class="fa fa-home" title="Home" aria-hidden="true"></i>':'<i class="fa fa-plane" title="Away" aria-hidden="true"></i>';?>
</td>