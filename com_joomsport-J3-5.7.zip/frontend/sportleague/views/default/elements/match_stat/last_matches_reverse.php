<?php
/**
 * WP-JoomSport
 * @author      BearDev
 * @package     JoomSport
 */

?>
<td class="jsMatchPlace">
    <?=$lMatch->opposite?'<i class="fa fa-home" title="Home" aria-hidden="true"></i>':'<i class="fa fa-plane" title="Away" aria-hidden="true"></i>';?>
</td>
<td class="jsMatchPlayedScore">
    <?=jsHelper::getScore($lMatch, '');?>
</td>
<td class="jsMatchPlayedStatus">
    <?=jsHelper::JsFormViewElement($lMatch, $partic_away->object->id);?>
</td>
<td class="jsMatchTeamName">
    <?php
    if(is_object($LMpartic)){
        echo  jsHelper::nameHTML($LMpartic->getName(true));
    }
?>
</td>
<td class="jsMatchTeamLogo">
    <?php
    if(is_object($LMpartic)){
        echo ($LMpartic->getEmblem());
    }
    ?>
</td>
<td class="jsMatchDate">
    <?=$match_date;?>
</td>


