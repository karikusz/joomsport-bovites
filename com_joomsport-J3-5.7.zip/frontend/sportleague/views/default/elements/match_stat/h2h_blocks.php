<?php
/*------------------------------------------------------------------------
# JoomSport Professional
# ------------------------------------------------------------------------
# BearDev development company
# Copyright (C) 2011 JoomSport.com. All Rights Reserved.
# @license - http://joomsport.com/news/license.html GNU/GPL
# Websites: http://www.JoomSport.com
# Technical Support:  Forum - http://joomsport.com/helpdesk/
-------------------------------------------------------------------------*/
require_once JS_PATH_HELPERS . "js-helper-btw.php";
if(jsHelperBtw::showH2HBlock($rows->object->id)) {
    global $jsConfig;
    $rows->h2h();

// League Analytics

    $optionsHome = jsHelperBtw::getColumnsOptions($rows->season_id, $partic_home->object->id);
    $optionsAway = jsHelperBtw::getColumnsOptions($rows->season_id, $partic_away->object->id);
    $partic_home_short = $partic_home->getName(false, 0, 2);
    $partic_away_short = $partic_away->getName(false, 0, 2);
    $partic_home_middle = $partic_home->getName(false, 0, 1);
    $partic_away_middle = $partic_away->getName(false, 0, 1);
    $matchesPlHome = jsHelperBtw::getPlayedMatches($partic_home->object->id, $rows->season_id);
    $matchesPlAway = jsHelperBtw::getPlayedMatches($partic_away->object->id, $rows->season_id);

    echo '<div class="jsHHMatchDiv table-responsive">';

    if (count($matchesPlHome) || count($matchesPlAway)) {
        echo '<div class="jsHHSeasonAnalytics clearfix">';
        echo '<div class="jsMatchStatHeader jspBlockTitle jscenter"><h3>' . JText::_("BLFA_H2H_SEASON_ANALYTIC") . '</h3><i class="fa fa-chevron-up" aria-hidden="true"></i></div>';
        echo '<div class="jspBlockSection col-xs-12">';
        ?>
        <div class="jsMatchStatTeams visible-xs clearfix">
            <div class="row">
                <?php
                if(jsHelperBtw::showPositionBlock($rows->object->id)) {
                    $teamBtnClass = 'col-xs-4';
                    $positionBtnClass = 'col-xs-4';
                } else {
                    $teamBtnClass = 'col-xs-6';
                    $positionBtnClass = 'jsHHide';
                }
                ?>
                
                <div class="<?php echo $teamBtnClass; ?>">
                    <div class="jstable jsMatchTeam jsMatchStatHome jsactive" data-tab="jsHHMatchHome">
                        <div class="jstable-cell jsMatchTeamLogo">
                            <?php echo $partic_home ? ($partic_home->getEmblem(false, 0, '', $width)) : ''; ?>
                        </div>
                        <div class="jstable-cell jsMatchTeamName">
                            <div>
                                <span>
                                    <?php echo ($partic_home) ? ($partic_home->getName(false)) : ''; ?>
                                </span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="<?php echo $positionBtnClass; ?>">
                    <div class="jsMatchTeam jsMatchTeamPos row" data-tab="jsHHMatchPos">
                        <div>
                            <?php echo JText::_("BLFA_H2H_POSITION"); ?>
                        </div>
                    </div>
                </div>
                <div class="<?php echo $teamBtnClass; ?>">
                    <div class="jstable jsMatchTeam jsMatchStatAway" data-tab="jsHHMatchAway">
                        <div class="jstable-cell jsMatchTeamName">
                            <div>
                                <span>
                                    <?php echo ($partic_away) ? ($partic_away->getName(false)) : ''; ?>
                                </span>
                            </div>
                        </div>
                        <div class="jstable-cell jsMatchTeamLogo">
                            <?php echo $partic_away ? ($partic_away->getEmblem(false, 0, 'emblInline', $width)) : ''; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php
        echo '<div class="jsHomeTeamAnalytics jsTeamAnalytics jsactive col-xs-12 col-sm-5" data-tab="jsHHMatchHome">';
            echo '<div class="centrikLDW jscenter">';
                echo '<div class="centrikLDWinner">';
                    echo '<div class="centrikLDWinnerTitle">';
                        echo '<div class="divTabfade"><a href="javascript:void(0);" class="jsTabActive" onclick="jspTabs(this, 2);">' . JText::_("BLFA_H2H_SEASON_TOTAL") . '</a></div>';
                        echo '<div class="divTabfade"><a href="javascript:void(0);" class="" onclick="jspTabs(this, 1);">' . $partic_home_short . ' ' . JText::_("BLFA_H2H_HOME") . '</a></div>';
                    echo '</div>';
                    echo '<div class="centrikLDWinnerContainer" id="centrikLDWinnerContainer1"  style="display: none;">';
                        echo '<div class="divCntWLD winWLD">' . $optionsHome["winhome_chk"] . '</div>';
                        echo '<div class="divCntWLD drawWLD">' . $optionsHome["drawhome_chk"] . '</div>';
                        echo '<div class="divCntWLD lostWLD">' . $optionsHome["losthome_chk"] . '</div>';
                    echo '</div>';
                    echo '<div class="centrikLDWinnerContainer" id="centrikLDWinnerContainer2">';
                        echo '<div class="divCntWLD winWLD">' . ($optionsHome["winaway_chk"] + $optionsHome["winhome_chk"]) . '</div>';
                        echo '<div class="divCntWLD drawWLD">' . ($optionsHome["drawaway_chk"] + $optionsHome["drawhome_chk"]) . '</div>';
                        echo '<div class="divCntWLD lostWLD">' . ($optionsHome["lostaway_chk"] + $optionsHome["losthome_chk"]) . '</div>';
                    echo '</div>';
                echo '</div>';
            echo '</div>';

            echo '<div class="jspBlockTitleSmall jscenter"><h4>' . JText::_("BLFA_H2H_LAST_MATCHES") . '</h4></div>';

            echo '<table class=" table divLastMatches divLastMatches2">';
            $lastH = $rows->getLastMatchesH();
            for ($intA = 0; $intA < count($lastH); $intA++) {
                $lMatch = $lastH[$intA];
                $m_date = $lMatch->object->m_date;
                if ($lMatch->opposite == 1) {
                    $LMpartic = $lMatch->getParticipantAway();
                } else {
                    $LMpartic = $lMatch->getParticipantHome();
                }

                $match_date = classJsportDate::getDate($m_date, '');
                echo '<tr>';
                require 'last_matches.php';
                echo '</tr>';
            }
            echo '</table>';
            echo '<table class="table divLastMatches divLastMatches1" style="display:none;">';
            $lastH = $rows->getLastMatchesH(1);
            for ($intA = 0; $intA < count($lastH); $intA++) {
                $lMatch = $lastH[$intA];
                $m_date = $lMatch->object->m_date;

                if ($lMatch->opposite == 1) {
                    $LMpartic = $lMatch->getParticipantAway();
                } else {
                    $LMpartic = $lMatch->getParticipantHome();
                }

                $match_date = classJsportDate::getDate($m_date, '');
                echo '<tr>';
                require 'last_matches.php';
                echo '</tr>';
            }
            echo '</table>';
        echo '</div>';

        $position = jsHelperBtw::getPositions($rows->season_id, $partic_home->object->id, $partic_away->object->id);
        $colors = jsHelperBtw::getStandingColors($rows->season_id);
        $placeblockheight = 15;

        echo '<div class="jsTeamPosAnalytics col-xs-12 col-sm-2" data-tab="jsHHMatchPos">';
        if(jsHelperBtw::showPositionBlock($rows->object->id)) {
            echo '<div class="divLeaguePos">';
            echo '<div class="divLeaguePosHT" style="top:' . intval(($position->teamHomePosition * $placeblockheight ) - $placeblockheight) . 'px;">' . $position->teamHomePosition . '</div>';
            echo '<div class="divLeaguePosAT" style="top:' . intval(($position->teamAwayPosition * $placeblockheight ) - $placeblockheight) . 'px;">' . $position->teamAwayPosition . '</div>';

            for ($i = 0; $i < $position->maxPosition; $i++) {
                echo '<div class="posDivelContainer">';
                    echo '<div class="posDivelLeft" ' . (isset($colors[$i + 1]) && $colors[$i + 1] ? ' style="background-color:' . $colors[$i + 1] . '"' : "") . '></div>';
                    echo '<div class="posDivel"></div>';
                //echo '<div class="posDivelRight"></div>';
                echo '</div>';
            }

            echo '</div>';
            echo '<div class="jscenter">' . JText::_("BLFA_H2H_POSITION") . '</div>';
        }
        echo '</div>';
        echo '<div class="jsAwayTeamAnalytics jsTeamAnalytics col-xs-12 col-sm-5" data-tab="jsHHMatchAway">';
        echo '<div class="centrikLDW jscenter">';
            echo '<div class="centrikLDWinner">';
                echo '<div class="centrikLDWinnerTitle">';
                    echo '<div class="divTabfade"><a href="javascript:void(0);" class="jsTabActive" onclick="jspTabs(this, 4);">' . JText::_("BLFA_H2H_SEASON_TOTAL") . '</a></div>';
                    echo '<div class="divTabfade"><a href="javascript:void(0);" class="" onclick="jspTabs(this, 3);">' . $partic_away_short . ' ' . JText::_("BLFA_H2H_AWAY") . '</a></div>';
                echo '</div>';
                echo '<div class="centrikLDWinnerContainer" id="centrikLDWinnerContainer3"  style="display: none;">';
                    echo '<div class="divCntWLD winWLD">' . $optionsAway["winaway_chk"] . '</div>';
                    echo '<div class="divCntWLD drawWLD">' . $optionsAway["drawaway_chk"] . '</div>';
                    echo '<div class="divCntWLD lostWLD">' . $optionsAway["lostaway_chk"] . '</div>';
                echo '</div>';
                echo '<div class="centrikLDWinnerContainer" id="centrikLDWinnerContainer4">';
                    echo '<div class="divCntWLD winWLD">' . ($optionsAway["winaway_chk"] + $optionsAway["winhome_chk"]) . '</div>';
                    echo '<div class="divCntWLD drawWLD">' . ($optionsAway["drawaway_chk"] + $optionsAway["drawhome_chk"]) . '</div>';
                    echo '<div class="divCntWLD lostWLD">' . ($optionsAway["lostaway_chk"] + $optionsAway["losthome_chk"]) . '</div>';
                echo '</div>';
            echo '</div>';
        echo '</div>';

        echo '<div class="jspBlockTitleSmall jscenter"><h4>' . JText::_("BLFA_H2H_LAST_MATCHES") . '</h4></div>';

        echo '<table class="table divLastMatches divLastMatches4">';
        $lastA = $rows->getLastMatchesA();
        for ($intA = 0; $intA < count($lastA); $intA++) {
            $lMatch = $lastA[$intA];
            $m_date = $lMatch->object->m_date;

            if ($lMatch->opposite == 1) {
                $LMpartic = $lMatch->getParticipantAway();
            } else {
                $LMpartic = $lMatch->getParticipantHome();
            }

            $match_date = classJsportDate::getDate($m_date, '');
            echo '<tr>';
            require 'last_matches_reverse.php';
            echo '</tr>';
        }
        echo '</table>';
        $lastA = $rows->getLastMatchesA(2);
        echo '<table class="table divLastMatches divLastMatches3" style="display: none;">';

        for ($intA = 0; $intA < count($lastA); $intA++) {
            $lMatch = $lastA[$intA];
            $m_date = $lMatch->object->m_date;

            if ($lMatch->opposite == 1) {
                $LMpartic = $lMatch->getParticipantAway();
            } else {
                $LMpartic = $lMatch->getParticipantHome();
            }

            $match_date = classJsportDate::getDate($m_date, '');
            echo '<tr>';
            require 'last_matches_reverse.php';
            echo '</tr>';
        }
        echo '</table>';
        echo '</div>';
        echo '</div>';
        echo '</div>';
    }

    $matchesPlHome = jsHelperBtw::getPlayedMatches($partic_home->object->id, $rows->season_id);
    $matchesPlAway = jsHelperBtw::getPlayedMatches($partic_away->object->id, $rows->season_id);

    if (count($matchesPlHome) || count($matchesPlAway)) {
        echo '<div class="jsHHAvrgAnalytics clearfix">';
        echo '<div class="jsMatchStatHeader jspBlockTitle jscenter"><h3>' . JText::_("BLFA_H2H_AVG_ANALYTICS") . '</h3><i class="fa fa-chevron-up" aria-hidden="true"></i></div>';
        echo '<div class="clearfix">';
        echo '<div class="centrikLDW jscenter">';
        echo '<div class="centrikLDWinnerTitle">';
        echo '<div class="divTabfade"><a href="javascript:void(0);" class="jsTabActive" onclick="jspTabsMajor(this, 1);">' . JText::_("BLFA_H2H_SEASON_TOTAL") . '</a></div>';
        echo '<div class="divTabfade"><a href="javascript:void(0);" class="" onclick="jspTabsMajor(this, 2);">' . $partic_home_short . ' '. JText::_("BLFA_H2H_HOME") . ' / ' . $partic_away_short . ' '. JText::_("BLFA_H2H_AWAY") . '</a></div>';
        echo '</div>';
        echo '</div>';


        $matchesIDSHome = jsHelper::getPostsAsArray($matchesPlHome);
        $evsHome = jsHelperBtw::getTeamStat($partic_home->object->id, $rows->season_id, $matchesIDSHome);

        $matchesIDSAway = jsHelper::getPostsAsArray($matchesPlAway);
        $evsAway = jsHelperBtw::getTeamStat($partic_away->object->id, $rows->season_id, $matchesIDSAway);

        $matchesPlHomePlace = jsHelperBtw::getPlayedMatches($partic_home->object->id, $rows->season_id, 1);
        $matchesIDSHomePlace = jsHelper::getPostsAsArray($matchesPlHomePlace);
        $evsHomePlace = jsHelperBtw::getTeamStat($partic_home->object->id, $rows->season_id, $matchesIDSHome);

        $matchesPlAwayPlace = jsHelperBtw::getPlayedMatches($partic_away->object->id, $rows->season_id, 2);
        $matchesIDSAwayPlace = jsHelper::getPostsAsArray($matchesPlAwayPlace);
        $evsAwayPlace = jsHelperBtw::getTeamStat($partic_away->object->id, $rows->season_id, $matchesIDSAwayPlace);

        $avgevents_events = $jsConfig->get('avgevents_events')?$jsConfig->get('avgevents_events'):array();

        if ($avgevents_events) {
            $avgevents_events = json_decode($avgevents_events, true);
        }
        echo '<div class="jsAnalyticBlock col-xs-12 clearfix">';
        echo '<div class="jspBlockSection clearfix">';
        echo '<div class="jsEventsAnalytic col-xs-6 col-sm-5">';
        echo '<table class="table evTblforTabs evTbl1">';

        if (count($avgevents_events)) {
            foreach ($avgevents_events as $ev) {
                echo '<tr>';
                $objEvent = new classJsportEvent($ev);

                if (isset($evsHome[$ev]) || isset($evsAway[$ev])) {
                    echo '<td>' . (isset($evsHome[$ev])?round($evsHome[$ev]["cnt"] / count($matchesIDSHome), 1):"0"). '</td>';
                    echo '<td class="jsEventType">' . $objEvent->getEmblem(false) . '</td>';
                    echo '<td>' . (isset($evsAway[$ev])?round($evsAway[$ev]["cnt"] / count($matchesIDSAway), 1):"0") . '</td>';
                }

                echo '</tr>';
            }
        }
        echo '</table>';
        echo '<table class="table evTblforTabs evTbl2" style="display:none;">';
        if (count($avgevents_events)) {
            foreach ($avgevents_events as $ev) {
                echo '<tr>';
                $objEvent = new classJsportEvent($ev);

                if (isset($evsHomePlace[$ev]) && isset($evsAwayPlace[$ev])) {
                    echo '<td>' . (isset($evsHomePlace[$ev])?round($evsHomePlace[$ev]["cnt"] / count($matchesIDSHomePlace), 1):"0") . '</td>';
                    echo '<td class="jsEventType">' . $objEvent->getEmblem(false) . '</td>';
                    echo '<td>' . (isset($evsAwayPlace[$ev])?round($evsAwayPlace[$ev]["cnt"] / count($matchesIDSAwayPlace), 1):"0") . '</td>';
                }

                echo '</tr>';
            }
        }
        echo '</table>';
        echo '</div>';

        $hmGoals = jsHelperBtw::getTeamGoals($partic_home->object->id, $matchesIDSHome);
        $awGoals = jsHelperBtw::getTeamGoals($partic_away->object->id, $matchesIDSAway);

        $hmGoalsPlace = jsHelperBtw::getTeamGoals($partic_home->object->id, $matchesIDSHomePlace);
        $awGoalsPlace = jsHelperBtw::getTeamGoals($partic_away->object->id, $matchesIDSAwayPlace);
        echo '<div class="jsGoalsAnalytic col-xs-6 col-sm-5 col-sm-offset-2">';
            echo '<table class="evTblforTabs evTbl1">';
                $scoredH = round($hmGoals["scored"] / count($matchesIDSHome), 1);
                $concH = round($hmGoals["conceeded"] / count($matchesIDSHome), 1);
                $scoredA = round($awGoals["scored"] / count($matchesIDSAway), 1);
                $concA = round($awGoals["conceeded"] / count($matchesIDSAway), 1);
                $homeTeamSum = $scoredH + $concH;
                $awayTeamSum = $scoredA + $concA;

                $maxVal = $homeTeamSum > $awayTeamSum?$homeTeamSum:$awayTeamSum;

                $pxGraphStep = $maxVal ? round(100 / $maxVal) : 0;

                echo '<tr>';
                    echo '<td class="jsVertHead"><span>' . JText::_("BLFA_H2H_GOALS_SC") . '</span></td>';
                    echo '<td class="jsHomeScoreAnalytic tdValignBottom">' . $scoredH . '<div style="height:'.round($pxGraphStep*$scoredH).'px;" class="avgGoalBar"></div></td>';
                    echo '<td class="jsAwayScoreAnalytic tdValignBottom">' . $scoredA . '<div style="height:'.round($pxGraphStep*$scoredA).'px;" class="avgGoalBar"></div></td>';
                echo '</tr>';
                echo '<tr>';
                    echo '<td class="jsVertHead"><span>' . JText::_("BLFA_H2H_GOALS_CS") . '</span></td>';
                    echo '<td class="jsHomeScoreAnalytic tdValignTop"><div style="height:'.round($pxGraphStep*$concH).'px;" class="avgGoalBar"></div>' . $concH . '</td>';
                    echo '<td class="jsAwayScoreAnalytic tdValignTop"><div style="height:'.round($pxGraphStep*$concA).'px;" class="avgGoalBar"></div>' . $concA . '</td>';
                echo '</tr>';
                echo '<tr>';
                    echo '<td class="tdAvgTotal">' . JText::_("BLFA_H2H_TOTAL") . '</td>';
                    echo '<td class="tdAvgTotal">'.$homeTeamSum.'</td>';
                    echo '<td class="tdAvgTotal">'.$awayTeamSum.'</td>';
                echo '</tr>';
            echo '</table>';
            echo '<table class="evTblforTabs evTbl2" style="display: none;">';
                $scoredH = round($hmGoalsPlace["scored"] / count($matchesIDSHomePlace), 1);
                $concH = round($hmGoalsPlace["conceeded"] / count($matchesIDSHomePlace), 1);
                $scoredA = round($awGoalsPlace["scored"] / count($matchesIDSAwayPlace), 1);
                $concA = round($awGoalsPlace["conceeded"] / count($matchesIDSAwayPlace), 1);
                $homeTeamSum = $scoredH + $concH;
                $awayTeamSum = $scoredA + $concA;

                $maxVal = $homeTeamSum > $awayTeamSum?$homeTeamSum:$awayTeamSum;

                $pxGraphStep = $maxVal ? round(100 / $maxVal) : 0;
                echo '<tr>';
                    echo '<td class="jsVertHead"><span>' . JText::_("BLFA_H2H_GOALS_SC") . '</span></td>';
                    echo '<td class="jsHomeScoreAnalytic tdValignBottom">' . $scoredH . '<div style="height:'.round($pxGraphStep*$scoredH).'px;" class="avgGoalBar"></div></td>';
                    echo '<td class="jsAwayScoreAnalytic tdValignBottom">' . $scoredA . '<div style="height:'.round($pxGraphStep*$scoredA).'px;" class="avgGoalBar"></div></td>';
                echo '</tr>';
                echo '<tr>';
                    echo '<td class="jsVertHead"><span>' . JText::_("BLFA_H2H_GOALS_CS") . '</span></td>';
                    echo '<td class="jsHomeScoreAnalytic tdValignTop"><div style="height:'.round($pxGraphStep*$concH).'px;" class="avgGoalBar"></div>' . $concH . '</td>';
                    echo '<td class="jsAwayScoreAnalytic tdValignTop"><div style="height:'.round($pxGraphStep*$concA).'px;" class="avgGoalBar"></div>' . $concA . '</td>';
                echo '</tr>';
                echo '<tr>';
                    echo '<td class="tdAvgTotal">' . JText::_("BLFA_H2H_TOTAL") . '</td>';
                    echo '<td class="tdAvgTotal">'.$homeTeamSum.'</td>';
                    echo '<td class="tdAvgTotal">'.$awayTeamSum.'</td>';
                echo '</tr>';
            echo '</table>';
        echo '</div>';
        echo '</div>';
        echo '</div>';
        echo '</div>';
        echo '</div>';
    }

    if (count($rows->lists["btwMatchesAll"])) {

        $btwWin = $btwDraw = $btwLost = 0;
        for ($intA = 0; $intA < count($rows->lists["btwMatchesAll"]); $intA++) {
            $mtch = $rows->lists["btwMatchesAll"][$intA];
            $home_score = $mtch->score1;
            $away_score = $mtch->score2;
            $home_team = $mtch->team1_id;
            $away_team = $mtch->team2_id;
            if ($home_score != '' && $home_score == $away_score) {
                $btwDraw++;
            }elseif($home_score != ''){

                if (($home_team == $partic_home->object->id && $home_score > $away_score)
                    || ($away_team == $partic_home->object->id && $home_score < $away_score)) {

                    $btwWin++;
                } else {
                    $btwLost++;
                }
            }
        }

        $ovr = $btwWin + $btwDraw + $btwLost;

        if($ovr){
            $homeWin = round(($btwWin*360) / $ovr);
            $awayWin = round(($btwLost*360) / $ovr);
        }else{
            $homeWinLocal = $awayWinLocal = 0;
        }

        //h/a
        $btwWinLocal = $btwDrawLocal = $btwLostLocal = 0;
        for ($intA = 0; $intA < count($rows->lists["btwMatchesLocal"]); $intA++) {
            $mtch = $rows->lists["btwMatchesLocal"][$intA];
            $home_score = $mtch->score1;
            $away_score = $mtch->score2;
            $home_team = $mtch->team1_id;
            $away_team = $mtch->team2_id;
            if ($home_score != '' && $home_score == $away_score) {
                $btwDrawLocal++;
            }elseif($home_score != ''){
                if (($home_team == $partic_home->object->id && $home_score > $away_score)
                    || ($away_team == $partic_home->object->id && $home_score < $away_score)) {
                    $btwWinLocal++;
                } else {
                    $btwLostLocal++;
                }
            }

        }
        $ovr2 = $btwWinLocal + $btwDrawLocal + $btwLostLocal;
        if($ovr2){
            $homeWinLocal = round(($btwWinLocal*360) / $ovr2);
            $awayWinLocal = round(($btwLostLocal*360) / $ovr2);
        }else{
            $homeWinLocal = $awayWinLocal = 0;
        }

        echo '<div class="jsHHAnalytics clearfix">';
        echo '<div class="jsMatchStatHeader jspBlockTitle jscenter"><h3>' . JText::_("BLFA_H2H_ANALYTICS") . '</h3><i class="fa fa-chevron-up" aria-hidden="true"></i></div>';
        echo '<div class="jspBlockSection clearfix">';
        ?>
        <script>
            jQuery(document).ready(function() {
                jspDrowPie('jspCircle1', <?=$awayWin?>, <?=$homeWin?>);
            });
            jQuery(document).ready(function() {
                jspDrowPie('jspCircle2', <?=$awayWinLocal?>, <?=$homeWinLocal?>);
            });
        </script>

        <?php

        echo '<div class="centrikLDW jscenter">';
        echo '<div class="centrikLDWinnerTitle">';
        echo '<div class="divTabfade"><a href="javascript:void(0);" class="jsTabActive" onclick="jspTabsMajor(this, 3);">' . JText::_("BLFA_H2H_TOTAL") . '</a></div>';
        echo '<div class="divTabfade"><a href="javascript:void(0);" class="" onclick="jspTabsMajor(this, 4);">' . $partic_home_short . ' '. JText::_("BLFA_H2H_HOME") . ' / ' . $partic_away_short . ' '. JText::_("BLFA_H2H_AWAY") . '</a></div>';
        echo '</div>';
        echo '</div>';
        echo '<div class="jsHHBlock col-xs-12">';
        echo '<div class="col-xs-12 col-sm-6 jsHHPercentage">';
        echo '<table class="evTblforTabs evTbl3">';
        echo '<tr>';
        echo '<td>';
        if($ovr) {
            echo '<div class="circleHmWinText"><div><span class="jsTeamName">' . $partic_home_middle . '</span></div><span>' . JText::_("BLFA_H2H_WINS") . ' ' . $btwWin . '</span></div>';
            echo '<div class=\'circle\' id="jspCircle1">';
            echo '<div class="circleInnerDraw">' . $btwDraw . ' ' . JText::_("BLFA_H2H_DRAWS").'</div>';
            echo '</div>';
            echo '<div class="circleHmWinText"><div><span class="jsTeamName">' . $partic_away_middle . '</span></div><span>' . JText::_("BLFA_H2H_WINS") . ' ' . $btwLost . '</span></div>';
        }
        echo '</td>';
        echo '</tr>';
        echo '</table>';

        echo '<table class="evTblforTabs evTbl4" style="display: none;">';
        echo '<tr>';
        echo '<td>';

        if($ovr2) {
            echo '<div class="circleHmWinText"><div><span class="jsTeamName">' . $partic_home_middle . '</span></div><span>' . JText::_("BLFA_H2H_WINS") . ' ' . $btwWinLocal . '</span></div>';
            echo '<div class=\'circle\' id="jspCircle2">';
            echo '<div class="circleInnerDraw">' . $btwDrawLocal. ' ' . JText::_("BLFA_H2H_DRAWS").'</div>';
            echo '</div>';
            echo '<div class="circleHmWinText"><div><span class="jsTeamName">' . $partic_away_middle . '</span></div><span>' . JText::_("BLFA_H2H_WINS") . ' ' . $btwLostLocal . '</span></div>';
        }

        echo '</td>';
        echo '</tr>';
        echo '</table>';
        echo '</div>';

        echo '<div class="col-xs-12 col-sm-6 jsHHMatches">';
        echo '<table class="table evTblforTabs evTbl3">';

        $cnt = count($rows->lists["btwMatchesAll"]) > JSCONF_H2H_MAX_MATCH ? JSCONF_H2H_MAX_MATCH : count($rows->lists["btwMatchesAll"]);
        $prev_seasonid = 0;
        for ($i = 0; $i < $cnt; $i++) {
            $match = new classJsportMatch($rows->lists["btwMatchesAll"][$i]->id, false);
            $matchOBJ = $match->getRowSimple();

            $m_date = $rows->lists["btwMatchesAll"][$i]->m_date;
            $match_date = classJsportDate::getDate($m_date, '');
            $btwParticHome = $matchOBJ->getParticipantHome();
            $btwParticAway = $matchOBJ->getParticipantAway();


            $season_id = jsHelperBtw::getMatchSeason($rows->lists["btwMatchesAll"][$i]->id);
            $name = jsHelperBtw::getSeasonName($season_id);

            if ($prev_seasonid != $season_id) {
                echo '<tr class="jsSeasonName"><td colspan="4" class="jscenter">' . $name . '</td></tr>';
                $prev_seasonid = $season_id;
            }

            ?>
            <tr>
                <td class="jsMatchDate">
                    <?= $match_date; ?>
                </td>
                <td class="jsMatchTeam jsHomeTeam">
                    <?php
                    if (is_object($btwParticHome)) {
                        echo($btwParticHome->getEmblem());
                    }

                    if (is_object($btwParticHome)) {
                        echo '<div class="jsMatchTeamName">';
                        echo jsHelper::nameHTML($btwParticHome->getName(true));
                        echo '</div>';
                    }
                    ?>
                </td>
                <td class="jsMatchPlayedScore">
                    <?= jsHelper::getScore($matchOBJ, ''); ?>
                </td>
                <td class="jsMatchTeam jsAwayTeam">
                    <?php
                    if (is_object($btwParticAway)) {
                        echo($btwParticAway->getEmblem());
                    }

                    if (is_object($btwParticAway)) {
                        echo '<div class="jsMatchTeamName">';
                        echo jsHelper::nameHTML($btwParticAway->getName(true));
                        echo '</div>';
                    }
                    ?>
                </td>
            </tr>
            <?php
        }
        echo '</table>';

        echo '<table class="table evTblforTabs evTbl4" style="display: none;">';
        $cnt = count($rows->lists["btwMatchesLocal"]) > JSCONF_H2H_MAX_MATCH ? JSCONF_H2H_MAX_MATCH : count($rows->lists["btwMatchesLocal"]);
        $prev_seasonid = 0;
        for ($i = 0; $i < $cnt; $i++) {
            $match = new classJsportMatch($rows->lists["btwMatchesLocal"][$i]->id, false);
            $matchOBJ = $match->getRowSimple();

            $m_date = $rows->lists["btwMatchesLocal"][$i]->m_date;
            $match_date = classJsportDate::getDate($m_date, '');
            $btwParticHome = $matchOBJ->getParticipantHome();
            $btwParticAway = $matchOBJ->getParticipantAway();

            $season_id = jsHelperBtw::getMatchSeason($rows->lists["btwMatchesLocal"][$i]->id);
            $name = jsHelperBtw::getSeasonName($season_id);

            if ($prev_seasonid != $season_id) {
                echo '<tr class="jsSeasonName"><td colspan="4" class="jscenter">' . $name . '</td></tr>';
                $prev_seasonid = $season_id;
            }
            ?>
            <tr>
                <td class="jsMatchDate">
                    <?= $match_date; ?>
                </td>
                <td class="jsMatchTeam jsHomeTeam">
                    <?php
                    if (is_object($btwParticHome)) {
                        echo($btwParticHome->getEmblem());
                    }

                    if (is_object($btwParticHome)) {
                        echo '<div class="jsMatchTeamName">';
                        echo jsHelper::nameHTML($btwParticHome->getName(true));
                        echo '</div>';
                    }
                    ?>
                </td>
                <td class="jsMatchPlayedScore">
                    <?= jsHelper::getScore($matchOBJ, ''); ?>
                </td>
                <td class="jsMatchTeam jsAwayTeam">
                    <?php
                    if (is_object($btwParticAway)) {
                        echo($btwParticAway->getEmblem());
                    }

                    if (is_object($btwParticAway)) {
                        echo '<div class="jsMatchTeamName">';
                        echo jsHelper::nameHTML($btwParticAway->getName(true));
                        echo '</div>';
                    }
                    ?>
                </td>
            </tr>
            <?php
        }
        echo '</table>';
        echo '</div>';
        echo '</div>';
        echo '</div>';
        echo '</div>';
    }
    echo '</div>';
}
/*<!--/jsonlyinproPHP-->*/

