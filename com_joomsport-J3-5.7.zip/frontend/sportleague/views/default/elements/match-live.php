<?php
/*------------------------------------------------------------------------
# JoomSport Professional 
# ------------------------------------------------------------------------
# BearDev development company 
# Copyright (C) 2011 JoomSport.com. All Rights Reserved.
# @license - http://joomsport.com/news/license.html GNU/GPL
# Websites: http://www.JoomSport.com 
# Technical Support:  Forum - http://joomsport.com/helpdesk/
-------------------------------------------------------------------------*/
defined('_JEXEC') or die('Restricted access');
$sObj = new modelJsportSeason($rows->season_id);
$single = $sObj->getSingle();

?>
<div class="table-responsive">
    <?php
    $editor = JFactory::getConfig()->get('editor');
    $editor = JEditor::getInstance($editor);

    if(jsHelper::isSeasonAdmin($rows->object->id)){?>
    <div class="jsrespdiv12">
        <div class="jsrespdiv6">
            <div class="jsBepanel">
                <div class="jsBEheader">
                    <?php echo JText::_("BLFA_HEAD_TIMER");?>     
                </div>
                <div class="jsBEsettings">
                    <div class="form-horizontal">
                        <div class="form-group">
                            <label class="control-label col-sm-5" for="jslive_time"><?php echo JText::_("BLFA_LIVE_TIMETICKER");?></label>
                            <div class="col-sm-7">
                                <div class="input-group">
                                    <input class="form-control" type="text" name="jslive_time" id="jslive_time" value="0" />
                                    <span class="input-group-btn">
                                        <i id="js_live_ticker_stop" class="fa fa-pause btn btn-default" aria-hidden="true"></i>
                                        <i id="js_live_ticker_start" class="fa fa-play btn btn-default" aria-hidden="true"></i>
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>   
                </div>
            </div>          
        </div>
        <div class="jsrespdiv6 jsrespmarginleft2">
            <div class="jsBepanel">
                <div class="jsBEheader">
                    <?php echo JText::_("BLFA_HEAD_GENERAL");?>             
                </div>
                <div class="jsBEsettings">
                    <div class="form-horizontal">
                        <div class="form-group">
                            <label class="control-label col-sm-5" for="match_status"><?php echo JText::_("BLFA_LIVE_STATUS");?></label>
                            <div class="col-sm-7">
                                <?php echo jsHelper::getMatchStatuses($rows->object->m_played,"match_status");?>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-sm-5" for="jslive_match_duration"><?php echo JText::_("BLFA_LIVE_MATCH_DURATION");?></label>
                            <div class="col-sm-7">          
                                <?php
                                $duration_value = 0;

                                if($rows->object->options){
                                    $json = json_decode($rows->object->options, true);
                                    $duration_value = (isset($json["duration"]))?intval($json["duration"]):0; }?>
                                    <input class="form-control" type="number"  id="jslive_match_duration" name="jslive_match_duration" value="<?php echo $duration_value;?>" />
                                </div>
                            </div>
                            <div class="form-group clearfix">        
                                <div class="col-xs-12">
                                    <button type="button" id="js_save_live_general" class="btn btn-success pull-right"><?php echo JText::_("BLFA_SAVE");?></button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>    
            </div>
        </div>
        <div class="jsrespdiv12">
            <div class="jsBepanel">
                <div class="jsBEheader">
                    <?php echo JText::_("BLFA_HEAD_SCORE");?>
                </div>
                <div class="jsBEsettings">
                    <form action="" method="post" name="jsScoreForm" id="jsScoreForm" class="form-horizontal">
                        <div class="form-group">
                            <label class="control-label col-sm-2"><?php echo JText::_("BLFA_SCORE");?></label>
                            <div class="col-sm-10">
                                <div class="form-inline"> 
                                    <label class="js_homeTeam" for="js_live_score1"><?php echo ($partic_home) ? ($partic_home->getName(false)) : '';?></label>
                                    <input class="form-control" type="number" name="js_live_score1" value="<?php echo ($rows->object->score1);?>" />
                                    <input class="form-control" type="number" name="js_live_score2" value="<?php echo ($rows->object->score2);?>" />
                                    <label class="js_awayTeam" for="js_live_score2"><?php echo ($partic_away) ? ($partic_away->getName(false)) : '';?></label>
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-sm-2"><?php echo JText::_('BLFA_EXTRATIMEF');?></label>
                            <div class="col-sm-10">
                                <fieldset class="radio btn-group-js squardbut">
                                    <?php echo JHTML::_('select.booleanlist',  'is_extra', 'class="inputbox" ', $rows->object->is_extra);?>
                                </fieldset>
                            </div>
                        </div>

                        <?php
                        if (count($rows->lists['maps'])) {
                            for ($i = 0;$i < count($rows->lists['maps']);++$i) {
                                ?>
                                <div class="form-group">
                                    <label class="control-label col-sm-2"><?php echo $rows->lists['maps'][$i]->m_name;?></label>
                                    <div class="col-sm-10">
                                        <div class="form-inline"> 
                                            <label class="js_homeTeam" for="js_live_map1[]"><?php echo ($partic_home) ? ($partic_home->getName(false)) : '';?></label>
                                            <input class="form-control" type="number" name="js_live_map1[]" value="<?php echo $rows->lists['maps'][$i]->m_score1?>" /> 
                                            <input class="form-control" type="number" name="js_live_map2[]" value="<?php echo $rows->lists['maps'][$i]->m_score2?>" />
                                            <input type='hidden' name='js_live_mapid[]' value='<?php echo $rows->lists['maps'][$i]->id?>'/>
                                            <label class="js_awayTeam" for="js_live_map2[]"><?php echo ($partic_away) ? ($partic_away->getName(false)) : '';?></label>
                                        </div>
                                    </div>
                                </div>
                                <?php
                            }
                        } ?>
                    </form>
                    <div class="form-group clearfix">
                        <button type="button" id="js_save_live_score" class="btn btn-success pull-right"><?php echo JText::_("BLFA_SAVE");?></button>
                    </div>
                </div>
            </div>
        </div>
        <div class="jsrespdiv12">
            <div class="jsBepanel">
                <div class="jsBEheader">
                    <?php echo JText::_("BLFA_HEAD_LIVEPOST");?>
                </div>
                <div class="jsBEsettings">
                    <form method="post" name="jspostForm" id="jspostForm" class="form-horizontal">
                        <div class="form-group">
                            <label class="control-label col-sm-2" for="e_img"><?php echo JText::_("BLFA_LIVE_POSTICO");?></label>
                            <div class="col-sm-10">
                                <?php 
                                $javascript = "onchange=\"if (document.forms.jspostForm.e_img.options[selectedIndex].value!='') {"
                                ." jQuery('#jslive_icon_img').attr('src','".jUri::base()."media/bearleague/events/' + document.forms.jspostForm.e_img.options[selectedIndex].value);} else {jQuery('#jslive_icon_img').attr('src','".jUri::base()."media/system/images/blank.png');}\"";

                                echo JHTML::_('list.images',  'e_img', 0, $javascript, '/media/bearleague/events');

                                echo '<img id="jslive_icon_img" src="'.jUri::base().'/media/system/images/blank.png" />';
                                ?>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-sm-2" for="live_post"><?php echo JText::_("BLFA_LIVE_POST_TEXT");?></label>
                            <div class="col-sm-10 jslive_editor">
                                <?php 
                                $params = array( );
                                echo $editor->display( 'live_post', '', '100%', '200', '20', '20', true, false );
                                ?>
                                <!--textarea name="live_post" id="live_post"></textarea-->
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-sm-2"><?php echo JText::_("BLFA_LIVE_PLAYER_EVENT");?></label>
                            <div class="col-sm-10">
                                <div class="form-inline"> 
                                    <?php echo $rows->lists['events'];  ?>
                                    <?php echo $rows->lists['players'];  ?>
                                </div>
                                <div class="form-inline">
                                    <span id="spanSubEvent" style="display:none;">
                                        <span id="spanSubEventTitle"></span><?php echo $rows->lists["playersSub"];?>
                                    </span>
                                </div>
                                <?php if(!$single){?>
                                <input type="button" id="jslive_setsquad" class="btn btn-primary" value="<?php echo JText::_("BLFA_LIVE_SET_SQUAD");?>" />
                                <?php } ?>
                            </div>
                        </div>
                        <?php if(!$single){?>
                        <div class="form-group">
                            <label class="control-label col-sm-2" for="teamsq_id"><?php echo JText::_("BLFA_SUBSTITUTES");?></label>
                            <div class="col-sm-10">
                                <?php echo $rows->lists['teams']; ?>
                                <span id="js_live_subsdd"></span> 
                            </div>
                        </div>
                        <?php } ?>
                        <div class="form-group">
                            <label class="control-label col-sm-2" for="js_live_twitter"><?php echo JText::_("BLFA_TWITTER_LINK");?></label>
                            <div class="col-sm-10">
                                <input type="text" name="js_live_twitter" id="js_live_twitter" value="" class="form-control" />
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-sm-2" for="js_live_fb"><?php echo JText::_("BLFA_FB_LINK");?></label>
                            <div class="col-sm-10">
                                <input type="text" name="js_live_fb" id="js_live_fb" value="" class="form-control" />
                            </div>
                        </div>
                        <div class="form-group pull-right">
                            <label class="control-label col-sm-5" for="js_live_post_time"><?php echo JText::_("BLFA_LIVE_POST_TIME");?></label>
                            <div class="col-sm-7">
                                <input type="text" id="js_live_post_time" name="js_live_post_time" value="" class="form-control" />
                            </div>
                        </div>
                        <div class="form-group clearfix">
                            <div class="col-xs-12">
                                <button type="button" id="js_live_post" class="btn btn-success pull-right"><?php echo JText::_("BLFA_ADD_POST");?></button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <div class="modal fade" id="jsdiv_fill_squad">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                        <h5 class="modal-title"><?php echo JText::_("BLFA_LIVE_SET_SQUAD");?></h5>
                    </div>

                    <div class="modal-body table-responsive">

                    </div>
                    <div class="modal-footer">
                        <button type="button" id="js_save_squad" class="btn btn-success"><?php echo JText::_("BLFA_SAVE");?></button>
                        <button type="button" class="btn btn-secondary" data-dismiss="modal"><?php echo JText::_("BLFA_CLOSE");?></button>
                    </div>
                </div>
            </div>
        </div>

        <div class="modal fade" id="jsdiv_fill_editpost">
            <div class="modal-dialog" role="document">
              <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                    <h5 class="modal-title"><?php echo JText::_("BLFA_LIVE_EDIT_POST");?></h5>
                </div>

                <div class="modal-body table-responsive">
                    <form method="post" name="jspostFormEdit" id="jspostFormEdit" class="form-horizontal">
                        <div class="form-group">
                            <label class="control-label col-sm-2" for="e_img_edit"><?php echo JText::_("BLFA_LIVE_POSTICO");?></label>
                            <div class="col-sm-10">
                                <?php 
                                $javascript = "onchange=\"if (document.forms.jspostFormEdit.e_img_edit.options[selectedIndex].value!='') {"
                                ." jQuery('#jslive_icon_img_edit').attr('src','".jUri::base()."media/bearleague/events/' + document.forms.jspostFormEdit.e_img_edit.options[selectedIndex].value);} else {jQuery('#jslive_icon_img_edit').attr('src','".jUri::base()."media/system/images/blank.png');}\"";

                                echo JHTML::_('list.images',  'e_img_edit', 0, $javascript, 'media/bearleague/events');

                                echo '<img id="jslive_icon_img_edit" src="media/system/images/blank.png" />';
                                ?>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-sm-2" for="live_post_edit"><?php echo JText::_("BLFA_LIVE_POST_TEXT");?></label>
                            <div class="col-sm-10 jslive_editor">          
                                <?php 
                                $params = array( );
                                echo $editor->display( 'live_post_edit', '', '100%', '100', '20', '10', false, $params );
                                ?>

                                <!--textarea name="live_post" id="live_post"></textarea-->
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-sm-2"><?php echo JText::_("BLFA_LIVE_PLAYER_EVENT");?></label>
                            <div class="col-sm-10">
                                <div class="form-inline"> 
                                    <?php echo $rows->lists['events_edit'];  ?>
                                    
                                    <?php echo $rows->lists['players_edit'];  ?> 
                                    <span id="spanSubEventEdit" style="display:none;">
                                        <span id="spanSubEventEditTitle"></span><?php echo $rows->lists["playersSubEdit"];?>
                                    </span>
                                </div>
                            </div>
                        </div>
                        <?php if(!$single){?>
                        <div class="form-group">
                            <label class="control-label col-sm-2" for="teams_edit"><?php echo JText::_("BLFA_SUBSTITUTES");?></label>
                            <div class="col-sm-10">
                                <?php echo $rows->lists['teams_edit'];  ?>
                                <span id="js_live_subsdd_edit"></span> 
                            </div>
                        </div>
                        <?php } ?>
                        <div class="form-group">
                            <label class="control-label col-sm-2" for="js_live_twitter_edit"><?php echo JText::_("BLFA_TWITTER_LINK");?></label>
                            <div class="col-sm-10">
                                <input type="text" name="js_live_twitter_edit" id="js_live_twitter_edit" value="" class="form-control" />
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-sm-2" for="js_live_fb_edit"><?php echo JText::_("BLFA_FB_LINK");?></label>
                            <div class="col-sm-10">
                                <input type="text" name="js_live_fb_edit" id="js_live_fb_edit" value="" class="form-control" />
                            </div>
                        </div>
                        <div class="form-group pull-right">
                            <label class="control-label col-sm-5" for="js_live_post_time_edit"><?php echo JText::_("BLFA_LIVE_POST_TIME");?></label>
                            <div class="col-sm-7">
                                <input type="text" id="js_live_post_time_edit" name="js_live_post_time_edit" value="" class="form-control" />
                            </div>
                        </div>
                        <input type="hidden" id="edit_record" name="edit_record" value="0" />
                    </form>
                </div>
                <div class="modal-footer">
                  <button type="button" id="js_save_editpost" class="btn btn-success"><?php echo JText::_("BLFA_SAVE");?></button>
                  <button type="button" class="btn btn-secondary" data-dismiss="modal"><?php echo JText::_("BLFA_CLOSE");?></button>
              </div>
          </div>
      </div>
  </div>

  <?php 
}
JHtml::_('jquery.ui');
?>
    <script>
        var jsLiveSiteLink = '<?php echo JUri::base();?>';
    </script>
<?php
classJsportAddtag::addJS(JS_LIVE_ASSETS.'js/livematch.js');
classJsportAddtag::addCSS(JS_LIVE_ASSETS.'css/livematch.css');

$doc = JFactory::getDocument();

?>
<script>window.twttr = (function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0],
  t = window.twttr || {};
  if (d.getElementById(id)) return t;
  js = d.createElement(s);
  js.id = id;
  js.src = "https://platform.twitter.com/widgets.js";
  fjs.parentNode.insertBefore(js, fjs);

  t._e = [];
  t.ready = function(f) {
    t._e.push(f);
};

return t;
}(document, "script", "twitter-wjs"));</script>
<div id="fb-root"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "https://connect.facebook.net/en_US/all.js#xfbml=1";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>

<input type="hidden" id="match_id" name="match_id" value="<?php echo $rows->object->id;?>" />
<div id="js_live_post_container">
    <?php
    for($intA=0;$intA<count($rows->lists['liveposts']);$intA++){
        $imgsrc = JUri::base().'media/system/images/blank.png';
        if($rows->lists['liveposts'][$intA]->postIcon){
            $imgsrc = JUri::base().'media/bearleague/events/'.$rows->lists['liveposts'][$intA]->postIcon;
        }
        echo '<div class="jsLivePostDiv" jsupdaten="'.$rows->lists['liveposts'][$intA]->id.'">';
        echo '<div class="jsLivePostDivTime">'.($rows->lists['liveposts'][$intA]->minutes).'<div><img src="'.$imgsrc.'" /></div></div><div class="jsLivePostDivmain">'.nl2br($rows->lists['liveposts'][$intA]->postText).'</div>';
        if(jsHelper::isSeasonAdmin($rows->object->id)){
            echo '<div class="jsLivePostDivEditing" jsdata="'.$rows->lists['liveposts'][$intA]->id.'"><i class="fa fa-times" aria-hidden="true"></i><i class="fa fa-pencil-square-o" aria-hidden="true"></i></div>';

        }
        echo '</div>';
    }
    ?>
</div>

<div id="modalAj"><!-- Place at bottom of page --></div>
</div>