<?php
defined('_JEXEC') or die;
?>
<table class="jsTblVerticalTimeLine table">
    <tbody>

    <?php
    for($intE=0;$intE<count($eventsB);$intE++){
        $isOpposite = in_array($eventsB[$intE]->e_id,$opposite_events);
        ?>
        <tr>
            <?php
            if((!$isOpposite && $partic_home->object->id == $eventsB[$intE]->{$fieldIs}) ||
                ($isOpposite && $partic_away->object->id == $eventsB[$intE]->{$fieldIs})){

                echo '<td class="jsMatchPlayer">';
                echo $eventsB[$intE]->obj->getName(true);

                $subEv = jsHelperStages::getSubEvents($eventsB[$intE]->meid);
                if (isset($subEv->plFM) && $subEv->plFM) {


                    echo '<div class="subEvDiv">(' . $subEv->subEn . ': ' . $subEv->plFM . ')</div>';
                }

                echo '</td>';
            } else {
                echo '<td class="jsMatchPlayer jsHidden">';
                echo '&nbsp;';
                echo '</td>';
            }

            ?>


            <?php
            if((!$isOpposite && $partic_home->object->id == $eventsB[$intE]->{$fieldIs}) ||
                ($isOpposite && $partic_away->object->id == $eventsB[$intE]->{$fieldIs})){
                echo '<td class="jsMatchEvent">';
                echo $eventsB[$intE]->objEvent->getEmblem(false);
                echo '</td>';
            } else {
                echo '<td class="jsMatchEvent jsHidden">';
                echo '&nbsp;';
                echo '</td>';
            }

            ?>

            <td class="jstimeevent">
                <?php

                    echo $eventsB[$intE]->minutes ? $eventsB[$intE]->minutes."'" : '';

                ?>
            </td>
            <?php
            if((!$isOpposite && $partic_away->object->id == $eventsB[$intE]->{$fieldIs}) ||
                ($isOpposite && $partic_home->object->id == $eventsB[$intE]->{$fieldIs})){
                echo '<td class="jsMatchEvent">';
                echo $eventsB[$intE]->objEvent->getEmblem(false);
                echo '</td>';
            } else {
                echo '<td class="jsMatchEvent jsHidden">';
                echo '&nbsp;';
                echo '</td>';
            }
            ?>

            <?php
            if((!$isOpposite && $partic_away->object->id == $eventsB[$intE]->{$fieldIs}) ||
                ($isOpposite && $partic_home->object->id == $eventsB[$intE]->{$fieldIs})){
                echo '<td class="jsMatchPlayer">';
                echo $eventsB[$intE]->obj->getName(true);

                $subEv = jsHelperStages::getSubEvents($eventsB[$intE]->meid);
                if (isset($subEv->plFM) && $subEv->plFM) {


                    echo '<div class="subEvDiv">(' . $subEv->subEn . ': ' . $subEv->plFM . ')</div>';
                }
                echo '</td>';
            } else {
                echo '<td class="jsMatchPlayer jsHidden">';
                echo '&nbsp;';
                echo '</td>';
            }
            ?>
        </tr>
        <?php
    }
    ?>
    </tbody>
</table>