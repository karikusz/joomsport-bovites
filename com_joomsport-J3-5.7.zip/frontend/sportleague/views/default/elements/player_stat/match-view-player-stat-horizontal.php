<?php
defined('_JEXEC') or die;
$show_count = false;
$show_time = false;
for ($intP = 0; $intP < count($eventsB); ++$intP) {
    if($eventsB[$intP]->ecount != 1){
        $show_count = true;
    }
    if(isset($eventsB[$intP]->minutes) && $eventsB[$intP]->minutes){
        $show_time = true;
    }
}
?>
<div class="jsMatchStatTeams">
    <div class="clearfix">
        <div class="jsMatchStatHome col-sm-6">

                <table class="jsTblMatchTab firstTeam">
                    <thead>
                    <tr>
                        <th></th>
                        <?php if($show_count){?>
                        <th><?php echo classJsportLanguage::get('BLFA_QTY'); ?></th>
                        <?php } ?>

                        <th><?php echo classJsportLanguage::get('BLFA_EVENT'); ?></th>
                        <?php if($show_time){?>
                        <th><?php echo classJsportLanguage::get('BLFA_TIME'); ?></th>
                        <?php } ?>
                    </tr>
                    </thead>
                    <tbody>
                    <?php
                    for ($intP = 0; $intP < count($eventsB); ++$intP) {
                        $isOpposite = in_array($eventsB[$intP]->e_id, $opposite_events);
                        if ((!$isOpposite && $partic_home->object->id == $eventsB[$intP]->{$fieldIs}) ||
                            ($isOpposite && $partic_away->object->id == $eventsB[$intP]->{$fieldIs})) {
                            ?>
                            <tr class="jsMatchTRevents">
                                <td class="evPlayerName">
                                    <?php echo $eventsB[$intP]->obj->getName(true);

                                    $subEv = jsHelperStages::getSubEvents($eventsB[$intP]->meid);
                                    if (isset($subEv->plFM) && $subEv->plFM) {


                                        echo '<div class="subEvDiv">(' . $subEv->subEn . ': ' . $subEv->plFM . ')</div>';
                                    }
                                    ?>
                                </td>
                                <?php if($show_count){?>
                                <td>
                                    <?php echo $eventsB[$intP]->ecount; ?>
                                </td>
                                <?php } ?>
                                <td>
                                    <?php echo $eventsB[$intP]->objEvent->getEmblem(false); ?>
                                </td>
                                <?php if($show_time){?>
                                <td>
                                    <?php

                                        echo $eventsB[$intP]->minutes ? $eventsB[$intP]->minutes . "'" : '';

                                    ?>
                                </td>
                                <?php } ?>
                            </tr>
                            <?php
                        }
                    }
                    ?>
                    </tbody>
                </table>

        </div>
        <div class="jsMatchStatAway col-sm-6">

                <table class="jsTblMatchTab">
                    <thead>
                    <tr>
                        <?php if($show_time){?>
                        <th><?php echo classJsportLanguage::get('BLFA_TIME'); ?></th>
                        <?php } ?>
                        <th><?php echo classJsportLanguage::get('BLFA_EVENT'); ?></th>
                        <?php if($show_count){?>
                        <th><?php echo classJsportLanguage::get('BLFA_QTY'); ?></th>
                        <?php } ?>
                        <th></th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php
                    for ($intP = 0; $intP < count($eventsB); ++$intP) {
                        if ((!$isOpposite && $partic_away->object->id == $eventsB[$intP]->{$fieldIs}) ||
                            ($isOpposite && $partic_home->object->id == $eventsB[$intP]->{$fieldIs})) {
                            ?>
                            <tr class="jsMatchTRevents">
                                <?php if($show_time){?>
                                <td>
                                    <?php

                                        echo $eventsB[$intP]->minutes ? $eventsB[$intP]->minutes . "'" : '';

                                    ?>
                                </td>
                                <?php } ?>
                                <td>
                                    <?php echo $eventsB[$intP]->objEvent->getEmblem(false); ?>
                                </td>
                                <?php if($show_count){?>
                                <td>
                                    <?php echo $eventsB[$intP]->ecount; ?>
                                </td>
                                <?php } ?>
                                <td class="evPlayerName">
                                    <?php echo $eventsB[$intP]->obj->getName(true);
                                    $subEv = jsHelperStages::getSubEvents($eventsB[$intP]->meid);
                                    if (isset($subEv->plFM) && $subEv->plFM) {


                                        echo '<div class="subEvDiv">(' . $subEv->subEn . ': ' . $subEv->plFM . ')</div>';
                                    }
                                    ?>
                                </td>
                            </tr>
                            <?php
                        }
                    }
                    ?>
                    </tbody>
                </table>

        </div>
    </div>
</div>