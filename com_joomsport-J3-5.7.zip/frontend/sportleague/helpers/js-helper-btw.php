<?php
/*------------------------------------------------------------------------
# JoomSport Professional
# ------------------------------------------------------------------------
# BearDev development company
# Copyright (C) 2011 JoomSport.com. All Rights Reserved.
# @license - http://joomsport.com/news/license.html GNU/GPL
# Websites: http://www.JoomSport.com
# Technical Support:  Forum - http://joomsport.com/helpdesk/
-------------------------------------------------------------------------*/
defined('_JEXEC') or die('Restricted access');

class jsHelperBtw
{
    public static function matches($team1, $team2, $isSingle, $homeOnly = 0){
        global $jsDatabase;
        $team1 = intval($team1);
        $team2 = intval($team2);
        $query = "SELECT m.*"
            ." FROM #__bl_match as m"
            .' JOIN '.DB_TBL_MATCHDAY.' as md ON md.id = m.m_id'
            . ' JOIN '.DB_TBL_SEASONS.' as s ON md.s_id=s.s_id'
            .' JOIN '.DB_TBL_TOURNAMENT.' as tr ON tr.id=s.t_id'
            ." WHERE m.m_played = '1' AND tr.t_single = {$isSingle}"
            .($homeOnly?(" AND m.team1_id = {$team1} AND m.team2_id = {$team2}"):" AND m.team1_id IN ({$team1},{$team2}) AND m.team2_id IN ({$team1},{$team2})")

            ." ORDER BY m.m_date DESC";
        $matches = $jsDatabase->select($query);


        return $matches;
    }
    public static function getLastMatches($partic_id, $season_id, $isSingle,  $place = 0, $limit = 5){
        $limit = 5;
        //place 1-home, 2- away
        $options = array('team_id' => $partic_id, 'season_id' => $season_id, 'place' => $place, 'limit' => $limit, 'played' => 1, 'ordering' => 'm.m_date DESC');

        $obj = new classJsportMatches($options);
        $rows = $obj->getMatchList($isSingle);
        $matches = array();

        if ($rows['list']) {
            foreach ($rows['list'] as $row) {
                $match = new classJsportMatch($row->id, false);
                $match->opposite = 0;
                if($partic_id == $match->object->team1_id){
                    $match->opposite = 1;
                }
                $matches[] = $match->getRowSimple();
            }
        }

        return $matches;
    }

    public static function getPositions($season_id,$team1,$team2){
        global $jsDatabase;
        $obj = new stdClass();
        $obj->teamHomePosition = self::getPosition($season_id,$team1);
        $obj->teamAwayPosition = self::getPosition($season_id,$team2);

        $obj->maxPosition =  $jsDatabase->selectValue("SELECT COUNT(*) FROM #__bl_season_table WHERE season_id = {$season_id}");
        return $obj;
    }
    public static function getPosition($season_id,$team_id){
        global $jsDatabase;
        $res = $jsDatabase->selectValue("SELECT ordering FROM #__bl_season_table WHERE season_id = {$season_id} AND participant_id = {$team_id}");
        if($res !== null){
            return intval($res);
        }else{
            return null;
        }
    }

    public static function getPlayedMatches($team_id, $season_id, $place = 0){
        global $jsDatabase;

        $query = "SELECT m.*"
            ." FROM #__bl_match as m"
            ." JOIN #__bl_matchday as md ON m.m_id = md.id AND md.s_id = {$season_id}"
            ." WHERE  m.m_played = '1'"
            .($place?($place==1?" AND m.team1_id = {$team_id}":" AND m.team2_id = {$team_id}"):" AND (m.team1_id = {$team_id} OR m.team2_id = {$team_id})")

            ." ORDER BY m.m_date DESC";
        $matches = $jsDatabase->select($query);





        return $matches;
    }

    public static function getTeamStat($team_id, $season_id, $matches){
        $db = JFactory::getDBO();
        $db->setQuery("SELECT me.e_id, SUM(me.ecount) as cnt "
            ." FROM #__bl_match_events as me"
            ." JOIN #__bl_match as m ON m.id = me.match_id"
            ." JOIN #__bl_matchday as md ON m.m_id = md.id AND md.s_id = {$season_id}"
            ." WHERE t_id={$team_id}"
            .(count($matches)?" AND match_id IN (".implode(",",$matches).")":"")
            ." GROUP BY me.e_id"
        );
        $events = $db->loadAssocList("e_id");
        return $events;
    }



    public static function getTeamGoals($team_id, $matches){
        global $jsDatabase;
        $scored=$conceeded=0;
        for($intA=0;$intA<count($matches);$intA++){
            $query = "SELECT m.* "
                ." FROM #__bl_match as m"
                ." WHERE m.id = " . $matches[$intA];
            $match = $jsDatabase->selectObject($query);
            if($match){
                if($match->team1_id == $team_id){
                    $scored += $match->score1;
                    $conceeded += $match->score2;
                }else{
                    $scored += $match->score2;
                    $conceeded += $match->score1;
                }
            }

        }
        return array("scored"=>$scored, "conceeded"=>$conceeded);
    }

    public static function getColumnsOptions($season_id, $team_id){
        global $jsDatabase;

        $query = 'SELECT COUNT(m.id) as played_chk,'
            ." SUM(if(m.score1 > m.score2 AND m.team1_id = {$team_id},1,0)) as winhome_chk,"
            ." SUM(if(m.score2 > m.score1 AND m.team2_id = {$team_id},1,0)) as winaway_chk,"
            ." SUM(if(m.score2 = m.score1 AND m.team1_id = {$team_id},1,0)) as drawhome_chk,"
            ." SUM(if(m.score2 = m.score1 AND m.team2_id = {$team_id},1,0)) as drawaway_chk,"
            ." SUM(if(m.score1 < m.score2 AND m.team1_id = {$team_id},1,0)) as losthome_chk,"
            ." SUM(if(m.score2 < m.score1 AND m.team2_id = {$team_id},1,0)) as lostaway_chk"

            .' FROM '.DB_TBL_MATCH.' as m'
            .' JOIN '.DB_TBL_MATCHDAY.' as md ON m.m_id = md.id'
            .' WHERE md.s_id = '.$season_id
            .' AND m.published = 1'
            ." AND (m.team1_id = {$team_id} OR m.team2_id = {$team_id} )"
            .' AND m.m_played = 1';

        $options = $jsDatabase->selectArray($query);
        return $options;

        $options =  $jsDatabase->selectValue("SELECT options FROM #__bl_season_table WHERE season_id = {$season_id} AND participant_id = {$team_id}");
        return json_decode($options, true);
    }

    public static function getStandingColors($season_id){
        require_once JS_PATH_MODELS.'model-jsport-season.php';
        $obj = new modelJsportSeason($season_id);
        $arr = $obj->getColors();

        return is_array($arr)?$arr:array();
    }

    public static function showH2HBlock($match_id){
        global $jsConfig, $jsDatabase;
        $query = "SELECT md.s_id,m.m_played "
            ." FROM #__bl_match as m"
            ." JOIN #__bl_matchday as md ON md.id = m.m_id"
        ." WHERE m.id = {$match_id}";
        $match = $jsDatabase->selectObject($query);

        $enbl_block = $jsConfig->get('enbl_match_analytics_block');
        if(!$enbl_block){return false;};
        if(!$match->s_id){return false;};
        if($match->m_played != 0){ return false; }
        return true;
    }

    public static function showPositionBlock($match_id){
        global $jsDatabase;
        $query = "SELECT md.* "
            ." FROM #__bl_match as m"
            ." JOIN #__bl_matchday as md ON md.id = m.m_id"
            ." WHERE m.id = {$match_id}";
        $matchDay = $jsDatabase->selectObject($query);

        if(!$matchDay){
            return false;
        }

        $groups = $jsDatabase->selectValue("SELECT COUNT(*) FROM #__bl_groups WHERE s_id = ".intval($matchDay->s_id));

        if($groups){
            return false;
        }
        if(!$matchDay->t_type && !$matchDay->is_playoff){
            return true;
        }
        return false;
    }

    public static function getSeasonName($season_id){
        global $jsDatabase;
        return  $jsDatabase->selectValue('SELECT CONCAT(t.name, " ", s.s_name) as tsname'
            .' FROM '.DB_TBL_SEASONS.' as s'
            .' JOIN '.DB_TBL_TOURNAMENT.' as t  ON s.t_id = t.id'
            .' WHERE s.s_id = '.intval($season_id));
    }

    public static function getMatchSeason($matchID){
        global $jsDatabase;
        return  $jsDatabase->selectValue('SELECT md.s_id'
            .' FROM '.DB_TBL_MATCH.' as m'
            .' JOIN '.DB_TBL_MATCHDAY.' as md  ON md.id = m.m_id'
            .' WHERE m.id = '.intval($matchID));
    }
}
