<?php

abstract class classJsportH2H
{
    public $homeID;
    public $awayID;
    public $isSingle;

    public function __construct($team1, $team2, $isSingle){
        $this->homeID = $team1;
        $this->awayID = $team2;
        $this->isSingle = $isSingle;
    }
    abstract public function matchesBtw();
    abstract public function statBtw($eventID);
    abstract public function wdlBtw();

    public function checkIDs(){

    }
}