<?php
require_once 'class_jsport_h2h.php';
require_once JS_PATH_HELPERS . "js-helper-btw.php";

class classJsportH2HLocal extends classJsportH2H
{
    public $homeID;
    public $awayID;
    public $isSingle;

    public function __construct($team1, $team2, $isSingle){
        $this->homeID = $team1;
        $this->awayID = $team2;
        $this->isSingle = $isSingle;
    }
    public function matchesBtw(){
        return jsHelperBtw::matches($this->homeID, $this->awayID, $this->isSingle, 1);
    }
    public function statBtw($eventID){

    }
    public function wdlBtw(){

    }
}