<?php
/*------------------------------------------------------------------------
# JoomSport Professional 
# ------------------------------------------------------------------------
# BearDev development company 
# Copyright (C) 2011 JoomSport.com. All Rights Reserved.
# @license - http://joomsport.com/news/license.html GNU/GPL
# Websites: http://www.JoomSport.com 
# Technical Support:  Forum - http://joomsport.com/helpdesk/
-------------------------------------------------------------------------*/
defined('_JEXEC') or die('Restricted access');

require_once JS_PATH_OBJECTS.'class-jsport-team.php';


class classJsportRoster
{
    private $id = null;
    public $season_id = null;
    public $object = null;
    public $teamName = null;
    public $lists = null;
    public $rosterType = 0;

    public function __construct($id = 0, $season_id = null, $rosterType = null)
    {
        global $jsDatabase;
        if (!$id) {
            $this->season_id = (int) classJsportRequest::get('sid');
            $this->id = (int) classJsportRequest::get('tid');
        } else {
            $this->season_id = $season_id;
            $this->id = $id;
        }

        $this->rosterType = (int) classJsportRequest::get('roster_type');

        if($rosterType != null){
            $this->rosterType = $rosterType;
        }
        
        if (!$this->id) {
            die('ERROR! Team ID not DEFINED');
        }
        
        $query = 'SELECT s.s_id as id,s.s_name as s_name'
                    .' FROM '.DB_TBL_SEASONS.' as s'
                    .' LEFT JOIN '.DB_TBL_TOURNAMENT.' as t ON t.id = s.t_id'
                    .' JOIN '.DB_TBL_SEASON_TEAMS.' as st ON s.s_id=st.season_id'
                    ." WHERE s.published='1' AND st.team_id=".$this->id.''
                    .' AND s.s_id='.intval($this->season_id).' '
                    .' ORDER BY s.s_name';

        $rows = $jsDatabase->select($query);
        
        if(!count($rows)){
            $this->season_id = 0;
        }

        $teamObj = new classJsportTeam($this->id, $this->season_id);
        $teamObj->getPlayers(true);
        $this->lists = $teamObj->lists;
        $this->teamName = $teamObj->getName(false,0,0);
        $this->object = $teamObj->getObject();

        if($this->rosterType == '1'){
            $this->lists['players'] = array();
        }else{
            $this->lists['team_staff'] = array();
        }

    }


    public function getObject()
    {
        return $this->object;
    }
    public function getObjectThis()
    {
        return $this;
    }

    public function getRow()
    {
        jsHelper::setPageTitle($this->teamName);

        return $this;
    }
    public function getTabs()
    {
        global $jsConfig;
        $tabs = array();


        return $tabs;
    }


}
