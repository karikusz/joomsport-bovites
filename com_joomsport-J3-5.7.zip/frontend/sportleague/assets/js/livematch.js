jQuery(document).ready(function(){
    jQuery("#jslive_setsquad").on("click",function(){
        var match_id = jQuery("#match_id").val();
        jQuery.ajax({
            url: jsLiveSiteLink + "index.php?option=com_joomsport&task=showMatchLineUp&tmpl=component&no_html=1&controller=journalist",
            type: 'POST',
            data: {"match_id" : match_id}
        }).done(function(res) {
            var IS_JSON = true;
            try
            {
                var json = JSON.parse(res);
            }
            catch(err)
            {
                IS_JSON = false;
            } 
            if(IS_JSON){
                if(json.error == '0'){

                    jQuery("#jsdiv_fill_squad").find(".modal-body").html(json.html);
                    jsChkFnc();
                    jQuery("#jsdiv_fill_squad").modal("show");
                }
            }
            
        });
        
    });
    
    jsChkFnc = function(){
        jQuery('.radio.btn-group-js label').addClass('btn');
        jQuery('.squardbut label:not(.active)').click(function()
        {
                var label = jQuery(this);
                var input = jQuery('#' + label.attr('for'));

                //console.log(input.prop('checked'));
                if (!input.prop('checked')) {
                    //console.log(input.val());
                        label.closest('.btn-group-js').find('label').removeClass('active btn-success btn-danger btn-primary btn-warning');
                        if (input.val() == '') {
                                label.addClass('active btn-primary');
                        } else if (input.val() == 0) {
                                label.addClass('active btn-danger');
                        } else if (input.val() == '2'){

                                label.addClass('active btn-warning');

                        }else{
                                label.addClass('active btn-success');
                        }
                        input.prop('checked', true);
                        input.trigger('change');

                }
        });
        jQuery('.btn-group-js input[checked=checked]').each(function()
        {
                if (jQuery(this).val() == '') {
                        jQuery('label[for=' + jQuery(this).attr('id') + ']').addClass('active btn-primary');
                } else if (jQuery(this).val() == 0) {
                        jQuery('label[for=' + jQuery(this).attr('id') + ']').addClass('active btn-danger');
                } else if (jQuery(this).val() == 2) {
                        jQuery('label[for=' + jQuery(this).attr('id') + ']').addClass('active btn-warning');

                } else {
                        jQuery('label[for=' + jQuery(this).attr('id') + ']').addClass('active btn-success');
                }
        });
    }
    
    jQuery("#js_save_squad").on("click",function(){
        var match_id = jQuery("#match_id").val();
        jQuery.ajax({
            url: jsLiveSiteLink + "index.php?option=com_joomsport&task=setMatchLineUp&tmpl=component&no_html=1&controller=journalist&match_id="+match_id,
            type: 'POST',
            data: jQuery("#jsSquadForm").serialize(),
        }).done(function(res) {
            jQuery("#jsdiv_fill_squad").modal("hide");
        });
    });    
    jQuery("#js_save_live_general").on("click",function(){
        jQuery('#modalAj').show();
        var match_id = jQuery("#match_id").val();
        jQuery.ajax({
            url: jsLiveSiteLink + "index.php?option=com_joomsport&task=setMatchGeneral&tmpl=component&no_html=1&controller=journalist&match_id="+match_id,
            type: 'POST',
            data: {"match_status" : jQuery("#match_status").val(), "match_duration" : jQuery("#jslive_match_duration").val()},
        }).done(function(res) {
            
            jQuery('#modalAj').hide();
        });
    });
    jQuery("#js_save_live_score").on("click",function(){
        jQuery('#modalAj').show();
        var match_id = jQuery("#match_id").val();
        jQuery.ajax({
            url: jsLiveSiteLink + "index.php?option=com_joomsport&task=setMatchScore&tmpl=component&no_html=1&controller=journalist&match_id="+match_id,
            type: 'POST',
            data: jQuery("#jsScoreForm").serialize(),
        }).done(function(res) {
            jsLiveCheckUpdts();
            jQuery('#modalAj').hide();
        });
    });
    
    jQuery("#teamsq_id").on("change", function(){
        jQuery('#modalAj').show();
        var match_id = jQuery("#match_id").val();
        var team_id = jQuery(this).val();
        if(team_id && team_id != '0'){
            jQuery.ajax({
                url: jsLiveSiteLink + "index.php?option=com_joomsport&task=getMatchSubs&tmpl=component&no_html=1&controller=journalist&match_id="+match_id,
                type: 'POST',
                data: {"team_id" : team_id},
            }).done(function(res) {
                jQuery('#modalAj').hide();
                var IS_JSON = true;
                try
                {
                    var json = JSON.parse(res);
                }
                catch(err)
                {
                    IS_JSON = false;
                } 
                if(IS_JSON){
                    if(json.error == '0'){

                        jQuery("#js_live_subsdd").html(json.html);

                    }
                }
            });
        }else{
            
            jQuery("#js_live_subsdd").html('');
            jQuery('#modalAj').hide();
        }
    });
    
    jQuery("#teamsq_id_edit").on("change", function(event, pIn, pOut){
        //console.log(subID);
        //jQuery('#modalAj').show();
        var match_id = jQuery("#match_id").val();
        var team_id = jQuery(this).val();
        
        if(team_id && team_id != '0'){
            jQuery.ajax({
                url: jsLiveSiteLink + "index.php?option=com_joomsport&task=getMatchSubs&tmpl=component&no_html=1&controller=journalist&match_id="+match_id,
                type: 'POST',
                data: {"team_id" : team_id, "isedit" : 1, "recordID" : jQuery("#edit_record").val()},
            }).done(function(res) {
                //jQuery('#modalAj').hide();
                var IS_JSON = true;
                try
                {
                    var json = JSON.parse(res);
                }
                catch(err)
                {
                    IS_JSON = false;
                } 
                if(IS_JSON){
                    if(json.error == '0'){

                        jQuery("#js_live_subsdd_edit").html(json.html);
                        /*console.log(jQuery("#jslive_subs_in_edit").val());
                        console.log(pIn);
                        if(pIn){
                            jQuery("#jslive_subs_in_edit").val(pIn);
                            console.log(jQuery("#jslive_subs_in_edit").val());
                                jQuery("#jslive_subs_in_edit").trigger('change');
                                console.log(jQuery("#jslive_subs_in_edit").val());
                                   
                        }
                        if(pOut){
                            jQuery("#jslive_subs_out_edit").val(pOut);
                                jQuery("#jslive_subs_out_edit").trigger('change');
                                console.log(jQuery("#jslive_subs_out_edit").val());
                        }*/
                    }
                }
            });
        }else{
            
            jQuery("#js_live_subsdd_edit").html('');
            jQuery('#modalAj').hide();
        }
    });
    
    var js_live_interval;
    
    jQuery("#js_live_ticker_start").on("click", function(){
        jQuery("#js_live_ticker_start").hide();
        jQuery("#js_live_ticker_stop").show();
        js_live_interval = setInterval(function () { 
            jQuery("#jslive_time").val(parseInt(jQuery("#jslive_time").val())+1); jQuery("#js_live_post_time").val(parseInt(jQuery("#jslive_time").val()));
            jQuery("#jslive_time").trigger( "change" );
            if(parseInt(jQuery("#jslive_match_duration").val()) <= parseInt(jQuery("#jslive_time").val())){
                clearInterval(js_live_interval);
            }
            
        }, 60000);
    });
    jQuery("#js_live_ticker_stop").on("click", function(){
        jQuery("#js_live_ticker_stop").hide();
        jQuery("#js_live_ticker_start").show();
        clearInterval(js_live_interval);
    });
    
    jQuery("#jslive_time").on("change", function(){
        var match_id = jQuery("#match_id").val();
        jQuery.ajax({
            url: jsLiveSiteLink + "index.php?option=com_joomsport&task=setMatchTimer&tmpl=component&no_html=1&controller=journalist&match_id="+match_id,
            type: 'POST',
            data: {'current_time' : jQuery("#jslive_time").val()},
        }).done(function(res) {

        });
    })
    
    jQuery("#js_live_post").on("click", function(){
        jQuery('#modalAj').show();
        var match_id = jQuery("#match_id").val();
        jQuery("#live_post").val(tinyMCE.get('live_post').getContent());
        
        
        
        jQuery.ajax({
            url: jsLiveSiteLink + "index.php?option=com_joomsport&task=addPost&tmpl=component&no_html=1&controller=journalist&match_id="+match_id,
            type: 'POST',
            data: jQuery("#jspostForm").serialize(),
        }).done(function(res) {
            var IS_JSON = true;
            
            try
            {
                var json = JSON.parse(res);
            }
            catch(err)
            {
                IS_JSON = false;
            } 
            if(IS_JSON){
                
                if(json.error == '0'){

                    jQuery("#js_live_post_container").prepend(json.html);

                }
            }
            var posttime = parseInt(jQuery("#js_live_post_time").val());
            jQuery("#jspostForm").get(0).reset();
            if(posttime){
                jQuery("#js_live_post_time").val(posttime);
            }
            jQuery("#event_id").select2();
            jQuery("#playerz_id").select2();
            jQuery("#e_img").select2();

            jQuery("#jslive_icon_img").attr("src",jsLiveSiteLink+'media/system/images/blank.png');
            
            jQuery("#teamsq_id").select2();
            jQuery("#js_live_subsdd").html('');
            FB.XFBML.parse();
            
            jQuery('#modalAj').hide();
        });
    });
    
    
    jsChkFnc();
    
    //guest updates
    var js_live_interval_guest;

    

    function jsLiveCheckUpdts(){
        var match_id = jQuery("#match_id").val();
        jQuery.ajax({
            url: jsLiveSiteLink+"index.php?option=com_joomsport&task=checkUpdts&tmpl=component&no_html=1&controller=journalist&match_id="+match_id+"&lastupd="+jslive_last_upd,
            type: 'POST',
            data: jQuery("#jspostForm").serialize(),
        }).done(function(res) {
            var IS_JSON = true;
            
            try
            {
                var json = JSON.parse(res);
            }
            catch(err)
            {
                IS_JSON = false;
            } 
            if(IS_JSON){
                
                if(json.error == '0'){
                    var jshtml = JSON.parse(json.html);
                    //console.log(jshtml);
                    for(var i=0;i<jshtml.length;i++){
                        var rec = jshtml[i];
                        //console.log(rec);
                        var recid = rec[0];
                        var rechtml = rec[1];
                        var isedit = jQuery("#js_live_post_container").find("div[jsupdaten='"+recid+"']");
                        //console.log(isedit);
                        if(isedit[0]){
                            isedit.replaceWith(rechtml);
                        }else{
                            //console.log(rechtml);
                            jQuery("#js_live_post_container").prepend(rechtml);
                        }
                        
                    }
                    if(json.plstat){
                        jQuery("#jsPlayerStatMatchDiv").html(json.plstat);
                    }
                    if(json.plsquad){
                        jQuery("#stab_squad").html(json.plsquad);
                    }
                    if(json.hmev){
                        var hm = JSON.parse(json.hmev);
                        var aw = JSON.parse(json.awev);
                        var duration = parseInt(json.duration);
                        var stepJSD = jQuery('#jsTimeLineDiv').width()/duration;
                        jQuery('#jsTimeLineDivHome').html('');
                        jQuery('#jsTimeLineDivAway').html('');
                        calcJSTl(stepJSD,hm,aw);
                        
                    }
                    /*var jsevents = JSON.parse(json.events);
                    var duration = parseInt(jQuery(".jsTimeLineDivInnerResTime").html());
                    var stepJSD = jQuery('#jsTimeLineDiv').width()/duration;
                    var same_minutes_h = [];
                    var same_minutes_a = [];
                    for(var i=0;i<jsevents.length;i++){
                        var rec = jsevents[i];
                        if(rec.t_id == json.part[0]){
                            var cont = jQuery("table.firstTeam > tbody");
                            cont.append('<tr class="jsMatchTRevents"><td class="evPlayerName">'+rec.pname+'</td><td>'+rec.ecount+'</td><td>'+rec.e_img+'</td><td>'+rec.minutes+'\'</td></tr>');
                            if(parseInt(rec.minutes) >= 1 && rec.e_img_tline){  
                                var tooltip = '<span calss="tooltip-inner"><span>'+rec.minutes+'\'</span><span><img src="'+rec.e_img_tline+'" width="16"></span><span>'+rec.pname_tline+'</span></span>'; 

                                var dv = jQuery('<div />', {
                                 "class": 'jsTLEvent',
                                 text: ""});
                                 dv.css("left",rec.minutes*stepJSD-11);
                                 if(same_minutes_h[rec.minutes]){
                                     dv.css('bottom',28*(same_minutes_h[rec.minutes]));
                                 }
                                 var dvimg = jQuery('<div />',{"class": 'jsTLEventInner'});

                                 dvimg.append(jQuery('<img />', {
                                "class": "jsImgTL",    
                                "src": rec.e_img_tline,
                                "data-html":"true",
                                    "data-toggle2":"tooltipJSF",
                                    "data-placement":"top",
                                    "title":"",
                                    "data-original-title":tooltip
                                }));

                                 dv.append(dvimg);
                                 dv.append(jQuery('<div />', {
                                 "class": 'tlArrow'}));
                                jQuery('#jsTimeLineDivHome').append(dv);
                                if(!same_minutes_h[rec.minutes]){
                                    same_minutes_h[rec.minutes] = 1;
                                }else{
                                     same_minutes_h[rec.minutes] = parseInt(same_minutes_h[rec.minutes])+1;
                                }  
                            }
                        }else if(rec.t_id == json.part[1]){
                            var minutes
                            var cont = jQuery("table.secondTeam > tbody");
                            cont.append('<tr class="jsMatchTRevents"><td>'+rec.minutes+'\'</td><td>'+rec.e_img+'</td><td>'+rec.ecount+'</td><td class="evPlayerName">'+rec.pname+'</td></tr>');
                            if(parseInt(rec.minutes) >= 1 && rec.e_img_tline){  
                        
                                var tooltip = '<span calss="tooltip-inner"><span>'+rec.minutes+'\'</span><span><img src="'+rec.e_img_tline+'" width="16"></span><span>'+rec.pname_tline+'</span></span>'; 

                                var dv = jQuery('<div />', {
                                 "class": 'jsTLEvent',
                                 text: ""});
                                 dv.css("left",rec.minutes*stepJSD-11);
                                 if(same_minutes_a[rec.minutes]){
                                     dv.css('top',28*(same_minutes_a[rec.minutes]));
                                 }
                                 dv.append(jQuery('<div />', {
                                 "class": 'tlArrow'}));
                                 
                                 var dvimg = jQuery('<div />',{"class": 'jsTLEventInner'});
                                 dvimg.append(jQuery('<img />', {
                                "class": "jsImgTL",    
                                "src": rec.e_img_tline,
                                    "data-html":"true",
                                    "data-toggle2":"tooltipJSF",
                                    "data-placement":"bottom",
                                    "title":"",
                                    "data-original-title":tooltip
                                }));
                                 dv.append(dvimg);
                                jQuery('#jsTimeLineDivAway').append(dv);
                                if(!same_minutes_a[rec.minutes]){
                                    same_minutes_a[rec.minutes] = 1;
                                }else{
                                     same_minutes_a[rec.minutes] = parseInt(same_minutes_a[rec.minutes])+1;
                                }  
                            }
                        }
                    }   */ 
                    
                    //jQuery("#js_live_post_container").prepend(json.html);
                    
                    if(json.score){
                        jQuery(".BigMScore1").html(json.score[0]);
                        jQuery(".BigMScore2").html(json.score[1]);
                        
                        var divMobile = jQuery(".jsMatchDivMobile").find(".jsScoreDiv");
                        
                        var scoreIs = divMobile.find("a");
                        scoreIs.html(json.score[0] + ' - ' + json.score[1]);
                    }
                    if(json.timer){
                        jQuery("#jslive_ticker").html(json.timer+"'");
                        
                        //console.log(duration);
                       // console.log(parseInt(json.timer));
                        if(duration){
                            
                            if(parseInt(json.timer) <= duration){
                                var perc = 100 * (parseInt(json.timer)/duration);
                                jQuery(".jsTimeLineDivInner").css("width",perc+'%');
                            }
                        }
                        
                    }
                    //console.log(json.postsin);
                    if(json.postsin){
                        jQuery(".jsLivePostDiv").each(function(){
                            var updID = jQuery(this).attr("jsupdaten");
                            //console.log(updID);
                            //console.log(json.postsin.length);
                            //console.log(jQuery.inArray(json.postsin, updID));
                            if(json.postsin.length == 0 || jQuery.inArray(updID, json.postsin) == -1){
                                jQuery(this).remove();
                            }
                        });
                    }
                    
                    var d_jsLUP = new Date();
                    jslive_last_upd = d_jsLUP.toUTCString();
                }
            }
        });    
    }
    
    jQuery(document).on("click",".jsLivePostDivEditing > .fa-times",function(){
        if (confirm("Are you sure?")) {
            var match_id = jQuery("#match_id").val();
            var recordID = jQuery(this).parent().attr("jsdata");
            var curDiv = jQuery(this).parent().parent();
            if(recordID){
                jQuery.ajax({
                    url: jsLiveSiteLink+"index.php?option=com_joomsport&task=deleteRecord&tmpl=component&no_html=1&controller=journalist&match_id="+match_id,
                    type: 'POST',
                    data: {rid: recordID},
                }).done(function(res) {
                    if(res == "1"){
                        curDiv.remove();
                    }
                });
            }
        }
    });
    jQuery(document).on("click",".jsLivePostDivEditing > .fa-pencil-square-o",function(){
        
        var match_id = jQuery("#match_id").val();
        var recordID = jQuery(this).parent().attr("jsdata");
        jQuery("#edit_record").val(recordID);
        var curDiv = jQuery(this).parent().parent();
        if(recordID){
            jQuery.ajax({
                url: jsLiveSiteLink + "index.php?option=com_joomsport&task=getRecord&tmpl=component&no_html=1&controller=journalist&match_id="+match_id,
                type: 'POST',
                data: {rid: recordID},
            }).done(function(res) {
                var IS_JSON = true;
            
                try
                {
                    var json = JSON.parse(res);
                }
                catch(err)
                {
                    IS_JSON = false;
                } 
                if(IS_JSON){
                    if(json.postIcon){
                        jQuery("#e_img_edit").val(json.postIcon);
                        jQuery("#e_img_edit").trigger('change');
                    }
                    if(json.minutes){
                        jQuery("#js_live_post_time_edit").val(json.minutes);
                        
                    }
                    if(json.options){
                        var jsonOptions = JSON.parse(json.options);
                        if(jsonOptions.twitter){
                            jQuery("#js_live_twitter_edit").val(jsonOptions.twitter);
                        }
                        if(jsonOptions.facebook){
                            jQuery("#js_live_fb_edit").val(jsonOptions.facebook);
                        }
                    }
                    if(json.eventObj){
                        var jsonOptions = JSON.parse(json.eventObj);
                        if(jsonOptions.e_id){
                            jQuery("#event_id_edit").val(jsonOptions.e_id);
                            jQuery("#event_id_edit").trigger('change');
                            
                            jQuery("#playerz_id_edit").val(jsonOptions.player_id+'*'+jsonOptions.t_id+'*'+jsonOptions.t_id);
                            jQuery("#playerz_id_edit").trigger('change');
                        }
                    }
                    if(json.eventSubObj){
                        console.log(json.eventSubObj);
                        var jsonOptions = JSON.parse(json.eventSubObj);
                        var Values = new Array();

                        for(var i=0;i<jsonOptions.length;i++){
                            Values.push(jsonOptions[i].player_id+'*'+jsonOptions[i].t_id+'*'+jsonOptions[i].t_id);
                            
                        }
                        if(Values.length){
                            jQuery("#spanSubEventEdit").show();
                        }
                        jQuery("#playerzEditSub_id").val(Values).trigger('change');
                    }
                    if(json.subsObj){
                        var jsonOptions = JSON.parse(json.subsObj);
                        if(jsonOptions.team_id){
                            jQuery("#teamsq_id_edit").val(jsonOptions.team_id);
                            jQuery("#teamsq_id_edit").trigger('change',[jsonOptions.player_in,jsonOptions.player_out]);
                            /*console.log(jQuery("#jslive_subs_in_edit").val());
                            jQuery("#jslive_subs_in_edit").val(jsonOptions.player_in);
                                jQuery("#jslive_subs_in_edit").trigger('change');
                                console.log(jQuery("#jslive_subs_in_edit").val());
                                jQuery("#jslive_subs_out_edit").val(jsonOptions.player_out);
                                jQuery("#jslive_subs_out_edit").trigger('change');   */
                                
                            /*jQuery("#teamsq_id_edit").trigger('change', [function(){
                                jQuery("#jslive_subs_in_edit").val(jsonOptions.player_in);
                                jQuery("#jslive_subs_in_edit").trigger('change');

                                jQuery("#jslive_subs_out_edit").val(jsonOptions.player_out);
                                jQuery("#jslive_subs_out_edit").trigger('change');    
                            }, jsonOptions.id]);*/
                            
                            
                            
                        }
                    }
                    if(json.postText){
                        //console.log(json.postText);
                        var matches = json.postText.match(/<div\s+class="jsPostText">([\S\s]+)<div\s+class="jsclear"><\/div><\/div>/);
                        //console.log(matches);
                        if(matches){
                            if (matches[1]) {
                                tinyMCE.get('live_post_edit').execCommand('mceInsertContent', false, matches[1]);
                                
                            }
                        }
                    }
                    
                    jQuery("#jsdiv_fill_editpost").modal("show");
                }
                
            });
            
        }
        
    });
    
    jQuery("#js_save_editpost").on("click", function(){
        //jQuery('#modalAj').show();
        var match_id = jQuery("#match_id").val();
        var recordID = jQuery("#edit_record").val();
        jQuery("#live_post_edit").val(tinyMCE.get('live_post_edit').getContent());
        
        
        if(recordID){
            jQuery.ajax({
                url: jsLiveSiteLink + "index.php?option=com_joomsport&task=editPost&tmpl=component&no_html=1&controller=journalist&match_id="+match_id,
                type: 'POST',
                data: jQuery("#jspostFormEdit").serialize(),
            }).done(function(res) {
                var IS_JSON = true;

                try
                {
                    var json = JSON.parse(res);
                }
                catch(err)
                {
                    IS_JSON = false;
                } 
                if(IS_JSON){

                    if(json.error == '0'){
                        var div = jQuery(".jsLivePostDiv").find("div[jsdata='"+recordID+"']").parent();
                        div.html(json.html);
                        //console.log(div);
                        //jQuery("#js_live_post_container").prepend(json.html);

                    }
                }

                jQuery("#jspostFormEdit").get(0).reset();
                jQuery("#event_id_edit").select2();
                jQuery("#playerz_id_edit").select2();
                jQuery("#e_img_edit").select2();
                jQuery("#jslive_icon_img_edit").attr("src",jsLiveSiteLink+'media/system/images/blank.png');

                jQuery("#teamsq_id_edit").select2();
                jQuery("#js_live_subsdd_edit").html('');
                FB.XFBML.parse();
                jQuery("#jsdiv_fill_editpost").modal("hide");
                //jQuery('#modalAj').hide();
            });
        }
    });
    
    
    
    js_live_interval_guest = setInterval(jsLiveCheckUpdts, 60000);
    
    var d_jsLUP = new Date();
    var jslive_last_upd = d_jsLUP.toUTCString();
    
});

function jsGetSubEvent(subDiv){
    var event_id = jQuery("#event_id").val();
    jQuery.ajax({
        url: jsLiveSiteLink + "index.php?option=com_joomsport&task=getSubEvents&tmpl=component&no_html=1&controller=journalist",
        type: 'POST',
        data: {"event_id" : event_id}
    }).done(function(res) {
        //jQuery("#"+subDiv).html(res);
        var jsOn = jQuery.parseJSON(res);
        jQuery("#"+subDiv).hide();
        if(jsOn && jsOn.name && jsOn.id){
            jQuery("#"+subDiv+"Title").html(jsOn.name+'<input type="hidden" name="sub_ev_id" value="'+jsOn.id+'" />');
            jQuery("#"+subDiv).show();
            //jQuery("#subeventid").val(jsOn.id);
        }
    });
}

function jsGetSubEventEdit(subDiv){
    var event_id = jQuery("#event_id_edit").val();
    jQuery.ajax({
        url: jsLiveSiteLink + "index.php?option=com_joomsport&task=getSubEvents&tmpl=component&no_html=1&controller=journalist",
        type: 'POST',
        data: {"event_id" : event_id}
    }).done(function(res) {
        //jQuery("#"+subDiv).html(res);
        var jsOn = jQuery.parseJSON(res);
        jQuery("#"+subDiv).hide();
        if(jsOn && jsOn.name && jsOn.id){
            jQuery("#"+subDiv+"Title").html(jsOn.name+'<input type="hidden" name="sub_ev_id_edit" value="'+jsOn.id+'" />');
            jQuery("#"+subDiv).show();
            //jQuery("#subeventid").val(jsOn.id);
        }
    });
}