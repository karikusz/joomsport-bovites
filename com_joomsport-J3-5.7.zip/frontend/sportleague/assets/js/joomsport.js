function delCom(num){
    jQuery.post(
        'index.php?tmpl=component&option=com_joomsport&controller=users&task=del_comment&format=row&cid='+num,
        function( result ) { 
            if(result){
                alert(result);
            } else {
                var d = document.getElementById('divcomb_'+num).parentNode;
                d.removeChild(jQuery('#divcomb_'+num).get(0));
            }
        });
}


function componentPopup(){
    var href = window.location.href;
    var regex = new RegExp("[&\\?]" + name + "=");

    if(href.indexOf("tmpl=component") > -1){
        window.print();
    }

    if(href.indexOf("?") > -1)
      var hrefnew = href + "&tmpl=component";
  else
      var hrefnew = href + "?tmpl=component";

  window.open(hrefnew,'jsmywindow','width=750,height=700,scrollbars=1,resizable=1');

}

function fSubmitwTab(e){
    if(jQuery('#joomsport-container').find('div.tabs').find('li.active').find('a').attr('href')){
        jQuery('input[name="jscurtab"]').val(jQuery('#joomsport-container').find('div.tabs').find('li.active').find('a').attr('href'));
    }
    e.form.submit();
}

jQuery(document).ready(function(){
   jQuery('#comForm').on('submit', function(e) {
    e.preventDefault();
    if(jQuery('#addcomm').val()){
        var submcom = jQuery('#submcom').get(0);
            //submcom.disabled = true;
            jQuery.ajax({
                url: jQuery('#comForm').attr('action'),
                type: "post",
                data: jQuery('#comForm').serialize(),
                success: function(result){

                    if(result){
                        result = JSON.parse(result);
                        if(result.error){
                            alert(result.error);
                        }else
                        if(result.id){
                            var li = jQuery("<li>");
                            li.attr("id", 'divcomb_'+result.id);

                            var div = jQuery("<div>");
                            div.attr("class", "comments-box-inner");
                            var divInner = jQuery("<div>");
                            divInner.attr("class","jsOverflowHidden");
                            divInner.css("position", "relative");
                            divInner.appendTo(div);
                            jQuery('<div class="date">'+result.datetime+' '+result.delimg+'</div>').appendTo(divInner);
                            //jQuery(result.photo).appendTo(divInner);

                            jQuery('<h4 class="nickname">'+result.name+'</h4>').appendTo(divInner);
                            jQuery('<div class="jsCommentBox">'+result.posted+'</div>').appendTo(div);
                            div.appendTo(li);
                            li.appendTo("#all_comments");
                            //var allc = jQuery('#all_comments').get(0);
                            //allc.innerHTML = allc.innerHTML + result;

                            submcom.disabled = false;
                            jQuery('#addcomm').val('');
                        }

                    }
                    jQuery('#comForm').get(0).reset();
                }
            });
        }
    });
   jQuery('div[class^="knockplName knockHover"]').hover(
    function(){
        var hclass = jQuery(this).attr("class");
        var tbody = jQuery(this).closest('tbody');

        tbody.find('[class^="knockplName knockHover"]').each(function(){
            if(jQuery(this).hasClass(hclass)){
                jQuery(this).addClass("knIsHover");
            }
        });
            //console.log('div.'+hclass);
            //jQuery('div.'+hclass).addClass("knIsHover");
        },
        function(){
            var tbody = jQuery(this).closest('tbody');
            tbody.find('[class^="knockplName knockHover"]').each(function(){
                if(jQuery(this).hasClass("knIsHover")){
                    jQuery(this).removeClass("knIsHover");
                }
            });
        }
        );

   jQuery("#aSearchFieldset").on("click",function(){
    if(jQuery("#jsFilterMatches").css("display") == 'none'){
        jQuery("#jsFilterMatches").css("display","block");
    }else{
        jQuery("#jsFilterMatches").css("display","none");
    }
});
   jQuery('#joomsport-container select').select2({minimumResultsForSearch: 20});
   //jQuery('#playerzSub_id').chosen({disable_search_threshold: 10});
   //jQuery('#playerzSub_id').select2('disable');

   var $select = jQuery('#mapformat select').select2();
    //console.log($select);
    $select.each(function(i,item){
      //console.log(item);
      jQuery(item).select2("destroy");
  });
  
});
jQuery(window).on('load',function() {
    var maxwidth = 200;
    var maxheight = 200;
    var maxheightWC = 200;
    
    var divwidth = jQuery('#jsPlayerListContainer').parent().width();
    var cols = Math.floor(parseInt(divwidth)/255);
    if(!cols){
        cols = 1;
    }

    var widthCols = Math.round(100/cols);
    var widthColsPix = Math.round(divwidth/cols);
    
    jQuery('.jsplayerCart').css({'width': widthCols+'%'});
    //jQuery('.jsplayerCart').width(parseInt(widthCols)+'%');
    
    jQuery('.imgPlayerCart').each(function(){
        //console.log(jQuery(this).find('img').prop('naturalHeight'));
        if(jQuery(this).find('img').prop('naturalWidth') > maxwidth){
            maxwidth = jQuery(this).find('img').prop('naturalWidth');
        }
        var widthNatural = parseInt(jQuery(this).find('img').prop('naturalWidth'));
        if(widthNatural < widthColsPix){
            coeff = 1;
        }else{
            if(widthNatural > 0){
                var coeff = (widthColsPix/(widthNatural+32));
            }else{
                coeff = 1;
            }
        }
        
        if(jQuery(this).find('img').prop('naturalHeight') > maxheight){
            maxheight = jQuery(this).find('img').prop('naturalHeight');
            maxheightWC = maxheight*coeff;
            // console.log(widthColsPix+':'+widthNatural);
            // console.log(maxheight+':'+coeff+':'+maxheightWC);
        }
    });
    //jQuery('.imgPlayerCart').width(maxwidth);
    jQuery('.imgPlayerCart').height(maxheightWC);
    jQuery('.imgPlayerCart > .innerjsplayerCart').height(maxheightWC);
});

function jsToggleTH() {
    jQuery('table[id^="jstable_"] th').each( function(){
        var alternate = true;
        jQuery(this).click(function() {
            jQuery(this).find("span").each(function() {
                if (alternate) { var shrtname = jQuery(this).attr("jsattr-full"); var text = jQuery(this).text(shrtname); } else { var shrtname = jQuery(this).attr("jsattr-short"); var text = jQuery(this).text(shrtname); }
            });
            alternate = !alternate;
        });	
    });
}
function JSwindowSize() {
    jQuery('table[id^="jstable_"]').each( function() {
        var conths = jQuery(this).parent().width();
        var thswdth = jQuery(this).find('th');
        var scrlths = 0;
        thswdth.each(function(){ scrlths+=jQuery(this)[0].getBoundingClientRect().width; });
        jQuery(this).find("span").each(function() {
            if (scrlths.toFixed(1) > conths) { var shrtname = jQuery(this).attr("jsattr-short"); var text = jQuery(this).text(shrtname).addClass("short"); return jsToggleTH(); }
        });
    });
    jQuery('#joomsport-container .page-content .tabs > ul.nav').each( function() {
        var jstabsul = jQuery(this).width();
        var jstabsli = jQuery(this).find('li');
        var jstabssum = 0;
        jstabsli.each(function(){ jstabssum+=jQuery(this).innerWidth(); });
        if (jstabssum > jstabsul) {jstabsli.addClass('jsmintab');}
    });
}
jQuery(window).on('load',JSwindowSize);

function jsCutRosterNames(){
    jQuery('.PlayerCardFIO > .js_div_particName').each(function(){
        var jsOuterHeight = jQuery(this).outerHeight(),
        jsLineHeight = parseInt(jQuery(this).css('line-height')),
        jsLinesInDiv = (jsOuterHeight/jsLineHeight).toFixed(),
        jsPlayerName = jQuery(this).text();

        if (jsLinesInDiv > 2) {
            jQuery(this).text(jsPlayerName.slice(0, 20) + '...');
        }
    });
}

function jsTabsSimulation(tabelement, tabcontent){
    jQuery(tabelement).on("click", function(){
        var id = jQuery(this).attr('data-tab'),
        content = jQuery(tabcontent+'[data-tab="'+ id +'"]');

        jQuery(tabelement+'.jsactive').removeClass('jsactive');
        jQuery(this).addClass('jsactive');

        jQuery(tabcontent+'.jsactive').removeClass('jsactive');
        content.addClass('jsactive');
    });
}

jQuery(document).ready(function(){
    jQuery('#joomsport-container a[href="#stab_players"]').on("click", function(){
        setTimeout(jsCutRosterNames, 200);
    });

    jQuery('#joomsport-container a[href="#stab_main"]').on("click", function(){
        jQuery(window).trigger('resize');
    });

    jsTabsSimulation('.jsMatchStatTeams .jsMatchTeam', '.jsSquadContent > div');
    jsTabsSimulation('.jsMatchStatTeams .jsMatchTeam', '.jsHHSeasonAnalytics .jspBlockSection > div');
});

// Front-end buttons
jQuery(document).ready(function(){
    jQuery('a[data-toggle="tab"]').on('shown.bs.tab', function (e) {
        jQuery(window).trigger('resize');
      });
    jQuery('.jsFEedit .squardbut label:not(.active)').click(function() {
        var label = jQuery(this);
        var input = jQuery('#' + label.attr('for'));

                //console.log(input.prop('checked'));
                if (!input.prop('checked')) {
                    //console.log(input.val());
                    label.closest('.btn-group-js').find('label').removeClass('active btn-success btn-danger btn-primary btn-warning');
                    if (input.val() == '') {
                        label.addClass('active btn-primary');
                    } else if (input.val() == 0) {
                        label.addClass('active btn-danger');
                    } else if (input.val() == '2'){

                        label.addClass('active btn-warning');

                    } else {
                        label.addClass('active btn-success');
                    }
                    input.prop('checked', true);
                    input.trigger('change');

                }
            });
    jQuery('.jsFEedit .btn-group-js input[checked=checked]').each(function() {
        if (jQuery(this).val() == '') {
            jQuery('label[for=' + jQuery(this).attr('id') + ']').addClass('active btn-primary');
        } else if (jQuery(this).val() == 0) {
            jQuery('label[for=' + jQuery(this).attr('id') + ']').addClass('active btn-danger');
        } else if (jQuery(this).val() == 2) {
            jQuery('label[for=' + jQuery(this).attr('id') + ']').addClass('active btn-warning');

        } else {
            jQuery('label[for=' + jQuery(this).attr('id') + ']').addClass('active btn-success');
        }
    });
    jQuery(".jspBlockTitle").on("click", function(){
        if(jQuery(this).next().hasClass("jsHHide")){
            jQuery(this).next().removeClass("jsHHide");
        }else{
            jQuery(this).next().addClass("jsHHide");
        }

        if(jQuery(this).children('i').hasClass('fa-chevron-up')){
            jQuery(this).children('i').removeClass('fa-chevron-up').addClass('fa-chevron-down');
        } else {
            jQuery(this).children('i').removeClass('fa-chevron-down').addClass('fa-chevron-up');
        }
    });

});
jQuery(window).load(function() {
    jQuery('#joomsport-container .btn-group-js.t3onoff').removeClass('t3onoff');
});

function calcJSTl(stepJSD,hm,aw){
           var same_minutes = [];
           for(var i=0; i<hm.length; i++){
                //var hmJS = jQuery.parseJSON(hm[i].obj);
                var imgEv = hm[i].objEvent.object.e_img;
                if(imgEv){
                    var img = jsLiveEvPath+imgEv;
                    
                    if(parseInt(hm[i].minutes) >= 1){  
                        var additevent = '';
                        if(hm[i].plFM){
                            additevent = "<br />("+hm[i].subEn+": "+hm[i].plFM+")";
                        }  
                        
                        var tooltip = '<span calss="tooltip-inner"><span>'+hm[i].minutes+'\'</span><span><img src="'+img+'" width="16"></span><span>'+hm[i].obj.object.first_name+' '+hm[i].obj.object.last_name+additevent+'</span></span>'; 
                    
                        var dv = jQuery('<div />', {
                         "class": 'jsTLEvent',
                         text: ""});
                         dv.css("left",parseInt(hm[i].minutes)*stepJSD-11);
                         if(same_minutes[parseInt(hm[i].minutes)]){
                             dv.css('bottom',29*same_minutes[parseInt(hm[i].minutes)]);
                         }
                         var dvimg = jQuery('<div />',{"class": 'jsTLEventInner'});
                            
                         dvimg.append(jQuery('<img />', {
                        "class": "jsImgTL",    
                        "src": img,
                        "data-html":"true",
                            "data-toggle2":"tooltipJSF",
                            "data-placement":"top",
                            "title":"",
                            "data-original-title":tooltip
                        }));
                    
                         dv.append(dvimg);
                         dv.append(jQuery('<div />', {
                         "class": 'tlArrow'}));
                        jQuery('#jsTimeLineDivHome').append(dv);
                        if(!same_minutes[parseInt(hm[i].minutes)]){
                            same_minutes[parseInt(hm[i].minutes)] = 1;
                        }else{
                             same_minutes[parseInt(hm[i].minutes)] = parseInt(same_minutes[parseInt(hm[i].minutes)])+1;
                        } 
                    } 
                }
            }
            var same_minutes = [];
            for(var i=0; i<aw.length; i++){
                var imgEv = aw[i].objEvent.object.e_img;
                if(imgEv){
                
                    var img = jsLiveEvPath+imgEv;
                    if(parseInt(aw[i].minutes) >= 1){
                        var additevent = '';
                        if(aw[i].plFM){
                            additevent = "<br />("+aw[i].subEn+": "+aw[i].plFM+")";
                        }    
                        var tooltip = '<span calss="tooltip-inner"><span>'+aw[i].minutes+'\'</span><span><img src="'+img+'" width="16"></span><span>'+aw[i].obj.object.first_name+' '+aw[i].obj.object.last_name+additevent+'</span></span>'; 
                    
                        var dv = jQuery('<div />', {
                         "class": 'jsTLEvent',
                         text: ""});
                         dv.css("left",parseInt(aw[i].minutes)*stepJSD-11);
                         dv.append(jQuery('<div />', {
                         "class": 'tlArrow'}));
                         if(same_minutes[parseInt(aw[i].minutes)]){
                             dv.css('top',29*same_minutes[parseInt(aw[i].minutes)]);
                         } 
                         var dvimg = jQuery('<div />',{"class": 'jsTLEventInner'});
                         dvimg.append(jQuery('<img />', {
                        "class": "jsImgTL",    
                        "src": img,
                            "data-html":"true",
                            "data-toggle2":"tooltipJSF",
                            "data-placement":"bottom",
                            "title":"",
                            "data-original-title":tooltip
                        }));
                         dv.append(dvimg);
                        jQuery('#jsTimeLineDivAway').append(dv);
                        
                        if(!same_minutes[parseInt(aw[i].minutes)]){
                            same_minutes[parseInt(aw[i].minutes)] = 1;
                        }else{
                             same_minutes[parseInt(aw[i].minutes)] = parseInt(same_minutes[parseInt(aw[i].minutes)])+1;
                        } 
                    } 
                }    
            }
       }

function jspTabs(t, i){
    var par = jQuery(t).closest(".centrikLDW");
    par.find("a").removeClass("jsTabActive");
    jQuery(t).addClass("jsTabActive");
    console.log(jQuery(t));
    par.find('.centrikLDWinnerContainer').hide();
    jQuery("#centrikLDWinnerContainer" + i).show();

    par.parent().find('.divLastMatches').hide();
    par.parent().find(".divLastMatches" + i).show();

}
function jspTabsMajor(t, i){
    var par = jQuery(t).closest(".centrikLDW");
    par.find("a").removeClass("jsTabActive");
    jQuery(t).addClass("jsTabActive");
    par.parent().find('.evTblforTabs').hide();
    jQuery(".evTbl" + i).show();

}

function jspDrowPie(circle, away, home){

    console.log(away);

    var degree = away >= 90? 0: 90 - away;
    jQuery("#"+circle).append('<div class="arc arcR1" style="transform: rotate(90deg) skewX('+degree+'deg);"></div>');
    jQuery('<style>#'+circle+' .arcR1:before{transform: skewX(-'+degree+'deg);}</style>').appendTo('head');

    if( away > 90){
        var degree = away >= 180 ? 0 : 180 - away;

        jQuery("#"+circle).append('<div class="arc arcR2" style="transform: rotate(180deg) skewX('+degree+'deg);"></div>');
        jQuery('<style>#'+circle+' .arcR2:before{transform: skewX(-'+degree+'deg);}</style>').appendTo('head');

        if( away > 180){
            var degree = away >= 270 ? 0 : 270 - away;

            jQuery("#"+circle).append('<div class="arc arcR3" style="transform: rotate(270deg) skewX('+degree+'deg);"></div>');
            jQuery('<style>#'+circle+' .arcR3:before{transform: skewX(-'+degree+'deg);}</style>').appendTo('head');
        }
        if( away > 270){
            var degree = away >= 360 ? 0 : 360 - away;

            jQuery("#"+circle).append('<div class="arc arcR4" style="transform: rotate(0deg) skewX('+degree+'deg);"></div>');
            jQuery('<style>#'+circle+' .arcR4:before{transform: skewX(-'+degree+'deg);}</style>').appendTo('head');
        }

    }



    var degree = home >= 90? 0: 90 - home;
    jQuery("#"+circle).append('<div class="arc2 arcL1" style="transform: rotate('+degree+'deg) skewX('+degree+'deg);"></div>');
    jQuery('<style>#'+circle+' .arcL1:before{transform: skewX(-'+degree+'deg);}</style>').appendTo('head');

    if( home > 90){
        var degree = home >= 180 ? 90 : home - 90;

        jQuery("#"+circle).append('<div class="arc2 arcL2" style="transform: rotate('+(360-degree)+'deg) skewX('+(90-degree)+'deg);"></div>');
        jQuery('<style>#'+circle+' .arcL2:before{transform: skewX(-'+(90-degree)+'deg);}</style>').appendTo('head');

        if( home > 180){
            var degree = home >= 270 ? 90 : home - 180;

            jQuery("#"+circle).append('<div class="arc2 arcL3" style="transform: rotate('+(270-degree)+'deg) skewX('+(90-degree)+'deg);"></div>');
            jQuery('<style>#'+circle+' .arcL3:before{transform: skewX(-'+(90-degree)+'deg);}</style>').appendTo('head');
        }
        if( home > 270){
            var degree = home >= 360 ? 90 : home - 270;

            jQuery("#"+circle).append('<div class="arc2 arcL4" style="transform: rotate('+(180-degree)+'deg) skewX('+(90-degree)+'deg);"></div>');
            jQuery('<style>#'+circle+' .arcL4:before{transform: skewX(-'+(90-degree)+'deg);}</style>').appendTo('head');
        }

    }
}
       
jQuery(window).load(function() {
    jQuery( ".jsHHMatchDiv .jstooltipJSF" ).tooltip( "destroy" );
});

jQuery(document).ready(function(){
    jQuery(".teamViewBlock").on("click",".nav-link",function(){
        var tabs = jQuery(this).closest(".nav-tabs");
        tabs.find(".nav-item").removeClass('active');
        jQuery(this).parent().addClass('active');
    });

    jQuery('div.jsMatchTT').tooltip({
        delay: 50,
        placement: "bottom",
        title: getMatchDetails,
        html: true
    });
    function getMatchDetails(){
        var id = this.id;
        var split_id = id.split('_');
        var match_id = split_id[1];

        var tooltipText = "";

        jQuery.ajax({
            url: jsLiveSiteLink + "index.php?option=com_joomsport&task=getMatchStat&tmpl=component&no_html=1",
            type: 'POST',
            async: false,
            data: {match_id:match_id},
            success: function(response){
                tooltipText = response;

            }
        });
        return tooltipText;
    }
});