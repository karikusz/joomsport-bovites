<?php
/*------------------------------------------------------------------------
# JoomSport Professional 
# ------------------------------------------------------------------------
# BearDev development company 
# Copyright (C) 2011 JoomSport.com. All Rights Reserved.
# @license - http://joomsport.com/news/license.html GNU/GPL
# Websites: http://www.JoomSport.com 
# Technical Support:  Forum - http://joomsport.com/helpdesk/
-------------------------------------------------------------------------*/
// no direct access
defined('_JEXEC') or die;


class classJsportRequest
{
    public static function get($var, $request = 'default', $type = 'string')
    {
        $return = JRequest::getVar($var, '', $request);

        switch ($type) { case 'int': $return = intval($return); break; case 'float': $return = floatval($return); break; }

        return $return;
    }
}