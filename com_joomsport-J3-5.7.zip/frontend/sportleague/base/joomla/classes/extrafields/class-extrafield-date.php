<?php
/*------------------------------------------------------------------------
# JoomSport Professional 
# ------------------------------------------------------------------------
# BearDev development company 
# Copyright (C) 2011 JoomSport.com. All Rights Reserved.
# @license - http://joomsport.com/news/license.html GNU/GPL
# Websites: http://www.JoomSport.com 
# Technical Support:  Forum - http://joomsport.com/helpdesk/
-------------------------------------------------------------------------*/
// no direct access
defined('_JEXEC') or die;

class classExtrafieldDate
{
    public static function getValue($ef)
    {
        $options = json_decode($ef->options,true);
        
        $dateage = 0;
        if(isset($options['dateage'])){
            $dateage = intval($options['dateage']);
        }
               
        if($ef->fvalue && $ef->fvalue != '0000-00-00 00:00:00'){
            switch ($dateage) {
                case '1':
                    return self::calcAge($ef->fvalue);

                    break;
                case '2':
                    return classJsportDate::getDate($ef->fvalue,'').' ('.self::calcAge($ef->fvalue).')';

                    break;

                default:
                    return classJsportDate::getDate($ef->fvalue,'');
                    break;
            }
            
        }
        return '';
    }
    public static function calcAge($ef){
        return intval(date('Y', time() - strtotime($ef))) - 1970;
    }
}
