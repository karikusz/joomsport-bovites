<?php
/*------------------------------------------------------------------------
# JoomSport Professional 
# ------------------------------------------------------------------------
# BearDev development company 
# Copyright (C) 2011 JoomSport.com. All Rights Reserved.
# @license - http://joomsport.com/news/license.html GNU/GPL
# Websites: http://www.JoomSport.com 
# Technical Support:  Forum - http://joomsport.com/helpdesk/
-------------------------------------------------------------------------*/
// no direct access
defined('_JEXEC') or die;


class classExtrafieldLink
{
    public static function getValue($ef)
    {
        $html = '';
        if ($ef->fvalue) {
            //var_dump(preg_match('/https?:\\//', $ef->fvalue));die();
            $html = "<a target='_blank' href='".(preg_match('/https?:\\//', $ef->fvalue) ? $ef->fvalue : 'http://'.$ef->fvalue)."'>".$ef->fvalue.'</a>';
        }

        return $html;
    }
}
