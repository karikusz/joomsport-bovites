<?php
/*------------------------------------------------------------------------
# JoomSport Professional 
# ------------------------------------------------------------------------
# BearDev development company 
# Copyright (C) 2011 JoomSport.com. All Rights Reserved.
# @license - http://joomsport.com/news/license.html GNU/GPL
# Websites: http://www.JoomSport.com 
# Technical Support:  Forum - http://joomsport.com/helpdesk/
-------------------------------------------------------------------------*/
// no direct access
defined('_JEXEC') or die;


require_once JS_PATH_OBJECTS.'class-jsport-season.php';
require_once JS_PATH_MODELS.'model-jsport-season.php';
require_once JPATH_ROOT.'/components/com_joomsport/helpers/js-helper-stages.php';
class modelJsportMatch
{
    public $match_id = null;
    public $lists = null;
    public $row = null;
    public $season = null;

    public function __construct($match_id)
    {
        $this->match_id = $match_id;

        if (!$this->match_id) {
            die('ERROR! Match ID not DEFINED');
        }
        $this->loadObject();
    }
    private function loadObject()
    {
        global $jsDatabase;
        $this->row = $jsDatabase->selectObject('SELECT m.*,md.m_name '
                .'FROM '.DB_TBL_MATCH.' as m'
                .' JOIN '.DB_TBL_MATCHDAY.' as md ON m.m_id = md.id'
                .' WHERE m.id = '.$this->match_id);
        $this->row->match_descr = classJsportTranslation::get('match_'.$this->row->id, 'match_descr',$this->row->match_descr);
    }
    public function getSeasonID()
    {
        global $jsDatabase;

        $season_id = $jsDatabase->selectValue('SELECT s_id '
                .'FROM '.DB_TBL_MATCHDAY
                .' WHERE id = "'.$this->row->m_id.'"');


        return $season_id;
    }

    public function loadLists()
    {
        $this->lists['ef'] = classJsportExtrafields::getExtraFieldList($this->match_id, '2', 0);

        $season_id = $this->getSeasonID();
        if ($season_id > 0) {
            $sObj = new modelJsportSeason($season_id);
            $single = $sObj->getSingle();
        } else {
            $single = $this->row->m_single;
        }
        $this->lists["single"] = $single;

        $this->getPhotos();
        $this->getPlayerEvents();
        $this->getTeamEvents();
        $this->getLineUps();
        $this->getMaps();
    }
    public function loadListsLiveMatch(){
        global $jsDatabase;
        
        require_once JS_PATH_OBJECTS.'class-jsport-player.php';
        require_once JS_PATH_OBJECTS.'class-jsport-event.php';
        
        //player events
        $is_event = array();
        $query = "SELECT * FROM #__bl_events WHERE player_event = '1' AND dependson='' ORDER BY e_name";
        
        $events = $jsDatabase->select($query);
        $is_event[] = JHTML::_('select.option',  0, JText::_('BLBE_SELEVENT'), 'id', 'e_name');
        if (count($events)) {
            
            for($intA=0;$intA<count($events);$intA++){
                $event_id = $events[$intA]->id;
                $eventObj = new classJsportEvent($event_id);
                $events[$intA]->e_name = $eventObj->getEventName();
            }
            
            $is_event = array_merge($is_event, $events);
        }
        $this->lists['events'] = JHTML::_('select.genericlist',   $is_event, 'event_id', 'class="inputbox chzn-done" size="1" style="width:170px;" onchange="jsGetSubEvent(\'spanSubEvent\');"', 'id', 'e_name', 0);
        $this->lists['events_edit'] = JHTML::_('select.genericlist',   $is_event, 'event_id_edit', 'class="inputbox chzn-done" size="1" style="width:170px;" onchange="jsGetSubEventEdit(\'spanSubEventEdit\');"', 'id', 'e_name', 0);
        
        //check for single
        $season_id = $this->getSeasonID();
        if ($season_id > 0) {
            $sObj = new modelJsportSeason($season_id);
            $single = $sObj->getSingle();
        } else {
            $single = $this->row->m_single;
        }
        $this->lists["single"] = $single;
        $team_1 = "";
        $team_2 = "";
        $obj = new classJsportParticipant($season_id, $this->row->m_single);
        if ($this->row->team1_id > 0) {
            $part = $obj->getParticipiantObj($this->row->team1_id);
            $team_1 = $part->getName(false);
        }   
        $obj = new classJsportParticipant($season_id, $this->row->m_single);
        if ($this->row->team2_id > 0) {
            $part = $obj->getParticipiantObj($this->row->team2_id);
            $team_2 = $part->getName(false);
        }  
        //players list
        $is_player = array();
        if ($single) {
            $is_player[] = JHTML::_('select.option',  0, JText::_('BLBE_SELPLAYER'), 'id', 'p_name');
            if ($this->row->team1_id != -1) {
                $is_player[] = JHTML::_('select.option',  $this->row->team1_id, $team_1, 'id', 'p_name');
            }
            if ($this->row->team2_id != -1) {
                $is_player[] = JHTML::_('select.option',  $this->row->team2_id, $team_2, 'id', 'p_name');
            }
            $ev_pl = $is_player;
            $this->lists['players'] = $this->lists['players_edit'] = JHTML::_('select.genericlist',   $ev_pl, 'playerz_id', 'class="chzn-done" size="1" style="width:190px;"', 'id', 'p_name', 0);
        } else {
            $query = "SELECT CONCAT(p.id,'*',s.team_id) as id,CONCAT(p.first_name,' ',p.last_name) as p_name,p.id as pid
			            FROM #__bl_players as p, #__bl_players_team as s
			            WHERE s.confirmed='0' AND s.player_join='0' AND s.player_id = p.id
			            AND s.team_id = ".$this->row->team1_id.' AND s.season_id='.$season_id
                        .' ORDER BY p.first_name,p.last_name';
            if ($season_id == -1) {
                $query = "SELECT DISTINCT(p.id),p.id as id,
				            CONCAT(p.first_name,' ',p.last_name) as p_name,p.id as pid
				            FROM #__bl_players as p, #__bl_players_team as s
				            WHERE s.confirmed='0' AND s.player_join='0' AND s.player_id = p.id
				            ORDER BY p.first_name,p.last_name";
            }
            

            $players_1 = $this->lists['team1_players'] = $jsDatabase->select($query);

       
            $query = "SELECT CONCAT(p.id,'*',s.team_id) as id,"
                        ." CONCAT(p.first_name,' ',p.last_name) as p_name,p.id as pid"
                        .' FROM #__bl_players as p, #__bl_players_team as s'
                        ." WHERE s.confirmed='0' AND s.player_join='0' AND s.player_id = p.id"
                        .' AND s.team_id = '.$this->row->team2_id.' AND s.season_id='.$season_id
                        .' ORDER BY p.first_name,p.last_name';
            if ($season_id == -1) {
                $query = 'SELECT DISTINCT(p.id),p.id as id,'
                        ." CONCAT(p.first_name,' ',p.last_name) as p_name,p.id as pid"
                        .' FROM #__bl_players as p, #__bl_players_team as s '
                        ." WHERE s.confirmed='0' AND s.player_join='0' AND s.player_id = p.id"
                        .' ORDER BY p.first_name,p.last_name';
            }


            $players_2 = $this->lists['team2_players'] = $jsDatabase->select($query);
        
            $is_player[] = JHTML::_('select.option',  0, JText::_('BLBE_SELPLAYER'), 'id', 'p_name');

            $is_player[] = JHTML::_('select.optgroup',  $team_1, 'id', 'p_name');

            $is_player2[] = JHTML::_('select.optgroup',  $team_2, 'id', 'p_name');
            
            $jqre = '';
            
            $jqre_new = '<select name="playerz_id" id="playerz_id" style="width:190px;" class="chzn-done" size="1">';
            $jqre_edit = '<select name="playerz_id_edit" id="playerz_id_edit" style="width:190px;" class="chzn-done" size="1">';
            $jqre .= '<option value="0">'.JText::_('BLBE_SELPLAYER').'</option>';
            $jqre .= '<optgroup label="'.$team_1.'">';
            for ($g = 0;$g < count($players_1);++$g) {
                $playerObj = new classJsportPlayer($players_1[$g]->pid,0);
                $players_1[$g]->p_name = $playerObj->getName(false);
                
                $jqre .= '<option value="'.$players_1[$g]->id.'*'.$this->row->team1_id.'">'.$players_1[$g]->p_name.'</option>';
            }
            $jqre .= '</optgroup>';
            $jqre .= '<optgroup label="'.$team_2.'">';
            for ($g = 0;$g < count($players_2);++$g) {
                $playerObj = new classJsportPlayer($players_2[$g]->pid,0);
                $players_2[$g]->p_name = $playerObj->getName(false);
                $jqre .= '<option value="'.$players_2[$g]->id.'*'.$this->row->team2_id.'">'.$players_2[$g]->p_name.'</option>';
            }
            $jqre .= '</optgroup>';
            $jqre .= '</select>';

            $this->lists['players'] = $jqre_new.$jqre;
            $this->lists['players_edit'] = $jqre_edit.$jqre;
            $jqreHd2 = '<select name="playerzSub_id[]" id="playerzSub_id" style="width:120px;" multiple class="chzn-done" size="1" data-placeholder="'.JText::_('BLBE_SELPLAYER').'">';
            $jqreHd3 = '<select name="playerzEditSub_id[]" id="playerzEditSub_id" style="width:120px;" multiple class="chzn-done" size="1" data-placeholder="'.JText::_('BLBE_SELPLAYER').'">';
            
            $this->lists['playersSub'] = $jqreHd2.$jqre;
            $this->lists['playersSubEdit'] = $jqreHd3.$jqre;
            
            $is_team[] = JHTML::_('select.option',  0, JText::_('BLBE_SELTEAM'), 'id', 'p_name');
            $is_team[] = JHTML::_('select.option',  $this->row->team1_id, $team_1, 'id', 'p_name');
            
            $is_team[] = JHTML::_('select.option',  $this->row->team2_id, $team_2, 'id', 'p_name');
            $this->lists['teams'] = JHTML::_('select.genericlist',   $is_team, 'teamsq_id', 'class="chzn-done" size="1" style="width:190px;"', 'id', 'p_name', 0);
            $this->lists['teams_edit'] = JHTML::_('select.genericlist',   $is_team, 'teamsq_id_edit', 'class="chzn-done" size="1" style="width:190px;"', 'id', 'p_name', 0);
         
        }
        
        //posts
        $query = "SELECT * FROM #__bl_liveposts WHERE match_id={$this->match_id} ORDER BY ordering desc";
        $this->lists['liveposts'] = $jsDatabase->select($query);
        
    }
    public function getPhotos()
    {
        global $jsDatabase;
        $query = 'SELECT p.ph_name as name,p.id as id,p.ph_filename as filename'
                .' FROM '.DB_TBL_ASSIGN_PHOTOS.' as ap, '.DB_TBL_PHOTOS.' as p'
                .' WHERE ap.photo_id = p.id AND cat_type = 3 AND cat_id = '.$this->match_id;

        $photos = $jsDatabase->select($query);
        $this->lists['photos'] = array();
        if (count($photos)) {
            foreach ($photos as $photo) {
                if (is_file(JS_PATH_IMAGES.$photo->filename)) {
                    $this->lists['photos'][] = $photo;
                }
            }
        }
    }

    public function getPlayerEvents()
    {
        global $jsDatabase, $jsConfig;
        
        $opposite_events = $jsConfig->get('opposite_events');
        if ($opposite_events) {
            $opposite_events = json_decode($opposite_events, true);
        } else {
            $opposite_events = array();
        }

        $season_id = $this->getSeasonID();
        if ($season_id > 0) {
            $sObj = new modelJsportSeason($season_id);
            $single = $sObj->getSingle();

            $this->lists['eventsByStage'] = jsHelperStages::getMatchEvents($this->match_id, $season_id);
            $this->lists['eventsNotByStage'] = jsHelperStages::getNotStageEvents($this->match_id, $this->lists['eventsByStage']);

        } else {
            $single = $this->row->m_single;
        }

        $query = "SELECT me.*,me.id as meid,ev.*,p.id as playerid,CONCAT(p.first_name,' ',p.last_name) as p_name"
                    .' FROM  #__bl_match_events as me'
                . ' JOIN #__bl_events as ev ON me.e_id = ev.id AND me.match_id = '.$this->match_id
                . ' JOIN #__bl_players as p ON me.player_id = p.id'
                    ." WHERE ev.player_event = '1' AND ev.dependson='' AND "
                .($single ? ('me.player_id='.intval($this->row->team1_id)) : (count($opposite_events)?('(ev.id NOT IN ('.implode(",", $opposite_events).') AND me.t_id='.intval($this->row->team1_id).') OR (ev.id IN ('.implode(",", $opposite_events).') AND me.t_id='.intval($this->row->team2_id).')'):'me.t_id='.intval($this->row->team1_id)))
                .' GROUP BY me.id'
                .' ORDER BY CAST(me.minutes AS UNSIGNED),me.eordering';
             

        $this->lists['m_events_home'] = $jsDatabase->select($query);


        $query = "SELECT me.*,ev.*,p.id as playerid,CONCAT(p.first_name,' ',p.last_name) as p_name"
                    .' FROM  #__bl_match_events as me'
                . ' JOIN #__bl_events as ev ON me.e_id = ev.id AND me.match_id = '.$this->match_id
                . ' JOIN #__bl_players as p ON me.player_id = p.id'
                    ." WHERE ev.player_event = '1' AND ev.dependson='' AND "
                .($single ? ('me.player_id='.intval($this->row->team2_id)) : (count($opposite_events)?('(ev.id NOT IN ('.implode(",", $opposite_events).') AND me.t_id='.intval($this->row->team2_id).') OR (ev.id IN ('.implode(",", $opposite_events).') AND me.t_id='.intval($this->row->team1_id).')'):'me.t_id='.intval($this->row->team2_id)))
                .' GROUP BY me.id'
                .' ORDER BY CAST(me.minutes AS UNSIGNED),me.eordering';

        $this->lists['m_events_away'] = $jsDatabase->select($query);

        
        $query = "SELECT me.*,ev.*,p.id as playerid,CONCAT(p.first_name,' ',p.last_name) as p_name"
                    .' FROM  #__bl_match_events as me'
                . ' JOIN #__bl_events as ev ON me.e_id = ev.id AND me.match_id = '.$this->match_id
                . ' JOIN #__bl_players as p ON me.player_id = p.id'
                    ." WHERE ev.player_event = '1' AND ev.dependson='' "
            . ' AND me.minutes != "0" AND me.minutes != ""'
                .' GROUP BY me.id'
                .' ORDER BY CAST(me.minutes AS UNSIGNED),me.eordering';

        $this->lists['m_events_all'] = $jsDatabase->select($query);
        $this->lists['m_events_display'] = 1;
        if(count($this->lists['m_events_all']) == count($this->lists['m_events_home'])+count($this->lists['m_events_away'])){
            $this->lists['m_events_display'] = 0;
        }
        

        
    }
    public function getTeamEvents()
    {
        global $jsDatabase;
        $season_id = $this->getSeasonID();
        if ($season_id > 0) {
            $sObj = new modelJsportSeason($season_id);
            $single = $sObj->getSingle();
        } else {
            $single = $this->row->m_single;
        }

        $query = 'SELECT DISTINCT ev.e_name as e_name, ev.*'
                .' FROM '.DB_TBL_MATCH_EVENTS.' as me,'
                        .' '.DB_TBL_EVENTS.' as ev,'
                        .' '.DB_TBL_TEAMS.' as p'
                        .' WHERE me.t_id = p.id AND me.t_id IN ( '.intval($this->row->team1_id).', '.intval($this->row->team2_id).')'
                        ." AND ev.player_event = '0' AND me.e_id = ev.id AND me.match_id = ".$this->match_id
                        .' ORDER BY ev.ordering,ev.e_name';

        $this->lists['team_events'] = $jsDatabase->select($query);

        for ($intA = 0; $intA < count($this->lists['team_events']); ++$intA) {
            $query = 'SELECT me.ecount'
                .' FROM '.DB_TBL_MATCH_EVENTS.' as me,'
                        .' '.DB_TBL_EVENTS.' as ev,'
                        .' '.DB_TBL_TEAMS.' as p'
                        .' WHERE me.t_id = p.id AND me.t_id = '.intval($this->row->team1_id).''
                        ." AND ev.player_event = '0' AND me.e_id = ev.id AND me.match_id = ".$this->match_id
                        .' AND ev.id = '.$this->lists['team_events'][$intA]->id
                        .' ORDER BY ev.ordering,ev.e_name';

            $this->lists['team_events'][$intA]->home_value = $jsDatabase->selectValue($query);

            $query = 'SELECT me.ecount'
                .' FROM '.DB_TBL_MATCH_EVENTS.' as me,'
                        .' '.DB_TBL_EVENTS.' as ev,'
                        .' '.DB_TBL_TEAMS.' as p'
                        .' WHERE me.t_id = p.id AND me.t_id = '.intval($this->row->team2_id).''
                        ." AND ev.player_event = '0' AND me.e_id = ev.id AND me.match_id = ".$this->match_id
                        .' AND ev.id = '.$this->lists['team_events'][$intA]->id
                        .' ORDER BY ev.ordering,ev.e_name';

            $this->lists['team_events'][$intA]->away_value = $jsDatabase->selectValue($query);
        }
    }
    public function getLineUps()
    {
        global $jsDatabase;
        $season_id = $this->getSeasonID();
        $ef = classJsportExtrafields::getExtraFieldListSQ(0);



        $query = "SELECT p.*,CONCAT(p.first_name,' ',p.last_name) as name,p.def_img,p.id as playerid,sb.player_out,sb.player_in,sb.minutes"
                .' FROM '.DB_TBL_PLAYERS.' as p'
                .' JOIN  '.DB_TBL_SQUARD.' as s ON p.id=s.player_id AND s.match_id='.$this->match_id
                                .' LEFT JOIN '.DB_TBL_SUBSIN.' as sb ON p.id=sb.player_out AND sb.match_id=s.match_id'
                                .' AND sb.team_id='.intval($this->row->team1_id)
                .' WHERE s.team_id='.intval($this->row->team1_id)." AND s.mainsquard = '1'"
                .' ORDER BY p.first_name,p.last_name';

        $this->lists['squard1'] = $this->sortLineUps($jsDatabase->select($query), $ef, $season_id, $this->row->team1_id);


        $query = "SELECT p.*,CONCAT(p.first_name,' ',p.last_name) as name,p.def_img,p.id as playerid,sb.player_out,sb.player_in,sb.minutes"
                .' FROM '.DB_TBL_PLAYERS.' as p'
                                .' JOIN  '.DB_TBL_SQUARD.' as s ON p.id=s.player_id AND s.match_id='.$this->match_id
                                .' LEFT JOIN '.DB_TBL_SUBSIN.' as sb ON p.id=sb.player_out AND sb.match_id=s.match_id'
                                .' AND sb.team_id='.intval($this->row->team2_id)
                .' WHERE s.team_id='.intval($this->row->team2_id)." AND s.mainsquard = '1'"
                .' ORDER BY p.first_name,p.last_name';

        $this->lists['squard2'] = $this->sortLineUps($jsDatabase->select($query), $ef, $season_id, $this->row->team2_id);

        $query = "SELECT p.*,CONCAT(p.first_name,' ',p.last_name) as name,p.def_img,p.id as playerid,sb.player_in,sb.minutes,sb2.minutes as sb2m,sb2.player_in as sb2in"
                .' FROM '.DB_TBL_PLAYERS.' as p'
                                .' JOIN  '.DB_TBL_SQUARD.' as s ON p.id=s.player_id AND s.match_id='.$this->match_id
                                .' LEFT JOIN '.DB_TBL_SUBSIN.' as sb ON p.id=sb.player_in AND sb.match_id=s.match_id'
                                .' LEFT JOIN '.DB_TBL_SUBSIN.' as sb2 ON p.id=sb2.player_out AND sb2.match_id=s.match_id'
                                .' AND sb.team_id='.intval($this->row->team1_id)
                .' WHERE s.team_id='.intval($this->row->team1_id)." AND s.mainsquard = '0'"
                .' ORDER BY p.first_name,p.last_name';

        $this->lists['squard1_res'] = $this->sortLineUps($jsDatabase->select($query), $ef, $season_id, $this->row->team1_id);

        $query = "SELECT p.*,CONCAT(p.first_name,' ',p.last_name) as name,p.def_img,p.id as playerid,sb.player_in,sb.minutes,sb2.minutes as sb2m,sb2.player_in as sb2in"
                .' FROM '.DB_TBL_PLAYERS.' as p'
                                .' JOIN  '.DB_TBL_SQUARD.' as s ON p.id=s.player_id AND s.match_id='.$this->match_id
                                .' LEFT JOIN '.DB_TBL_SUBSIN.' as sb ON p.id=sb.player_in AND sb.match_id=s.match_id'
                                .' LEFT JOIN '.DB_TBL_SUBSIN.' as sb2 ON p.id=sb2.player_out AND sb2.match_id=s.match_id'
                                .' AND sb.team_id='.intval($this->row->team2_id)
                .' WHERE s.team_id='.intval($this->row->team2_id)." AND s.mainsquard = '0'"
                .' ORDER BY p.first_name,p.last_name';

        $this->lists['squard2_res'] = $this->sortLineUps($jsDatabase->select($query), $ef, $season_id, $this->row->team2_id);
    }
    
    
    private function sortLineUps($list, $ef, $season_id, $team_id)
    {
        global $jsConfig;   
        global $jsDatabase;

        $jsmatch_squad_firstcol = $jsConfig->get('jsmatch_squad_firstcol');
        $jsmatch_squad_lastcol = $jsConfig->get('jsmatch_squad_lastcol');

        $count_players = count($list);
        $pl_list_order = $jsConfig->get('pllist_order_se');
        for ($intC = 0; $intC < $count_players; ++$intC) {
            for ($intB = 0; $intB < count($ef); ++$intB) {
                if('ef_'.$ef[$intB]->id.'_1' == 'ef_'.$pl_list_order){
                    $val = classJsportExtrafields::getExtraFieldValue($ef[$intB]->id, $list[$intC]->id, 0, $season_id);
                    if($val == null){
                        $list[$intC]->{'ef_'.$ef[$intB]->id.'_1'} = -1;
                    }else{
                        $query = 'SELECT DISTINCT(ef.id),ef.*,'
                                .'ev.fvalue as fvalue,ev.fvalue_text'
                                .' FROM '.DB_TBL_EXTRA_FILDS.' as ef'
                                .'  JOIN '.DB_TBL_EXTRA_VALUES.' as ev'
                                .' ON ef.id=ev.f_id'
                                .' AND ef.id = '.$ef[$intB]->id
                                .' AND ev.uid='.($list[$intC]->id ? intval($list[$intC]->id) : -1).''
                                .' AND ((ev.season_id='.($season_id > 0 ? $season_id : -100)." AND ef.season_related = '1') OR (ev.season_id=0 AND ef.season_related = '0'))"
                                ." WHERE ef.published=1 AND ef.type='0' ".(classJsportUser::getUserId() ? '' : " AND ef.faccess='0'").'';
                        $efObj = $jsDatabase->selectObject($query);
                        
                        $ordering = $jsDatabase->selectValue('SELECT eordering FROM '.DB_TBL_EXTRA_SELECT." WHERE id='".(int) $efObj->fvalue."'");
                        $list[$intC]->{'ef_'.$ef[$intB]->id.'_1'} = $ordering+1;
                    }
                }
                
            }
            $list[$intC]->efFirst = $list[$intC]->efLast = '';
            if($jsmatch_squad_firstcol > 0){
                $val = classJsportExtrafields::getExtraFieldValue($jsmatch_squad_firstcol, $list[$intC]->id, 0, $season_id);
                $list[$intC]->efFirst = $val;
            }elseif ($jsmatch_squad_firstcol == -1){
                $query = 'SELECT number'
                    .' FROM '.DB_TBL_PLAYERS_TEAM.''
                    ." WHERE player_id = {$list[$intC]->id}"
                    . " AND season_id = {$season_id}"
                    . " AND team_id = {$team_id}";

                $list[$intC]->efFirst = $jsDatabase->selectValue($query);
            }

            if($jsmatch_squad_lastcol > 0){
                $val = classJsportExtrafields::getExtraFieldValue($jsmatch_squad_lastcol, $list[$intC]->id, 0, $season_id);
                $list[$intC]->efLast = $val;
            }elseif ($jsmatch_squad_lastcol == -1){
                $query = 'SELECT number'
                    .' FROM '.DB_TBL_PLAYERS_TEAM.''
                    ." WHERE player_id = {$list[$intC]->id}"
                    . " AND season_id = {$season_id}"
                    . " AND team_id = {$team_id}";

                $list[$intC]->efLast = $jsDatabase->selectValue($query);
            }


        }
        
        
        if ($pl_list_order > 0){            
                      
            usort($list, array('modelJsportMatch' ,'eventSortSQ'));
        }
        
        return $list;
    }
    private function eventSortSQ($f1,$f2) {
                global $jsConfig;
                $pl_list_order = $jsConfig->get('pllist_order_se');
                try{
                    if (!$f1->{'ef_'.$pl_list_order} && $f2->{'ef_'.$pl_list_order}) {
                        return -1;
                    }
                    if ($f1->{'ef_'.$pl_list_order} && !$f2->{'ef_'.$pl_list_order}) {
                        return 1;
                    }

                    return strnatcmp($f1->{'ef_'.$pl_list_order}, $f2->{'ef_'.$pl_list_order});
                }catch(Exception $ex){
                    
                }
            }  
    
    public function getMaps()
    {
        global $jsDatabase;
        $season_id = $this->getSeasonID();

        $query = 'SELECT m.*,mp.m_score1,mp.m_score2'
                .' FROM '.DB_TBL_SEAS_MAPS.' as sm'
                .' JOIN '.DB_TBL_MAPS.' as m ON m.id=sm.map_id'
                .' LEFT JOIN '.DB_TBL_MAPSCORE.' as mp ON m.id=mp.map_id AND mp.m_id='.intval($this->match_id)
                .' WHERE m.id=sm.map_id AND sm.season_id='.intval($season_id).''
                .' ORDER BY m.id';
        $this->lists['maps'] = $jsDatabase->select($query);
    }
    public function getSeasonOptions()
    {
        global $jsDatabase;
        $season_id = $this->getSeasonID();

        $query = 'SELECT *'
                .' FROM '.DB_TBL_SEASONS.' as s'
                .' WHERE s.s_id='.intval($season_id);

        return $jsDatabase->selectObject($query);
    }

    public function getCustomMatch()
    {
        global $jsDatabase;
        $season_id = $this->getSeasonID();

        $query = 'SELECT *'
                .' FROM '.DB_TBL_MATCH_STATUSES
                .' WHERE id='.intval($this->row->m_played);

        return $jsDatabase->selectObject($query);
    }
    public function getBoxScore($home = true){
        global $jsDatabase,$jsConfig;

        $this->lists["boxheader1"] = array();
        $this->lists["boxheader2"] = array();
        
        $this->lists["boxbodyplayer"] = array();
        $this->lists["boxbody"] = array();
        $this->lists["boxtotal"] = array();
        
            $home_team = (int) $this->row->team1_id;
            $away_team = (int) $this->row->team2_id;
          
        $team_id = $home?$home_team:$away_team; 
        $query = "SELECT * FROM #__bl_box_fields"
                . " WHERE complex=0 AND published=1";
        $boxf = $jsDatabase->select($query);

        $checkfornull = '';
        for ($intA = 0; $intA < count($boxf); $intA++) {
            if ($boxf[$intA]->ftype == '1') {
                $options = json_decode($boxf[$intA]->options, true);
                if ($options['depend1'] && $options['depend2'] && ($options['depend1'] != 'totalMatches' && $options['depend2'] != 'totalMatches')) {
                    if ($checkfornull) {
                        $checkfornull .= ' OR ';
                }
                    $checkfornull .= ' ( boxfield_' . $options['depend1'] . ' IS NOT NULL ';
                    $checkfornull .= ' AND boxfield_' . $options['depend2'] . ' IS NOT NULL ) ';
            }
            } else {
                if ($checkfornull) {
                    $checkfornull .= ' OR ';
        }
                $checkfornull .= ' boxfield_' . $boxf[$intA]->id . ' IS NOT NULL';
            }
        }
        if($checkfornull){
            $query = "SELECT player_id FROM #__bl_box_matches"
                    ." WHERE match_id={$this->match_id} AND team_id = {$team_id}"
                    . " AND (".$checkfornull.")";
            $players = $jsDatabase->selectColumn($query);
            $html = '';
            if(count($players)){
                $html = $this->getBoxHtml($team_id, $players);
            }
            return $html;
        }
        return null;
    }
    
    public function getBoxHtml($home_team, $playersNotNull){
        global $jsConfig,$jsDatabase;
        $season_id = $this->getSeasonID();
        $efbox = (int) $jsConfig->get('boxExtraField','0');
        
        $html = '';
        $totalSQL = '';
        $bfields = $jsDatabase->select('SHOW COLUMNS FROM #__bl_box_matches LIKE  "boxfield_%"');
        
        for($intA=0;$intA<count($bfields);$intA++){
            $totalSQL .= 'SUM('.$bfields[$intA]->Field .') as '.$bfields[$intA]->Field.',';
        }
        if(!$totalSQL){
            $totalSQL = '*';
        }else{
            $totalSQL .= 'COUNT(DISTINCT match_id) AS `totalMatches`';
        }                
        
        $parentB = array();
        $complexBox = $jsDatabase->select('SELECT * FROM #__bl_box_fields WHERE parent_id="0" AND published="1"  ORDER BY ordering,name', 'OBJECT') ;
        for($intA=0;$intA<count($complexBox); $intA++){
            $complexBox[$intA]->extras = array();
            
            $childBox = array();
            if($complexBox[$intA]->complex == '1'){
                $complexBox[$intA]->checkedyes = false;
                $childBox = $jsDatabase->select('SELECT * FROM #__bl_box_fields WHERE parent_id="'.$complexBox[$intA]->id.'" AND published="1"  ORDER BY ordering,name', 'OBJECT') ;
                for($intB=0;$intB<count($childBox); $intB++){
                    $options = json_decode($childBox[$intB]->options,true);
                    $checkedyes = (isset($options['matchpage']['display_col']) && $options['matchpage']['display_col'] == "0") ? false: true;
                    if($checkedyes){
                        $complexBox[$intA]->checkedyes = true;
            
                    }                    
                    $extras = isset($options['extraVals'])?$options['extraVals']:array();
                    $childBox[$intB]->extras = $extras;
                    if(count($extras)){
                        foreach($extras as $extr){
                            array_push($complexBox[$intA]->extras, $extr);
                        }
                    }
                    
                    $childBox[$intB]->checkedyes = $checkedyes;
                }
            }else{
                $options = json_decode($complexBox[$intA]->options,true);
                $extras = isset($options['extraVals'])?$options['extraVals']:array();
                $checkedyes = (isset($options['matchpage']['display_col']) && $options['matchpage']['display_col'] == "0") ? false: true;
                    
                $complexBox[$intA]->extras =  $extras;
                $complexBox[$intA]->checkedyes = $checkedyes;
            }
            $parentB[$intA]['object'] = $complexBox[$intA];
            $parentB[$intA]['childs'] = $childBox;
        }
        
        $th1 = '';
        $th2 = '';
        
        if($efbox){
            $simpleBox = $jsDatabase->select('SELECT id, sel_value as name FROM #__bl_extra_select WHERE fid="'.$efbox.'" ORDER BY eordering,sel_value') ;
            for($intS=0;$intS<count($simpleBox);$intS++){  
                $query = "SELECT p.id as id,CONCAT(p.first_name,' ',p.last_name) as p_name
			            FROM #__bl_players as p, #__bl_players_team as s
                                    , #__bl_extra_values as ev 
			            WHERE s.confirmed='0' AND s.player_join='0' AND s.player_id = p.id
			            AND s.team_id = ".$home_team.' AND s.season_id='.$season_id
                                    ." AND ev.uid=p.id AND f_id={$efbox} AND ev.fvalue={$simpleBox[$intS]->id}"
                                    . " AND (ev.season_id = 0 OR ev.season_id = {$season_id})"
                                    ." GROUP BY p.id"
                        .' ORDER BY p.first_name,p.last_name';
                $players = $jsDatabase->select($query);
                
                //$html .= $simpleBox[$intS]->name;
                $this->lists["boxcorner"][$intS] = $simpleBox[$intS]->name;
                $th1=$th2='';
                $boxtd = array();
                for($intA=0;$intA<count($parentB);$intA++){
                    $box = $parentB[$intA];
                    $intChld = 0;
                    
                    for($intB=0;$intB<count($box['childs']); $intB++){
                        if(!count($box['childs'][$intB]->extras) || in_array($simpleBox[$intS]->id, $box['childs'][$intB]->extras)){
                            if($box['childs'][$intB]->checkedyes){
                                $intChld++;
                                $box['childs'][$intB]->name = classJsportTranslation::get('boxfields_'.$box['childs'][$intB]->id, 'name',$box['childs'][$intB]->name);

                                $th2 .= "<th>".$box['childs'][$intB]->name."</th>";
                                $this->lists["boxheader2"][$intS][] = array("1","1", $box['object']->name." ".$box['childs'][$intB]->name);
                                $boxtd[] =  $box['childs'][$intB]->id;
                            }
                        }
                    }

                    if(!count($box['object']->extras) || in_array($simpleBox[$intS]->id, $box['object']->extras)){
                        if($box['object']->checkedyes){    
                            $box['object']->name = classJsportTranslation::get('boxfields_'.$box['object']->id, 'name',$box['object']->name);

                            if($intChld){
                                $th1 .= '<th colspan="'.$intChld.'">'.$box['object']->name.'</th>';
                                //$this->lists["boxheader2"][$intS][] = array("1",$intChld, $box['object']->name);
                            }else{
                                $th1 .= '<th rowspan="2">'.$box['object']->name.'</th>';
                                $this->lists["boxheader2"][$intS][] = array("2","1", $box['object']->name);
                                $boxtd[] =  $box['object']->id;
                            }
                        }    
                    }elseif($intChld){
                        $th1 .= '<th colspan="'.$intChld.'">'.$box['object']->name.'</th>';
                        //$this->lists["boxheader2"][$intS][] = array("1",$intChld, $box['object']->name);
                    }
                }
                $html_head = $html_body = '';
                $html_head .= '<div class="table-responsive">
                    <table class="table jsBoxStatDIvFE">
                                <thead>
                                    <tr>
                                        <th rowspan="2">'.$simpleBox[$intS]->name.'</th>'
                                        .$th1.
                                    '</tr>
                                    <tr>'
                                        .$th2.
                                    '</tr>
                                </thead>
                                <tbody>';
                                $playersIN = array();
                                
                                    for($intPP=0;$intPP<count($players);$intPP++){
                                        if(in_array($players[$intPP]->id, $playersNotNull)){
                                            $html_body .= '<tr>';
                                            $html_body .= '<td>';
                                            
                                            $player = new classJsportPlayer($players[$intPP]->id,$season_id);
                                            $html_body .= $player->getName(true);
                                            $this->lists["boxbodyplayer"][$intS][] = array($player->getName(false));
                                            $html_body .= '</td>';
                                            $player_stat = $jsDatabase->selectObject("SELECT *, 1 AS `totalMatches` FROM #__bl_box_matches WHERE match_id={$this->match_id} AND team_id={$home_team} AND player_id={$player->object->id}");

                                            $tmparr = array();
                                            for($intBox=0;$intBox<count($boxtd);$intBox++){

                                                $html_body .= '<td>'.(jsHelper::getBoxValue($boxtd[$intBox], $player_stat)).'</td>';
                                                 array_push($tmparr,jsHelper::getBoxValue($boxtd[$intBox], $player_stat));
                                            }
                                            $playersIN[] = $players[$intPP]->id;
                                            $html_body .= '</tr>';
                                            
                                            $this->lists["boxbody"][$intS][] = $tmparr;
                                            
                                        }
                                    }
                if(!count($playersIN)){
                    $this->lists["boxbodyplayer"][$intS] = $this->lists["boxbody"][$intS] = array();
                }
                            if($html_body){
                                $html .= $html_head.$html_body.'</tbody>';
                            }        
                    
                    
                    if(count($playersIN) && $html_body){
                        $html .= '<tfoot>';
                        $html .= '<tr>';
                        $html .= '<td>';
                        $html .= JText::_('BLFA_BOXSCORE_TOTAL');
                        $tmparr = array();
                        $html .= '</td>';
                        $player_stat = $jsDatabase->selectObject("SELECT ".$totalSQL." FROM #__bl_box_matches WHERE match_id={$this->match_id} AND team_id={$home_team} AND player_id IN (".  implode(',', $playersIN).")");
                        for($intBox=0;$intBox<count($boxtd);$intBox++){
                            $cBox = $jsDatabase->selectObject('SELECT * FROM #__bl_box_fields WHERE id='.intval($boxtd[$intBox])) ;
                            $options = json_decode($cBox->options, true);
                            $checkedyes = (isset($options['matchpage']['display_total']) && $options['matchpage']['display_total'] == "0") ? false: true;
                    
                            $html .= '<td>'.($checkedyes?(jsHelper::getBoxValue($boxtd[$intBox], $player_stat)):'').'</td>';
                            //$this->lists["boxtotal"][$intS][] = array($checkedyes?(jsHelper::getBoxValue($boxtd[$intBox], $player_stat)):'');
                            array_push($tmparr,($checkedyes?(jsHelper::getBoxValue($boxtd[$intBox], $player_stat)):''));
                        }
                        
                        $this->lists["boxtotal"][$intS][] = $tmparr;

                        $html .= '</tr>';
                        $html .= '</tfoot>';
                    }else{
                        $this->lists["boxtotal"][$intS] = array();
                    }
                    if($html_body){
                        $html .=  '</table></div>';
                    }

            }
        }else{
            $th1=$th2='';
            $boxtd = array();

            $query = "SELECT p.id 
                        FROM #__bl_players as p, #__bl_players_team as s

                        WHERE s.confirmed='0' AND s.player_join='0' AND s.player_id = p.id
                        AND s.team_id = ".$home_team.' AND s.season_id='.$season_id
                       ." GROUP BY p.id"             
                        .' ORDER BY p.first_name,p.last_name';
            
            $players = $jsDatabase->select($query);
            
            for($intA=0;$intA<count($parentB);$intA++){
                $box = $parentB[$intA];
                $intChld = 0;
                for($intB=0;$intB<count($box['childs']); $intB++){
                    if($box['childs'][$intB]->checkedyes){
                        $intChld++;
                        $box['childs'][$intB]->name = classJsportTranslation::get('boxfields_'.$box['childs'][$intB]->id, 'name',$box['childs'][$intB]->name);

                        $th2 .= "<th>".$box['childs'][$intB]->name."</th>";
                        $boxtd[] =  $box['childs'][$intB]->id;
                        
                        $this->lists["boxheader2"][0][] = array("1","1", $box['childs'][$intB]->name);
                    }
                    
                }
                $box['object']->name = classJsportTranslation::get('boxfields_'.$box['object']->id, 'name',$box['object']->name);
        
                if($intChld){
                    if($box['object']->checkedyes){
                        $th1 .= '<th colspan="'.$intChld.'">'.$box['object']->name.'</th>';
                        $this->lists["boxheader1"][0][] = array("1",$intChld, $box['object']->name);
                    }
                }elseif($box['object']->complex != '1'){
                    if($box['object']->checkedyes){
                        $th1 .= '<th rowspan="2">'.$box['object']->name.'</th>';
                        //$this->lists["boxheader1"][0][] = array("2","1", $box['object']->name);
                        $this->lists["boxheader2"][0][] = array("2","1", $box['object']->name);
                        $boxtd[] =  $box['object']->id;
                    }
                }
                
            }
            $html_head = $html_body = '';
            $html_head .= '<div class="table-responsive"><table class="table jsBoxStatDIvFE">
                                <thead>
                                    <tr>
                                        <th rowspan="2">'.JText::_('BLFA_PLAYERR').'</th>'
                                        .$th1.
                                    '</tr>
                                    <tr>'
                                        .$th2.
                                    '</tr>
                                </thead>
                                <tbody>';
            $this->lists["boxcorner"][0] = JText::_('BLFA_PLAYERR');
                                    $playersIN = array();
                                    for($intPP=0;$intPP<count($players);$intPP++){
                                        if(in_array($players[$intPP]->id, $playersNotNull)){
                                        
                                            $html_body .= '<tr>';
                                            $html_body .= '<td>';
                                            $player = new classJsportPlayer($players[$intPP]->id,$season_id);
                                            $html_body .= $player->getName(true);
                                            $this->lists["boxbodyplayer"][0][] = array($player->getName(false));
                                            $html_body .= '</td>';
                                            $player_stat = $jsDatabase->selectObject("SELECT *, 1 AS `totalMatches` FROM #__bl_box_matches WHERE match_id={$this->match_id} AND team_id={$home_team} AND player_id={$player->object->id}");
                                            $tmparr = array();
                                            for($intBox=0;$intBox<count($boxtd);$intBox++){

                                                array_push($tmparr,jsHelper::getBoxValue($boxtd[$intBox], $player_stat));
                                                //$this->lists["boxbody"][0][] = array(jsHelper::getBoxValue($boxtd[$intBox], $player_stat));
                                                $html_body .= '<td>'.(jsHelper::getBoxValue($boxtd[$intBox], $player_stat)).'</td>';
                                            }
                                            $this->lists["boxbody"][0][] = $tmparr;
                                            $playersIN[] = $players[$intPP]->id;
                                            $html_body .= '</tr>';
                                        }
                                    }
                    if($html_body){
                        $html .=  $html_head.$html_body.'</tbody>';
                    }
                    
                    if(count($playersIN) && $html){
                        $html .= '<tfoot>';
                        $html .= '<tr>';
                        $html .= '<td>';
                        $html .= JText::_('BLFA_BOXSCORE_TOTAL');
                        
                        $html .= '</td>';
                        $player_stat = $jsDatabase->selectObject("SELECT ".$totalSQL." FROM #__bl_box_matches WHERE match_id={$this->match_id} AND team_id={$home_team}");
                        $tmparr = array();
                        for($intBox=0;$intBox<count($boxtd);$intBox++){
                            $cBox = $jsDatabase->selectObject('SELECT * FROM #__bl_box_fields WHERE id='.intval($boxtd[$intBox])) ;
                            $options = json_decode($cBox->options, true);
                            $checkedyes = (isset($options['matchpage']['display_total']) && $options['matchpage']['display_total'] == "0") ? false: true;
                    
                            $html .= '<td>'.($checkedyes?(jsHelper::getBoxValue($boxtd[$intBox], $player_stat)):'').'</td>';
                            array_push($tmparr,($checkedyes?(jsHelper::getBoxValue($boxtd[$intBox], $player_stat)):''));
                            //$this->lists["boxtotal"][0][] = array($checkedyes?(jsHelper::getBoxValue($boxtd[$intBox], $player_stat)):'');
                        }
                         $this->lists["boxtotal"][0][] = $tmparr;

                        $html .= '</tr>';
                        $html .= '</tfoot>';
                    }
                    if($html){
                        $html .=  '</table></div>';
                    }
        }
        return $html;
        
    }
}
