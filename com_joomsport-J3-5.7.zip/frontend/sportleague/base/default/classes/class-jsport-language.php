<?php

class classJsportLanguage
{
    public static function get($var)
    {
        return $var;
    }
}
