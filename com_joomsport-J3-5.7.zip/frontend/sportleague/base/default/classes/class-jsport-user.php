<?php

class classJsportUser
{
    public static function getUserId()
    {
    }
    public static function getUserValue()
    {
    }
}
