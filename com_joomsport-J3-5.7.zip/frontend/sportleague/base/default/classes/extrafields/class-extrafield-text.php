<?php

class classExtrafieldText
{
    public static function getValue($ef)
    {
        return $ef->fvalue;
    }
}
