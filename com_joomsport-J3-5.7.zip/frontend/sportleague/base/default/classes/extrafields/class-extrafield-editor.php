<?php

class classExtrafieldEditor
{
    public static function getValue($ef)
    {
        return $ef->fvalue_text;
    }
}
