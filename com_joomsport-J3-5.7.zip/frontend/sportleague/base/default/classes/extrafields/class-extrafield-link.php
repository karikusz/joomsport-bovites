<?php

class classExtrafieldLink
{
    public static function getValue($ef)
    {
        return $ef->fvalue;
    }
}
