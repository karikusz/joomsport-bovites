<?php
/*------------------------------------------------------------------------
# JoomSport Professional 
# ------------------------------------------------------------------------
# BearDev development company 
# Copyright (C) 2011 JoomSport.com. All Rights Reserved.
# @license - http://joomsport.com/news/license.html GNU/GPL
# Websites: http://www.JoomSport.com 
# Technical Support:  Forum - http://joomsport.com/helpdesk/
-------------------------------------------------------------------------*/
// no direct access
defined('_JEXEC') or die('Restricted access');

if (isset($this->message)) {
    $this->display('message');
}
$Itemid = JRequest::getInt('Itemid');
?>

<?php
echo $lists['panel'];
?>
<div class="module-middle">
	
	<!-- <back box> -->
		<div class="back dotted"><a href="javascript:void(0);" onclick="history.back(-1);" title="<?php echo JText::_('BL_BACK')?>">&larr; <?php echo JText::_('BL_BACK')?></a></div>
	<!-- </back box> -->
	
	<!-- <title box> -->
	<div class="title-box">
		<h2><?php //echo $this->escape($this->params->get('page_title'));
            echo $this->escape($this->ptitle);
            ?></h2>
	</div>
	<!-- </div>title box> -->
	
</div>


<div style="clear:both"></div>
<div>
<?php
echo $this->lists['knock_layout'];
?>
</div>