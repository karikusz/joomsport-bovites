<?php
/* ------------------------------------------------------------------------
  # JoomSport Professional
  # ------------------------------------------------------------------------
  # BearDev development company
  # Copyright (C) 2011 JoomSport.com. All Rights Reserved.
  # @license - http://joomsport.com/news/license.html GNU/GPL
  # Websites: http://www.JoomSport.com
  # Technical Support:  Forum - http://joomsport.com/helpdesk/
------------------------------------------------------------------------- */
// no direct access
defined('_JEXEC') or die('Restricted access');
$rows = $this->rows;
$lists = $this->lists;
$page = $this->page;
$Itemid = JRequest::getInt('Itemid');
?>
<script type="text/javascript">
    function bl_submit(task, chk) {
        if (chk == 1 && document.adminForm.boxchecked.value == 0) {
            alert('<?php echo JText::_('BLFA_SELECTITEM') ?>');
        } else {
            document.adminForm.task.value = task;
            document.adminForm.submit();
        }
    }
    function submitbutton(pressbutton) {
        var form = document.adminForm;
        submitform(pressbutton);
        return;
    }
</script>
<div id="joomsport-container">
    <div class="page-content">
        <nav class="navbar navbar-default navbar-static-top" role="navigation">
            <?php
            echo $lists['panel'];
            ?>
        </nav>

        <!-- /.navbar -->

        <form action="<?php echo JRoute::_('index.php?option=com_joomsport&view=admin_matchday&controller=admin&sid='.$this->s_id.'&Itemid='.$Itemid.'&jslimit='.$this->page->limit.'&page=1'); ?>" method="post" name="adminForm" id="adminForm">
            <div class="jsFEedit adminMatchday">
                <div class="heading col-xs-12 col-lg-12">
                    <h4 class="text-right"><?php echo $this->lists['tournname']; ?></h4>
                    <h2><?php echo JText::_('BLFA_MATCHDAYLIST') ?></h2>
                </div>
                <div class="navbar-links col-xs-12 col-lg-12">
                    <div class="row">
                        <div class="col-sm-push-7 col-sm-5 col-xs-12 text-right">
                            <ul class="nav navbar-nav">
                                <?php if (!$this->lists['t_single']) { ?>
                                    <a class="btn btn-default" href="<?php echo JRoute::_('index.php?option=com_joomsport&controller=admin&task=admin_team&sid='.$this->s_id.'&Itemid='.$Itemid) ?>" title=""><i class="js-team"></i><?php echo JText::_('BLFA_ADMIN_TEAM') ?></a>
                                <?php } ?>
                                <a class="btn btn-default" href="<?php echo JRoute::_('index.php?option=com_joomsport&controller=admin&task=admin_player&sid='.$this->s_id.'&Itemid='.$Itemid) ?>" title=""><i class="js-pllist"></i><?php echo JText::_('BLFA_PLAYER') ?></a>
                            </ul>
                        </div>
                        <div class="admin-tools col-sm-pull-5 col-sm-7 col-xs-12">
                            <div>
                                <?php echo $this->lists['t_type']; ?>
                            <a class="btn btn-success" href="#" onclick="bl_submit('edit_matchday');
                            return false;" title="<?php echo JText::_('BLFA_NEW') ?>"><i class="glyphicon glyphicon-plus-sign"></i> <?php echo JText::_('BLFA_NEW') ?></a>
                            </div>
                            <div>
                            <a class="btn btn-default btn-icon" href="#" onclick="bl_submit('edit_matchday', 1);
                            return false;" title="<?php echo JText::_('BLFA_EDIT') ?>"><i class="glyphicon glyphicon-edit"></i> <?php echo JText::_('BLFA_EDIT') ?></a>
                            <a class="btn btn-default btn-icon" href="#" onclick="bl_submit('matchday_del', 1);
                            return false;" title="<?php echo JText::_('BLFA_DELETE') ?>"><i class="glyphicon glyphicon-remove"></i> <?php echo JText::_('BLFA_DELETE') ?></a>
                        </div>
                    </div>
                </div>
                </div>
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                    <div class="data">

                    </div>
                </div>
                <div class="table-responsive col-xs-12 col-lg-12">
                    <table class="table table-striped jstable-centered js_table_check">
                        <thead>
                            <tr>
                                <th width="5%"><?php echo JText::_('BLFA_NUM'); ?></th>
                                <th width="5%">
                                    <div class="js_checkbox js_checkbox-warning">
                                        <input type="checkbox" id="check_all" name="toggle" value="" onclick="Joomla.checkAll(this);" />
                                        <label for="check_all">
                                            <span class="glyphicon glyphicon-ok"></span>
                                        </label>
                                    </div>
                                </th>
                                <th class="jsTextAlignLeft" width="90%"><?php echo JText::_('BLFA_MATCHDAY'); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $k = 0;
                            if (count($rows)) {
                                for ($i = 0, $n = count($rows); $i < $n; ++$i) {
                                    $row = $rows[$i];
                                    JFilterOutput::objectHtmlSafe($row);
                                    $link = JRoute::_('index.php?option=com_joomsport&controller=admin&view=edit_matchday&cid[]='.$row->id.'&sid='.$this->s_id.'&Itemid='.$Itemid);
                                    $checked = @JHTML::_('grid.checkedout', $row, $i);
                                    ?>
                                    <tr class="<?php echo $i % 2 ? 'active' : ''; ?>">
                                        <td>
                                            <?php echo $i + 1 + (($this->page->page - 1) * $this->page->limit); ?>
                                        </td>
                                        <td>
                                            <div class="js_checkbox js_checkbox-warning">
                                                <?php echo $checked; ?>
                                                <label for="cb<?php echo $i; ?>">
                                                    <span class="glyphicon glyphicon-ok"></span>
                                                </label>
                                            </div>
                                        </td>
                                        <td class="jsTextAlignLeft">
                                            <?php echo '<a href="'.$link.'">'.$row->m_name.'</a>'; ?>
                                        </td>
                                    </tr>
                                    <?php
                                }
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
                <div class="jsClear"></div>
                <div class="pages">
                    <?php
                    $link_page = 'index.php?option=com_joomsport&view=admin_matchday&controller=admin&sid='.$this->s_id.'&Itemid='.$Itemid.'&jslimit='.$this->page->limit;
                    echo $this->page->getLimitPage();
                    echo $this->page->getPageLinks($link_page);
                    echo $this->page->getLimitBox();
                    ?>
                </div>
                <div class="jsClear"></div>
            </div>
            <input type="hidden" name="task" value="admin_matchday" />
            <input type="hidden" name="boxchecked" value="0" />
            <input type="hidden" name="controller" value="admin" />
            <input type="hidden" name="sid" value="<?php echo $this->s_id; ?>" />
            <?php echo JHTML::_('form.token'); ?>
        </form>
    </div>
</div>