<?php
/* ------------------------------------------------------------------------
  # JoomSport Professional
  # ------------------------------------------------------------------------
  # BearDev development company
  # Copyright (C) 2011 JoomSport.com. All Rights Reserved.
  # @license - http://joomsport.com/news/license.html GNU/GPL
  # Websites: http://www.JoomSport.com
  # Technical Support:  Forum - http://joomsport.com/helpdesk/
------------------------------------------------------------------------- */
// no direct access
defined('_JEXEC') or die('Restricted access');
if (isset($this->message)) {
    $this->display('message');
}
$rows = $this->rows;
$page = $this->page;

global $Itemid;
$Itemid = JRequest::getInt('Itemid');
?>
<script type="text/javascript">
    function bl_submit(task, chk) {
        if (chk == 1 && document.adminForm.boxchecked.value == 0) {
            alert('<?php echo JText::_('BLFA_SELECTITEM') ?>');
        } else {
            document.adminForm.task.value = task;
            document.adminForm.submit();
        }
    }
</script>
<div id="joomsport-container">
    <div class="page-content">
        <nav class="navbar navbar-default navbar-static-top" role="navigation">
            <?php echo $lists['panel']; ?>
        </nav>
        <!-- /.navbar -->

        <div class="jsFEedit adminPlayer">
            <div class="heading col-xs-12 col-lg-12">
                <?php if ($this->acl == 2) {
                    ?>
                    <h2 class="pull-left col-xs-12 col-sm-12 col-md-4 col-lg-4"><?php echo JText::_('BLFA_PLAYERSLIST') ?></h2>
                    <div class="selection col-xs-12 col-sm-12 col-md-8 col-lg-8 pull-right">
                        <form action='<?php echo JURI::base(); ?>index.php?option=com_joomsport&task=team_edit&controller=moder&Itemid=<?php echo $Itemid ?>' method='post' name='chg_team'>
                            <div class="data">
                                <?php echo $this->lists['tm_filtr']; ?>
                            </div>
                        </form>
                    </div>
                    <?php
                } else {
                    ?>
                    <h4 class="text-right"><?php echo $this->lists['tournname']; ?></h4>
                    <h2><?php echo JText::_('BLFA_PLAYERSLIST') ?></h2>
                    <?php
                } ?>
            </div>
            <div class="navbar-links col-xs-12 col-lg-12">
                <div class="row">
                    <div class="col-sm-push-7 col-sm-5 col-xs-12 text-right">
                        <ul class="nav navbar-nav">
                            <?php if ($this->acl == 2) {
                                ?>
                                <a class="btn btn-default" href="<?php echo JRoute::_('index.php?option=com_joomsport&controller=moder&view=edit_team&tid='.$this->tid.'&Itemid='.$Itemid); ?>" title=""><i class="js-team"></i><?php echo JText::_('BLFA_TEAM') ?></a>
                                <?php if ($this->lists['enmd']): ?>
                                    <a class="btn btn-default" href="<?php echo JRoute::_('index.php?option=com_joomsport&controller=moder&task=edit_matchday&tid='.$this->tid.'&Itemid='.$Itemid) ?>" title=""><i class="js-match"></i><?php echo JText::_('BLFA_MATCHDAY') ?></a>
                                <?php endif; ?>
                            <?php } else { ?>
                                <a class="btn btn-default" href="<?php echo JRoute::_('index.php?option=com_joomsport&controller=admin&view=admin_matchday&sid='.$this->s_id.'&Itemid='.$Itemid) ?>" title=""><i class="js-match"></i><?php echo JText::_('BLFA_MATCHDAY') ?></a>
                                <?php if (!$this->lists['t_single']) { ?>
                                    <a class="btn btn-default" href="<?php echo JRoute::_('index.php?option=com_joomsport&controller=admin&task=admin_team&sid='.$this->s_id.'&Itemid='.$Itemid) ?>" title=""><i class="js-team"></i><?php echo JText::_('BLFA_ADMIN_TEAM') ?></a>
                                <?php }  ?>
                                <?php
                            } ?>
                        </ul>
                    </div>
                    <div class="admin-tools col-sm-pull-5 col-sm-7 col-xs-12">
                        <?php if ($this->acl == 2) {
                            ?>
                            <a class="btn btn-success" href="javascript:void(0);" title="<?php echo JText::_('BLFA_NEW') ?>" onclick="javascript:bl_submit('adplayer_edit', 0);
                            return false;"><i class="glyphicon glyphicon-plus-sign"></i> <?php echo JText::_('BLFA_NEW') ?></a>
                            <a class="btn btn-default btn-icon" href="javascript:void(0);" title="<?php echo JText::_('BLFA_EDIT') ?>" onclick="javascript:bl_submit('adplayer_edit', 1);
                            return false;"><i class="glyphicon glyphicon-edit"></i> <?php echo JText::_('BLFA_EDIT') ?></a>
                            <a class="btn btn-default btn-icon" href="javascript:void(0);" title="<?php echo JText::_('BLFA_DELETE') ?>" onclick="javascript:bl_submit('mdplayer_del', 1);
                            return false;"><i class="glyphicon glyphicon-remove"></i> <?php echo JText::_('BLFA_DELETE') ?></a>
                            <?php
                        } else {
                            ?>
                            <?php if ($this->lists['jssa_addexteam_single'] == 1 && $this->lists['t_single'] == 1): ?>
                                <a class="btn btn-success" href="javascript:void(0);" onclick="javascript:getObj('div_addexpl').style.display = 'block';
                                return false;" title="<?php echo JText::_('BLFA_ADDEXPL') ?>"><i class="glyphicon glyphicon-plus-sign"></i> <?php echo JText::_('BLFA_ADDEXPL') ?></a>
                            <?php endif;
                            ?>
                            <a class="btn btn-success" href="javascript:void(0);" title="<?php echo JText::_('BLFA_NEW') ?>" onclick="javascript:bl_submit('adplayer_edit', 0);
                            return false;"><i class="glyphicon glyphicon-plus-sign"></i> <?php echo JText::_('BLFA_NEW') ?></a>
                            <?php if ($lists['jssa_editplayer']) {
                                ?>
                                <a class="btn btn-default btn-icon" href="javascript:void(0);" title="<?php echo JText::_('BLFA_EDIT') ?>" onclick="javascript:bl_submit('adplayer_edit', 1);
                                return false;"><i class="glyphicon glyphicon-edit"></i> <?php echo JText::_('BLFA_EDIT') ?></a>
                                <?php
                            }
                            ?>
                            <?php if ($lists['jssa_deleteplayers']) {
                                ?>
                                <a class="btn btn-default btn-icon" href="javascript:void(0);" title="<?php echo JText::_('BLFA_REMOVE') ?>" onclick="javascript:bl_submit('adplayer_del', 1);
                                return false;"><i class="glyphicon glyphicon-remove"></i><?php echo JText::_('BLFA_REMOVE') ?></a>
                                <?php
                            }
                            ?>
                            <?php
                        } ?>
                    </div>
                </div>
            </div>

            <?php
            $newad = '';
            if ($this->acl == 1) {
                $link = JURI::base().'index.php?option=com_joomsport&controller=admin&sid='.$this->s_id.'&Itemid='.$Itemid;
                if ($this->lists['jssa_addexteam_single'] == 1 && $this->lists['t_single'] == 1) {
                    $newad .= '<div style="display:none;padding:10px;" id="div_addexpl">';
                    $newad .= $this->lists['players_ex'];
                    $newad .= '<button class="send-button" onclick="javascript:if(document.adminForm.players_ex.value != 0){bl_submit(\'add_ex_player\',0);};return false;" />';
                    $newad .= '<span>'.JText::_('BLFA_ADD').'</span>';
                    $newad .= '</button>';
                    $newad .= '</div>';
                }
            } else {
                $link = JURI::base().'index.php?option=com_joomsport&controller=moder&tid='.$this->tid.'&Itemid='.$Itemid;
            }
            ?>
            <div class="jsClear"></div>
            <form action="<?php echo $link; ?>" method="post" name="adminForm" id="adminForm">
                <?php echo $newad;?>
                <div class="table-responsive col-xs-12 col-lg-12">
                    <table class="table table-striped jstable-centered js_table_check">
                        <thead>
                            <tr>
                                <th width="5%"><?php echo JText::_('BLFA_NUM'); ?></th>
                                <th width="5%">
                                    <?php if ($this->acl == 1 && ($lists['jssa_editplayer'] == 1 or $lists['jssa_deleteplayers'])) {
                                        ?>
                                        <div class="js_checkbox js_checkbox-warning">
                                            <input type="checkbox" id="check_all" name="toggle" value="" onclick="Joomla.checkAll(this);" />
                                            <label for="check_all">
                                                <span class="glyphicon glyphicon-ok"></span>
                                            </label>
                                        </div>
                                        <?php
                                    } elseif ($this->acl == 2) {
                                        ?>
                                        <div class="js_checkbox js_checkbox-warning">
                                            <input type="checkbox" id="check_all" name="toggle" value="" onclick="Joomla.checkAll(this);" />
                                            <label for="check_all">
                                                <span class="glyphicon glyphicon-ok"></span>
                                            </label>
                                        </div>
                                        <?php
                                    } ?>
                                </th>
                                <th class="jsTextAlignLeft" width="90%"><?php echo JText::_('BLFA_PLAYERR'); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $k = 0;
                            if (count($rows)) {
                                for ($i = 0, $n = count($rows); $i < $n; ++$i) {
                                    $row = $rows[$i];
                                    JFilterOutput::objectHtmlSafe($row);
                                    if ($this->acl == 2) {
                                        $link = JRoute::_('index.php?option=com_joomsport&controller=moder&task=adplayer_edit&tid='.$this->tid.'&cid[]='.$row->id.'&Itemid='.$Itemid);
                                    } else {
                                        if ($lists['jssa_editplayer']) {
                                            $link = JRoute::_('index.php?option=com_joomsport&task=adplayer_edit&controller=admin&sid='.$this->s_id.'&cid[]='.$row->id.'&Itemid='.$Itemid);
                                        } else {
                                            $link = JRoute::_('index.php?option=com_joomsport&task=player&sid='.$this->s_id.'&id='.$row->id.'&Itemid='.$Itemid);
                                        }
                                    }
                                    $checked = @JHTML::_('grid.checkedout', $row, $i);
                                    ?>
                                    <tr class="<?php echo $i % 2 ? 'gray' : ''; ?>">
                                        <td><?php echo $i + 1 + (($this->page->page - 1) * $this->page->limit);?></td>
                                        <td>
                                            <?php
                                            if ($this->acl == 1 && ($lists['jssa_editplayer'] == 1 or $lists['jssa_deleteplayers'])) {
                                                ?>
                                                <div class="js_checkbox js_checkbox-warning">
                                                    <?php echo $checked; ?>
                                                    <label for="cb<?php echo $i; ?>">
                                                        <span class="glyphicon glyphicon-ok"></span>
                                                    </label>
                                                </div>
                                                <?php
                                            } elseif ($this->acl == 2) {
                                                ?>
                                                <div class="js_checkbox js_checkbox-warning">
                                                    <?php echo $checked; ?>
                                                    <label for="cb<?php echo $i; ?>">
                                                        <span class="glyphicon glyphicon-ok"></span>
                                                    </label>
                                                </div>
                                                <?php
                                            }
                                            ?>
                                        </td>
                                        <td class="jsTextAlignLeft">
                                            <?php
                                            if ($row->photo && is_file('media/bearleague/'.$row->photo)) {
                                                echo '<img class="img-thumbnail" '.getImgPop($row->photo, 1).' alt="" />';
                                            } else {
                                                echo '<img class="img-thumbnail" src="'.JURI::base().'components/com_joomsport/img/ico/season-list-player-ico.gif" width="30" height="30" alt="">';
                                            }
                                            ?>
                                            <?php
                                            echo '<a href="'.$link.'">'.$row->first_name.' '.$row->last_name.'</a>';
                                            ?>
                                        </td>
                                    </tr>
                                    <?php

                                }
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
                <div class="jsClear"></div>
                <div class="pages">
                    <?php
                    if ($this->acl == 1) {
                        $link_page = 'index.php?option=com_joomsport&view=admin_player&controller=admin&sid='.$this->s_id.'&Itemid='.$Itemid.'&jslimit='.$this->page->limit;
                    } elseif ($this->acl == 2) {
                        $link_page = 'index.php?option=com_joomsport&view=admin_player&controller=moder&tid='.$this->tid.'&Itemid='.$Itemid.'&jslimit='.$this->page->limit;
                    }
                    echo $this->page->getLimitPage();
                    echo $this->page->getPageLinks($link_page);
                    echo $this->page->getLimitBox();
                    ?>
                    <div class="jsClear"></div>
                </div>
                <div class="jsClear"></div>
                <input type="hidden" name="option" value="com_joomsport" />
                <input type="hidden" name="task" value="admin_player" />
                <input type="hidden" name="boxchecked" value="0" />
                <?php echo JHTML::_('form.token'); ?>
            </form>
        </div>
    </div>
</div>