<?php
/* ------------------------------------------------------------------------
  # JoomSport Professional
  # ------------------------------------------------------------------------
  # BearDev development company
  # Copyright (C) 2011 JoomSport.com. All Rights Reserved.
  # @license - http://joomsport.com/news/license.html GNU/GPL
  # Websites: http://www.JoomSport.com
  # Technical Support:  Forum - http://joomsport.com/helpdesk/
------------------------------------------------------------------------- */
// no direct access
defined('_JEXEC') or die('Restricted access');

JHtml::_('behavior.tooltip');
JHTML::_('behavior.formvalidation');
$editor = JFactory::getEditor();

$Itemid = JRequest::getInt('Itemid');
//update
$this->lists['player_reg'] = array();
if (count($this->lists['player_reg'])) {
    for ($i = 0; $i < count($this->lists['player_reg']); ++$i) {
        foreach ($this->lists['player_reg'][$i] as $dta) {
            $tmp[$i][] = '\''.addslashes($dta).'\'';
        }
    }
    for ($j = 0; $j < count($tmp); ++$j) {
        $arr1[] = $tmp[$j][0];
        $arr2[] = $tmp[$j][1];
    }
}
$fname = isset($arr1) ? implode(',', $arr1) : ('');
$lname = isset($arr2) ? implode(',', $arr2) : ('');
?>
<script type="text/javascript">

    function delete_logo() {
        getObj("logoiddiv").innerHTML = '';
    }

    function confirmDelete() {
        var fName = document.getElementsByName('first_name')[0].value;
        var lName = document.getElementsByName('last_name')[0].value;
        var msg = '';

        var arrFName = new Array(<?php echo $fname; ?>);
        var arrLName = new Array(<?php echo $lname; ?>);

        for (var i = 0; i < arrFName.length; i++) {
            if (arrFName[i] == fName && arrLName[i] == lName) {
                msg = 1;
            }
        }

        var indf = <?php echo (isset($this->lists['usr']->last_name) && isset($this->lists['usr']->first_name)) ? (1) : (0); ?>;

        if (msg && indf == 0) {
            if (confirm("Player with such First Name and Last Name already exist. Do you wants to continue?")) {
                return true;
            } else {
                return false;
            }
        }
    }
</script>

<div id="joomsport-container">
    <div class="page-content">
        <div>
            <nav class="navbar navbar-default navbar-static-top" role="navigation">
                <?php
                echo $this->lists['panel'];
                ?>
            </nav>
        </div>
        <!-- /.navbar -->

        <div class="jsFEedit regPlayer">
            <form action="<?php echo JRoute::_('index.php?option=com_joomsport&task=regplayer&Itemid='.$Itemid); ?>" method="post" name="filterForm" id="filterForm" class="clearfix" enctype="multipart/form-data">
                <div class="heading col-xs-12 col-lg-12">
                    <h2 class="pull-left col-xs-12 col-sm-12 col-md-4 col-lg-4"><?php echo $this->escape($this->ptitle); ?></h2>
                    <div class="selection col-xs-12 col-sm-12 col-md-8 col-lg-8 pull-right" style="text-align:right;">
                        <?php if (isset($this->lists['ed_seas'])): ?>
                            <label class="selected" style="padding-top:7px;padding-right:10px;"><?php echo $this->lists['tourn_name']; ?></label>
                            <div class="data">
                                <?php echo $this->lists['ed_seas']; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </form>

            <div class="navbar-links col-xs-12 col-lg-12">
                <div class="row">
                    <div class="col-sm-push-7 col-sm-5 col-xs-12 text-right">
                        <?php if ($this->lists['enmd']):?>
                            <ul class="nav navbar-nav">
                                <a class="btn btn-default" href="<?php echo juri::base().'index.php?option=com_joomsport&view=edit_matchday&controller=users&Itemid='.$Itemid ?>" title=""><i class="js-match"></i><?php echo JText::_('BLFA_MATCHDAY') ?></a>
                            </ul>
                        <?php endif;?>
                    </div>
					<div class="admin-tools col-sm-pull-5 col-sm-7 col-xs-12"></div>
                    </div>
                </div>

            <div class="jsClear"></div>
            <div>
                <form method="POST" action="<?php echo 'index.php?option=com_joomsport&task=playerreg_save&Itemid='.$Itemid; ?>" enctype="multipart/form-data" class="form-horizontal" name="adminForm" id="adminForm">
                    <div>
                        <div class="jsrespdiv12">
                            <div class="jsrespdiv6">
                                <div class="jsBepanel">
                                    <div class="jsBEheader"><?php echo JText::_('BLFA_HEAD_GENERAL'); ?></div>
                                    <div class="jsBEsettings">
                                        <div class="form-horizontal">
                                            <div class="form-group">
                                                <label for="inputFirst" class="col-xs-12 col-sm-4 control-label"><?php echo JText::_('BLFA_FIRSTNAME'); ?> *:</label>
                                                <div class="col-sm-8">
                                                    <input name="first_name" value="<?php echo isset($this->lists['usr']->first_name) ? htmlspecialchars($this->lists['usr']->first_name) : '' ?>" type="text" class="form-control required" id="inputFirst" placeholder="First Name"/>
                                                </div>
                                            </div>

                                            <?php if ($this->lists['reg_lastname']) { ?>
                                                <div class="form-group">
                                                    <label for="inputLast" class="col-xs-12 col-sm-4 control-label"><?php echo JText::_('BLFA_LASTNAME');?><?php echo $this->lists['reg_lastname_rq'] ? ' *' : ''; ?>:</label>
                                                    <div class="col-sm-8">
                                                        <input name="last_name" value="<?php echo isset($this->lists['usr']->last_name) ? htmlspecialchars($this->lists['usr']->last_name) : '' ?>" type="text" class="form-control <?php echo $this->lists['reg_lastname_rq'] ? 'required' : '';?> " id="inputLast" placeholder="Last Name"/>
                                                    </div>
                                                </div>
                                            <?php } ?>

                                            <?php if ($this->lists['nick_reg']) { ?>
                                                <div class="form-group">
                                                    <label for="inputNickname" class="col-xs-12 col-sm-4 control-label"><?php echo JText::_('BL_NICK'); ?><?php echo $this->lists['nick_reg_rq'] ? ' *' : '';?>:</label>
                                                    <div class="col-sm-8">
                                                        <input name="nick" value="<?php echo isset($this->lists['usr']->nick) ? htmlspecialchars($this->lists['usr']->nick) : '' ?>" type="text" class="form-control <?php echo $this->lists['reg_lastname_rq'] ? 'required' : ''; ?> " id="inputNickname" placeholder="Nickname"/>
                                                    </div>
                                                </div>
                                            <?php } ?>

                                            <?php if($this->lists['country_reg']) { ?>
                                                <div class="form-group">
                                                    <label for="country_id" class="col-xs-12 col-sm-4 control-label"><?php echo JText::_('BL_COUNTRY'); ?><?php echo $this->lists['country_reg_rq'] ? ' *' : ''; ?>:</label>
                                                    <div class="col-sm-8">
                                                        <?php echo $this->lists['country'] ?>
                                                    </div>
                                                </div>
                                            <?php } ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="jsrespdiv6 jsrespmarginleft2">
                                <div class="jsrespdiv12">
                                    <div class="jsBepanel">
                                        <div class="jsBEheader"><?php echo JText::_('BL_EBL_VAL'); ?></div>
                                        <div class="jsBEsettings">
                                            <div class="form-horizontal">
                                                <?php for ($i = 0; $i < count($this->lists['adf']); ++$i) {
                                                    $adfs = $this->lists['adf'][$i];
                                                    if ($this->lists['adf'][$i]->season_related && $this->sid) { ?>
                                                        <div class="form-group">
                                                            <label class="col-xs-12 col-sm-4 control-label"><?php echo $adfs->name.($adfs->reg_require ? ' *' : '') ?></label>
                                                            <input type="hidden" name="extra_id[<?php echo $adfs->id; ?>]" value="<?php echo $adfs->id; ?>" />
                                                            <input type="hidden" name="extra_ftype[<?php echo $adfs->id; ?>]" value="<?php echo $adfs->field_type; ?>" />
                                                            <div class="col-sm-8">
                                                                <?php switch ($adfs->field_type) {
                                                                    case '1': echo $adfs->selvals;
                                                                    break;
                                                                    case '2': echo '<textarea class="form-control" name="extraf['.$adfs->id.']" rows="6">'.htmlspecialchars(isset($adfs->fvalue_text) ? ($adfs->fvalue_text) : '', ENT_QUOTES).'</textarea>';
                                                                    break;
                                                                    case '3': echo $adfs->selvals;
                                                                    break;
                                                                    case '0':
                                                                    default: echo '<input type="text" class="form-control'.($adfs->reg_require ? ' required' : '').'" maxlength="255" name="extraf['.$adfs->id.']" value="'.(isset($adfs->fvalue) ? htmlspecialchars($adfs->fvalue) : '').'" />';
                                                                    break;
                                                                } ?>
                                                            </div>
                                                        </div>
                                                        <?php
                                                    } elseif ($this->lists['adf'][$i]->season_related == 0 && $adfs->reg_exist) {
                                                        ?>
                                                        <div class="form-group">
                                                            <label class="col-xs-12 col-sm-4 control-label"><?php echo $adfs->name.($adfs->reg_require ? ' *' : ''); ?></label>
                                                            <input type="hidden" name="extra_id[<?php echo $adfs->id; ?>]" value="<?php echo $adfs->id; ?>" />
                                                            <input type="hidden" name="extra_ftype[<?php echo $adfs->id; ?>]" value="<?php echo $adfs->field_type; ?>" />
                                                            <div class="col-sm-8">
                                                                <?php switch ($adfs->field_type) {
                                                                    case '1': echo $adfs->selvals;
                                                                    break;
                                                                    case '2': echo '<textarea class="form-control" name="extraf['.$adfs->id.']" rows="6">'.htmlspecialchars(isset($adfs->fvalue_text) ? ($adfs->fvalue_text) : '', ENT_QUOTES).'</textarea>';
                                                                    break;
                                                                    case '3': echo isset($adfs->selvals) ? $adfs->selvals : '';
                                                                    break;
                                                                    case '0':
                                                                    default: echo '<input type="text" class="form-control '.($adfs->reg_require ? ' required' : '').'" maxlength="255" name="extraf['.$adfs->id.']" value="'.(isset($adfs->fvalue) ? htmlspecialchars($adfs->fvalue) : '').'" />';
                                                                    break;
                                                                } ?>
                                                            </div>
                                                        </div>
                                                        <?php
                                                    }
                                                }
                                                ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="jsrespdiv12">
                            <div class="jsBepanel">
                                <div class="jsBEheader"><?php echo JText::_('BLFA_ABOUT_PLAYER'); ?></div>
                                <div class="jsBEsettings">
                                    <div class="form-horizontal">
                                        <textarea name="about" id="aboutPlayer" rows="6">
                                            <?php echo htmlspecialchars($this->lists['usr']->about, ENT_QUOTES) ?>
                                        </textarea>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="jsrespdiv12">
                            <div class="jsBepanel">
                                <div class="jsBEheader"><?php echo JText::_('BL_TAB_PHOTOS'); ?></div>
                                <div class="jsBEsettings">
                                    <div class="form-horizontal">
                                        <div class="clearfix js-row">
                                            <div class="table-responsive col-xs-12 col-lg-12">
                                                <table class="table jstable-centered">
                                                    <?php if (isset($this->lists['photos']) && count($this->lists['photos'])) { ?>
                                                        <thead>
                                                            <tr>
                                                                <th width="10%"><?php echo JText::_('BLFA_DEFAULT') ?></th>
																<th width="80%"><?php echo JText::_('BLFA_IMAGE') ?></th>
																<!-- <th width="40%"><?php // echo JText::_('BLFA_TITLE') ?></th> -->
                                                                <th width="10%">
                                                                    #
                                                                    <?php // echo JText::_('BLFA_DELETE') ?>
                                                                </th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            <?php
                                                            foreach ($this->lists['photos'] as $photos) {
                                                                ?>
                                                                <tr>
                                                                    <td>
                                                                        <div class="js_radio js_radio-success">
                                                                            <?php $ph_checked = ($this->lists['usr']->def_img == $photos->id) ? 'checked="true"' : ''; ?>
                                                                            <input type="radio" id="ph_default_<?php echo $photos->id; ?>" name="ph_default" value="<?php echo $photos->id; ?>" <?php echo $ph_checked ?>/>
                                                                            <label for="ph_default_<?php echo $photos->id; ?>"><span></span></label>
                                                                            <input type="hidden" name="photos_id[]" value="<?php echo $photos->id; ?>"/>
                                                                        </div>
                                                                    </td>
                                                                    <td>
                                                                        <?php
                                                                        $imgsize = getimagesize('media/bearleague/'.$photos->filename);
                                                                        if ($imgsize[0] > 200) {
                                                                            $width = 200;
                                                                        } else {
                                                                            $width = $imgsize[0];
                                                                        }
                                                                        ?>
                                                                        <img class="img-responsive mw50" src="<?php echo JURI::base(); ?>media/bearleague/<?php echo $photos->filename ?>" width="<?php echo $width; ?>" />
                                                                    </td>
																	<?php // echo '<td><input type="text" maxlength="255" name="ph_names[]" value="'. htmlspecialchars($photos->name) .'" /></td>'; ?>
                                                                    <td>
                                                                        <button type="button" class="closerem" onclick="javascript:Delete_tbl_row(this);"><i class="glyphicon glyphicon-remove-circle"></i><span class="sr-only"><?php echo JText::_('BLFA_REMOVE') ?></span></button>
                                                                    </td>
                                                                </tr>
                                                            <?php } ?>
                                                        </tbody>
                                                        <?php
                                                    }
                                                    ?>
                                                    <tfoot class="upload">
                                                        <tr><td></td></tr>
                                                        <tr class="tfoot_header">
                                                            <td colspan="4" class="text-center"><?php echo JText::_('BLFA_UPLOADPHOT'); ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td colspan="2">
                                                                <input type="file" name="player_photo_1" value="" id="player_photo_1" >
                                                            </td>
                                                    		<td>
                                                                <button type="button" id="player_photo" class="btn btn-success"><?php echo JText::_('BLFA_UPLOAD'); ?></button>
                                                                <script type="text/javascript">
                                                                    var photo1 = document.getElementById("player_photo_1");
                                                                    var but_on = document.getElementById("player_photo");
                                                                    var serv_sett = <?php echo $this->lists['post_max_size']; ?>;
                                                                    but_on.onclick = function() {
                                                                        if (photo1.files[0]) {
                                                                            var size_img = photo1.files[0].size;
                                                                        }
                                                                        if (size_img > serv_sett) {
                                                                            alert("Image too big (change settings post_max_size)");
                                                                            return false;
                                                                        } else {
                                                                            submitbutton('playerreg_save');
                                                                        }
                                                                    };
                                                                </script>
                                                            </td>
                                                        </tr>
                                                    </tfoot>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="jsTextAlignRight">
                    	<button class="btn btn-success" type="submit" onclick="return document.formvalidator.isValid(document.id('adminForm'));"><i class="glyphicon glyphicon-floppy-disk"></i> <?php echo JText::_('BLFA_SAVE'); ?></button>
                    </div>
                    <input type="hidden" name="id" value="<?php echo isset($this->lists['usr']->id) ? $this->lists['usr']->id : 0 ?>" />
                    <input type="hidden" name="return" value="<?php echo isset($this->lists['return']) ? $this->lists['return'] : '' ?>" />
                    <input type="hidden" name="sid" value="<?php echo isset($this->sid) ? $this->sid : 0 ?>" />
                    <input type="hidden" name="task" value="playerreg_save" />
                </form>
            </div>
        </div>
    </div>
</div>