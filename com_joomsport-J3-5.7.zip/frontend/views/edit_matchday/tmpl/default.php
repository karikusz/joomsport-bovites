<?php
/* ------------------------------------------------------------------------
  # JoomSport Professional
  # ------------------------------------------------------------------------
  # BearDev development company
  # Copyright (C) 2011 JoomSport.com. All Rights Reserved.
  # @license - http://joomsport.com/news/license.html GNU/GPL
  # Websites: http://www.JoomSport.com
  # Technical Support:  Forum - http://joomsport.com/helpdesk/
------------------------------------------------------------------------- */
// no direct access
defined('_JEXEC') or die('Restricted access');
if (isset($this->message)) {
    $this->display('message');
}
$row = $this->row;
$lists = $this->lists;
$s_id = $lists['s_id'];
$match = $lists['match'];
global $Itemid;

if ($this->acl == 1) {
    $ctrl = 'admin';
} elseif ($this->acl == 2) {
    $ctrl = 'moder';
} else {
    $ctrl = 'users';
}

$Itemid = JRequest::getInt('Itemid');
$doc = JFactory::getDocument();

?>
<div id="joomsport-container">
    <div class="page-content">
        <nav class="navbar navbar-default navbar-static-top" role="navigation">
            <?php echo $lists['panel']; ?>
        </nav>
        <!-- /.navbar -->

        <div class="jsFEedit <?php echo $lists['t_type'] ? 'editDraw' : 'editMatchDay' ?>">
            <div class="heading col-xs-12 col-lg-12">
                <h2 class="pull-left col-xs-12 col-sm-12 col-md-4 col-lg-4"><?php echo $row->id ? JText::_('BLFA_MDAY_EDIT') : JText::_('BLFA_MDAY_NEW'); ?></h2>
                <div class="selection col-xs-12 col-sm-12 col-md-8 col-lg-8">
                    <?php if ($this->acl == 1): ?>
                        <form action='<?php echo JURI::base(); ?>index.php?option=com_joomsport&task=edit_matchday&controller=moder&Itemid=<?php echo $Itemid ?>' method='post' name='chg_team'>
                            <?php if (isset($this->lists['seass_filtr'])): ?>
                                <label class="selected"><?php echo $this->lists['tourn_name']; ?></label>
                            <?php endif; ?>
                            <div class="data">
                                <?php if (isset($this->lists['seass_filtr'])): ?>
                                    <?php echo $this->lists['seass_filtr']; ?>
                                <?php endif; ?>
                                <?php
                                if (isset($this->lists['tm_filtr'])) {
                                    echo $this->lists['tm_filtr'];
                                }
                                ?>
                            </div>
                        </form>
                        <form action="<?php echo JUri::base().'index.php?option=com_joomsport&controller=moder&view=edit_matchday&tid='.$lists['tid'].'&Itemid='.$Itemid; ?>" method="post" name="filtrForm">
                            <div class="data">
                                <?php if (isset($lists['md_filtr']) && $lists['md_filtr']) { ?>
                                    <?php echo $lists['md_filtr']; ?>
                                <?php } ?>
                            </div>
                        </form>
                    <?php endif; ?>
                    <?php if ($this->acl == 3): ?>
                        <form action="<?php echo 'index.php?option=com_joomsport&view=moderedit_umatchday&controller=users&Itemid='.$Itemid; ?>" method="post" name="filtrForm">
                            <label class="selected"><?php echo JText::_('BLFA_FILTERS') ?></label>
                            <div class="data">
                                <?php echo $lists['seas_filtr']; ?>
                                <?php if ($lists['md_filtr']) { ?>
                                    <?php echo $lists['md_filtr']; ?>
                                <?php } ?>
                            </div>
                        </form>
                    <?php endif; ?>

                    <?php if ($this->acl == 2): ?>
                        <form action='<?php echo JURI::base(); ?>index.php?option=com_joomsport&task=edit_matchday&tid=<?php echo $lists['tid']?>&controller=moder&Itemid=<?php echo $Itemid ?>' method='post' name='chg_team'>
                            <?php if (isset($this->lists['seass_filtr_nofr'])) { ?>
                                <label class="selected"><?php echo $this->lists['tourn_name']; ?></label>
                            <?php } ?>
                            <div class="data">
                                <?php echo $this->lists['tm_filtr']; ?>
                                <?php if (isset($this->lists['seass_filtr_nofr'])) { ?>
                                    <?php echo $this->lists['seass_filtr_nofr']; ?>
                                    <?php echo $lists['md_filtr'];
                                } ?>
                            </div>
                        </form>
                    <?php endif; ?>
                </div>
            </div>
            <div class="navbar-links col-xs-12 col-lg-12">
                <div class="row">
                    <div class="col-sm-push-7 col-sm-5 col-xs-12 text-right">
                        <?php if ($this->acl == 2): ?>
                            <ul class="nav navbar-nav">
                                <a class="btn btn-default" href="<?php echo JRoute::_('index.php?option=com_joomsport&controller=moder&view=edit_team&tid='.$lists['tid'].'&Itemid='.$Itemid); ?>" title=""><i class="js-team"></i><?php echo JText::_('BLFA_TEAM') ?></a>
                                <?php if ($lists['moder_addplayer']) { ?>
                                    <a class="btn btn-default" href="<?php echo JRoute::_('index.php?option=com_joomsport&controller=moder&view=admin_player&tid='.$lists['tid'].'&Itemid='.$Itemid) ?>" title=""><i class="js-pllist"></i><?php echo JText::_('BLFA_PLAYER') ?></a>
                                <?php } ?>
                            </ul>
                            <!-- </tab box> -->
                        <?php endif; ?>
                        <?php if ($this->acl == 3): ?>
                            <ul class="nav navbar-nav">
                                <a class="btn btn-default" href="<?php echo JRoute::_('index.php?option=com_joomsport&task=regplayer&Itemid='.$Itemid); ?>" title=""><i class="js-player"></i><?php echo JText::_('BLFA_PLAYERR') ?></a>
                            </ul>
                        <?php endif; ?>
                    </div>
                    <div class="admin-tools col-sm-pull-5 col-sm-7 col-xs-12">
                        <?php if ($this->acl == 1): ?>
                            <a class="btn btn-success" href="javascript:void(0);" title="<?php echo JText::_('BLFA_SAVE') ?>" onclick="javascript:submitbutton('matchday_save');
                            return false;"><i class="glyphicon glyphicon-floppy-disk"></i> <?php echo JText::_('BLFA_SAVE') ?></a>
                            <a class="btn btn-default btn-icon" href="javascript:void(0);" title="<?php echo JText::_('BLFA_APPLY') ?>" onclick="javascript:submitbutton('matchday_apply');
                            return false;"><i class="glyphicon glyphicon-ok"></i> <?php echo JText::_('BLFA_APPLY') ?></a>
                            <a class="btn btn-default btn-icon" href="<?php echo JRoute::_('index.php?option=com_joomsport&controller=admin&task=admin_matchday&sid='.$s_id.'&Itemid='.$Itemid) ?>" title="<?php echo JText::_('BLFA_CLOSE') ?>"><i class="glyphicon glyphicon-remove-sign"></i> <?php echo JText::_('BLFA_CLOSE') ?></a>
                        <?php endif; ?>
                        <?php if (($this->acl == 2 && isset($this->lists['seass_filtr'])) || $this->acl == 3): ?>
                            <a class="btn btn-success" href="javascript:void(0);" title="<?php echo JText::_('BLFA_SAVE') ?>" onclick="javascript:submitbutton('matchday_save');
                            return false;"><i class="glyphicon glyphicon-floppy-disk"></i> <?php echo JText::_('BLFA_SAVE') ?></a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <div class="jsClear"></div>
            <div>
                <form name="adminForm" id="adminForm" action="" class="form-horizontal" method="post">
                    <?php 
                    if ($this->acl == 1) {
                        ?>
                        <div class="jsrespdiv12">
                            <div class="jsBepanel">
                                <div class="jsBEheader"><?php echo JText::_('BLFA_MATCHDAY'); ?></div>
                                <div class="jsBEsettings">
                                    <div class="form-horizontal">
                                        <div class="form-group">
                                            <label for="inputMatchDay" class="col-xs-12 col-sm-4 control-label"><?php echo JText::_('BLFA_MATCHDAYNAME'); ?></label>
                                            <div class="col-sm-8">
                                                <input type="text" id="inputMatchDay" name="m_name" maxlength="255" value="<?php echo htmlspecialchars($row->m_name) ?>" />
                                            </div>
                                        </div>
                                        <?php if (!$lists['t_type']) {
                                            ?>
                                            <div class="form-group">
                                                <label class="control-label col-sm-4"><?php echo JText::_('BLFA_ISPLAYOFF'); ?></label>
                                                <div class="col-sm-8">
                                                    <fieldset class="btn-group-js squardbut">
                                                        <div class="controls">
                                                            <label for="is_playoff_0" class="radio btn">
                                                                <input type="radio" id="is_playoff_0" name="is_playoff" value="0" <?php echo!$row->is_playoff ? 'checked="checked"' : '' ?>/>
                                                                <?php echo JText::_('JNO'); ?>
                                                            </label>
                                                            <label for="is_playoff1" class="radio btn">
                                                                <input type="radio" id="is_playoff1" name="is_playoff" value="1" <?php echo $row->is_playoff ? 'checked="checked"' : '' ?>/>
                                                                <?php echo JText::_('JYES'); ?>
                                                            </label>
                                                        </div>
                                                    </fieldset>
                                                </div>
                                            </div>
                                            <?php
                                        }
                                        ?>
                                        <?php
                                        if ($lists['t_type'] && $this->acl == 1) {
                                            ?>
                                            <div class="form-group">
                                                <label for="inputMatchDay" class="col-xs-12 col-sm-4 control-label"><?php echo $lists['t_type'] == 2 ? JText::_('BLFA_DOUBLE') : JText::_('BLFA_KNOCK') ?></label>
                                                <div class="col-sm-8">
                                                    <?php echo $lists['format']; ?>

                                                    <?php
                                                    if ($lists['t_type'] == 1) {
                                                        $javascript = 'jQuery.post( \''.JUri::Base().'index.php?tmpl=component&option=com_joomsport&task=get_format&controller=admin&format=row&sid='.$s_id.'&t_single='.$lists['t_single'].'&fr_id=\'+jQuery(\'#format_post\').val(), function( data ) {jQuery(\'#mapformat\').html( data );});';
                                                    } elseif ($lists['t_type'] == 2) {
                                                        $javascript = 'jQuery.post( \''.JUri::Base().'index.php?tmpl=component&option=com_joomsport&task=get_formatkn&controller=admin&format=row&sid='.$s_id.'&t_single='.$lists['t_single'].'&fr_id=\'+jQuery(\'#format_post\').val(), function( data ) {jQuery(\'#mapformat\').html( data );});';
                                                    } elseif ($lists['t_type'] == 3) {
                                                        $javascript = 'jQuery.post( \''.JUri::Base().'index.php?tmpl=component&option=com_joomsport&task=get_formatcomplex&controller=admin&format=row&sid='.$s_id.'&t_single='.$lists['t_single'].'&fr_id=\'+jQuery(\'#format_post\').val(), function( data ) {jQuery(\'#mapformat\').html( data );partfull = jQuery(\'#js_selpartic_0_0 option\');jQuery(\'.jsproceednext\').hide();});';
                                                    }
                                                    ?>
                                                    <button onclick="<?php echo $javascript; ?>" type="button" class="btn btn-success">Generate</button>
                                                </div>
                                            </div>
                                            <?php
                                        }
                                        ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php
                    }
                    ?>

                    <?php
                    if ($lists['t_type'] && $this->acl == 1) {
                        ?>
                        <!--draw starts-->
                        <div class="table-responsive col-xs-12 col-lg-12" id="mapformat">
                            <?php
                            if (count($lists['match']) && isset($lists['knock_layout'])) {
                                echo $lists['knock_layout'];
                            }
                            ?>
                        </div>
                        <!--draw ends-->
                        <?php
                    } else {
                        ?>
                        <div class="jsrespdiv12">
                            <div class="jsBepanel">
                                <div class="jsBEheader"><?php echo JText::_('BLFA_MATCHRESULTS'); ?></div>
                                <div class="jsBEsettings">
                                    <div class="clearfix js-row">
                                        <div class="table-responsive col-xs-12">
                                            <table class="table jstable-centered">
                                                <tbody id="new_matches">
                                                    <?php
                                                    $cx = 0;
                                                    if (count($match)) {
                                                        foreach ($match as $curmatch) {
                                                            $moder_or_pl = ($this->acl == 3) ? ($curmatch->team1_id == $this->lists['usr']->id) : (in_array($curmatch->team1_id, $this->lists['teams_season']));
                                                            $moder_or_pl2 = ($this->acl == 3) ? ($curmatch->team2_id == $this->lists['usr']->id) : (in_array($curmatch->team2_id, $this->lists['teams_season']));

                                                            switch ($this->acl) {
                                                                case '2':
                                                                $match_link = 'index.php?option=com_joomsport&amp;controller=moder&amp;view=edit_match&amp;cid[]='.$curmatch->id.'&amp;controller=moder&amp;sid='.$s_id.'&amp;tid='.$lists['tid'].'&Itemid='.$Itemid;
                                                                break;
                                                                case '3':
                                                                $match_link = jUri::base().'index.php?option=com_joomsport&amp;controller=users&amp;view=moderedit_umatch&amp;cid[]='.$curmatch->id.'&Itemid='.$Itemid;
                                                                break;
                                                                default:
                                                                $match_link = 'index.php?option=com_joomsport&amp;controller=admin&amp;view=edit_match&amp;cid[]='.$curmatch->id.'&amp;controller=admin&amp;sid='.$s_id.'&amp;Itemid='.$Itemid;
                                                            }
                                                            ?>
                                                            <tr class="<?php echo $cx % 2 ? 'active' : 'noBB' ?>">
                                                                <td class="tdJsRemove" rowspan="2">
                                                                    <?php
                                                                    if ($this->acl != 1 && ($lists['t_type'] == 1 || ($lists['jsmr_mark_played'] == 0 && $curmatch->m_played == 1) || $lists['t_type'] == 2)) {
                                                                        echo '<input type="hidden" name="match_id[]" value="'.$curmatch->id.'" />';
                                                                    } else {
                                                                        echo '<input type="hidden" name="match_id[]" value="'.$curmatch->id.'" /><button type="button" onclick="Delete_tbl_row_md(this); return false;" class="closerem"><i class="glyphicon glyphicon-remove-circle"></i><span class="sr-only">'.JText::_('BLFA_DELETE').'</span></button>';
                                                                    }
                                                                    ?>
                                                                </td>
                                                                <td class="js_mteam"><input type="hidden" name="home_team[]" value="<?php echo $curmatch->team1_id ?>" /><?php echo $curmatch->home_team ?></td>
                                                                <td>
                                                                    <div>
                                                                        <?php
                                                                        if ($this->acl == 1) {
                                                                            echo '<input class="form-control score" type="text" name="home_score[]" value="'.$curmatch->score1.'" size="3" maxlength="5" onblur="extractNumber(this,0,false);" onkeyup="extractNumber(this,0,false);" onkeypress="return blockNonNumbers(this, event, false, false);" /><span> : </span><input class="form-control score" type="text" name="away_score[]" value="'.$curmatch->score2.'" size="3" maxlength="5" onblur="extractNumber(this,0,false);" onkeyup="extractNumber(this,0,false);" onkeypress="return blockNonNumbers(this, event, false, false);" />';
                                                                        } else {
                                                                            if ($lists['t_type'] == 1 || $lists['t_type'] == 2) {
                                                                                echo '<input class="form-control score" disabled="true" type="text" readonly="true" name="home_score[]" value="'.$curmatch->score1.'" size="3" maxlength="5" /><span> : </span><input class="form-control score" disabled="true" type="text" readonly="true" name="away_score[]" value="'.$curmatch->score2.'" size="3" maxlength="5" />';
                                                                            } else {
                                                                                $hidden1 = false;
                                                                                $hidden2 = false;
                                                                                if (($lists['jsmr_mark_played'] == 0 && $curmatch->m_played) == 1 || (($this->lists['jsmr_editresult_opposite'] == 0 && !$moder_or_pl) || ($this->lists['jsmr_editresult_yours'] == 0 && $moder_or_pl))) {
                                                                                    $hidden1 = true;
                                                                                }
                                                                                if (($lists['jsmr_mark_played'] == 0 && $curmatch->m_played) == 1 || (($this->lists['jsmr_editresult_opposite'] == 0 && !$moder_or_pl2) || ($this->lists['jsmr_editresult_yours'] == 0 && $moder_or_pl2))) {
                                                                                    $hidden2 = true;
                                                                                }
                                                                                echo '<input class="form-control score" type="text" name="home_score[]" value="'.$curmatch->score1.'" size="3" maxlength="5" onblur="extractNumber(this,0,false);" onkeyup="extractNumber(this,0,false);" onkeypress="return blockNonNumbers(this, event, false, false);" '.($hidden1 ? 'disabled="true"' : '').' />';
                                                                                echo '<span> : </span>';
                                                                                echo '<input class="form-control score" type="text" name="away_score[]" value="'.$curmatch->score2.'" size="3" maxlength="5" onblur="extractNumber(this,0,false);" onkeyup="extractNumber(this,0,false);" onkeypress="return blockNonNumbers(this, event, false, false);" '.($hidden2 ? 'disabled="true"' : '').' />';
                                                                            }
                                                                        }
                                                                        ?>
                                                                    </div>
                                                                    <?php
                                                                    if ($lists['s_enbl_extra']) {
                                                                        ?>
                                                                        <div class="js_extra_time">
                                                                            <span class="js_checkbox js_checkbox-warning">
                                                                                <?php echo '<input type="checkbox" id="et_'.$curmatch->id.'" name="extra_time[]" value="'.(($curmatch->is_extra) ? 1 : 0).'" '.(($curmatch->is_extra) ? 'checked' : '').' />'; ?>
                                                                                <label for="et_<?php echo $curmatch->id;?>">
                                                                                    <span class="glyphicon glyphicon-ok"></span>
                                                                                </label>
                                                                            </span>
                                                                            <span><?php echo JText::_('BLFA_ET'); ?></span>
                                                                        </div>
                                                                        <?php
                                                                    }
                                                                    ?>
                                                                </td>
                                                                <td class="js_mteam"><input type="hidden" name="away_team[]" value="<?php echo $curmatch->team2_id ?>" /><?php echo $curmatch->away_team ?></td>
                                                                <td class="jsSelecWidth">
                                                                    <?php
                                                                    if ($lists['jsmr_mark_played'] == 1) {
                                                    //$selvals = $this->_lists['m_played_i'] = array_merge($tmp_arr,$selvals);
                                                                        echo JHTML::_('select.genericlist',   $lists['m_played_i'], 'match_played[]', 'class="inputbox" size="1"', 'id', 'value', $curmatch->m_played);

                                                    //echo JText::_('BLFA_ISPLAYED') . ' <input type="checkbox" name="match_played[]" value="' . ($curmatch->m_played ? 1 : 0) . '" ' . ($curmatch->m_played ? "checked" : "") . ' />';
                                                                    }
                                                                    ?>
                                                                </td>
                                                            </tr>
                                                            <tr class="<?php echo $cx % 2 ? 'active' : 'noBB' ?> jsmfirstTR">
                                                                <td>
                                                                    <input class="form-control jsdtime" type="date" name="match_data[]" maxlength="5" size="12" value="<?php echo $curmatch->m_date ?>" />
                                                                </td>
                                                                <td>
                                                                    <input class="form-control jstime" type="text" name="match_time[]" maxlength="5" size="12" value="<?php echo substr($curmatch->m_time, 0, 5) ?>" />
                                                                </td>
                                                                <td>
                                                                    <?php echo $curmatch->venue_name ?><input type="hidden" name="venue_id[]" value="<?php echo $curmatch->venue_id ?>">
                                                                </td>
                                                                <td>
                                                                    <?php
                                                                    if ($lists['jsmr_mark_played'] == 0 && $curmatch->m_played == 1 && $this->acl != 1) {
                                                                        echo '&nbsp;';
                                                                    } else {
                                                                        echo '<a href="'.$match_link.'">'.JText::_('BLFA_MATCHDETAILS').'</a>';
                                                                    }
                                                                    ?>
                                                                </td>
                                                            </tr>

                                                            <?php
                                                            ++$cx;
                                                        }
                                                    }
                                                    ?>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>


                        <div class="clearfix"></div>
                        <?php
                        if ((($lists['t_type'] == 1 || $lists['t_type'] == 2) && $this->acl != 1) || (isset($lists['moder_create_match']) && $lists['moder_create_match']!='1' &&  $this->acl == 2)) {
                        } else {
                            ?>
                            <div class="jsrespdiv12">
                                <div class="jsBepanel">
                                    <div class="jsBEheader"><?php echo JText::_('BLFA_ADDMATCHRESULTS'); ?></div>
                                    <div class="jsBEsettings">
                                        <div class="clearfix js-row">
                                            <div class="table-responsive col-xs-12">
                                                <table class="table jstable-centered">
                                                    <tbody id="add_match">
                                                        <tr class="noBB">
                                                            <td>
                                                                <div>
                                                                    <?php echo $lists['t_single'] ? JText::_('BLFA_HOMEPLAYER') : JText::_('BLFA_HOMETEAM'); ?>
                                                                </div>
                                                                <div>
                                                                    <?php echo $lists['teams1'] ?>
                                                                </div>

                                                            </td>
                                                            <td>
                                                                <div>
                                                                    <?php // echo JText::_('BLFA_SCORE');?>
                                                                    <input type="text" class="form-control score" name="add_score1" id="add_score1" placeholder=" ">
                                                                    <span> : </span>
                                                                    <input type="text" class="form-control score" name="add_score2" id="add_score2" placeholder="">
                                                                </div>
                                                                <div class="js_extra_time">
                                                                    <?php if ($lists['s_enbl_extra']) {
                                                                        ?>
                                                                        <span class="js_checkbox js_checkbox-warning">
                                                                            <input type="checkbox" name="extra_timez" id="extra_timez" />
                                                                            <label for="extra_timez">
                                                                                <span class="glyphicon glyphicon-ok"></span>
                                                                            </label>
                                                                        </span>
                                                                        <span>
                                                                            <?php // echo JText::_('BLFA_EXTRATIMEF'); ?>
                                                                            <?php echo JText::_('BLFA_ET'); ?>
                                                                        </span>
                                                                        <?php
                                                                    }
                                                                    ?>
                                                                </div>
                                                            </td>
                                                            <td>
                                                                <div>
                                                                    <?php echo $lists['t_single'] ? JText::_('BLFA_AWAYPLAYER') : JText::_('BLFA_AWAYTEAM'); ?>
                                                                </div>
                                                                <div>
                                                                    <?php echo $lists['teams2'] ?>
                                                                </div>

                                                            </td>
                                                            <td class="jsSelecWidth">
                                                                <?php
                                                                if ($lists['jsmr_mark_played'] == 1) {
                                                                    ?>
                                                                    <!-- <div><?php // echo JText::_('JSTATUS'); ?></div> -->
                                                                    <div id="jstmplayedclone"><?php echo $lists['m_played']; ?></div>
                                                                    <?php
                                                                }
                                                                ?>
                                                            </td>
                                                        </tr>
                                                        <tr class="noBB jsmfirstTR">
                                                            <td>
                                                                <div><?php // echo JText::_('BLFA_DATE'); ?></div>
                                                                <div><input type="date" class="date" id="tm_date" name="tm_date"></div>
                                                            </td>
                                                            <td>
                                                                <div><?php // echo JText::_('BLFA_TIME'); ?></div>
                                                                <div><input type="text" class="time" name="match_time_new" id="match_time_new" maxlength="5" size="12" value="00:00" /></div>
                                                            </td>
                                                            <td>
                                                                <div><?php // echo JText::_('BLFA_VENUE'); ?></div>
                                                                <div><?php echo $lists['venue_name']; ?></div>
                                                            </td>
                                                            <td>
                                                                <button type="button" class="btn btn-success" onclick="bl_add_match(); return false;" class="btn"><?php echo JText::_('BLFA_ADD'); ?></button>
                                                            </td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="clearfix"></div>
                            <?php
                        }
                        ?>
                        <?php
                    } ?>
                    <input type="hidden" name="return_sh" value="0" />
                    <input type="hidden" name="task" value="admin_matchday" />
                    <input type="hidden" name="id" value="<?php echo $row->id ?>" />
                    <?php if ($row->id) {
                        ?>
                        <input type="hidden" name="format_post" value="<?php echo $row->k_format ?>" />
                        <?php
                    } ?>

                    <input type="hidden" name="isapply" value="0" />
                    <?php if ($this->acl == 1) {
                        ?>
                        <input type="hidden" name="sid" value="<?php echo $s_id;
                        ?>" />
                        <input type="hidden" name="t_single" value="<?php echo $lists['t_single'] ?>" />
                        <input type="hidden" name="t_knock" value="<?php echo $lists['t_type'] ?>" />
                        <!--<input type="hidden" name="t_type" value="<?php //echo $lists['t_type']  ?>" />-->
                        <?php
                    } else {
                        ?>
                        <input type="hidden" name="tid" value="<?php echo $lists['tid'] ?>" />
                        <input type="hidden" name="sid" value="<?php echo $s_id ?>" />
                        <input type="hidden" name="mid" value="<?php echo $lists['mid'] ?>" />
                        <input type="hidden" name="t_knock" value="<?php echo $lists['t_type'] ?>" />
                        <input type="hidden" name="t_type" value="<?php echo $lists['t_type'] ?>" />
                        <?php
                    } ?>
                    <?php echo JHTML::_('form.token'); ?>
                </form>
            </div>
            <div class="jsClear"></div>
        </div>
    </div>
</div>
<script type="text/javascript">
    <!--
        function in_array(what, where) {
            for (var i = 0, length_array = where.length; i < length_array; i++)
                if (what == where[i])
                    return true;
                return false;
            }
            function submitbutton(pressbutton) {
                var form = document.adminForm;
                if (pressbutton == 'matchday_save' || pressbutton == 'matchday_apply') {
                    if ('<?php echo $this->acl ?>' == 1) {
                        if (form.m_name.value == "" || form.sid.value == 0) {
                            alert("<?php echo JText::_('BL_ENTRNTS'); ?>");
                            return false;
                        }

                        if ('<?php echo $lists['t_type'] ?>' == 1 || '<?php echo $lists['t_type'] ?>' == 2) {
                            var arrpl = new Array();
                            var partip = eval("document.adminForm['teams_kn[]']");
                            var partip_aw = eval("document.adminForm['teams_kn_aw[]']");
                            if (partip) {
                                if (partip.options) {
                                    if (!in_array(partip.value, arrpl)) {
                                        if (partip.value != '0' && partip.value != '-1') {
                                            arrpl.push(partip.value);
                                        }

                                    } else {
                                        alert(partip.options[partip.selectedIndex].text + ' <?php echo JText::_('BLFA_KN_DUBL'); ?>');
                                        return false;
                                    }
                                } else {
                                    for (i = 0; i < partip.length; i++) {



                                        if (!in_array(partip[i].value, arrpl)) {
                                            if (partip[i].value != '0' && partip[i].value != '-1') {
                                                arrpl.push(partip[i].value);
                                            }

                                        } else {
                                            alert(partip[i].options[partip[i].selectedIndex].text + ' <?php echo JText::_('BLFA_KN_DUBL'); ?>');
                                            return false;
                                        }

                                    }

                                }
                            }
                            if (partip_aw) {
                                if (partip_aw.options) {

                                    if (!in_array(partip_aw.value, arrpl)) {
                                        if (partip_aw.value != '0' && partip_aw.value != '-1') {
                                            arrpl.push(partip_aw.value);
                                        }

                                    } else {
                                        alert(partip_aw.options[partip_aw.selectedIndex].text + ' <?php echo JText::_('BLFA_KN_DUBL'); ?>');
                                        return false;
                                    }

                                } else {
                                    for (i = 0; i < partip_aw.length; i++) {



                                        if (!in_array(partip_aw[i].value, arrpl)) {
                                            if (partip_aw[i].value != '0' && partip_aw[i].value != '-1') {
                                                arrpl.push(partip_aw[i].value);
                                            }

                                        } else {
                                            alert(partip_aw[i].options[partip_aw[i].selectedIndex].text + ' <?php echo JText::_('BLFA_KN_DUBL'); ?>');
                                            return false;
                                        }

                                    }
                                }
                            }
                        }
                    }
                    var extras = eval("document.adminForm['extra_time[]']");
                    if (extras) {
                        if (extras.length) {
                            for (i = 0; i < extras.length; i++) {
                                if (extras[i].checked) {
                                    extras[i].value = 1;
                                } else {
                                    extras[i].value = 0;
                                }
                                extras[i].checked = true;
                            }
                        } else {
                            if (extras.checked) {
                                extras.value = 1;
                            } else {
                                extras.value = 0;
                            }
                            extras.checked = true;
                        }
                    }

                        ///}
                        if (pressbutton == 'matchday_apply') {
                            form.isapply.value = '1';
                            pressbutton = 'matchday_save';
                        }

                        var errortime = '';
                        var mt_time = eval("document.adminForm['match_time[]']");
                        if (mt_time) {
                            if (mt_time.length) {
                                for (i = 0; i < mt_time.length; i++) {
                                    var regE = /[0-2][0-9]:[0-5][0-9]/;
                                    if (!regE.test(mt_time[i].value) && mt_time[i].value != '') {
                                        errortime = '1';
                                        mt_time[i].style.border = "1px solid red";
                                    } else {
                                        mt_time[i].style.border = "1px solid #C0C0C0";
                                    }
                                }
                            } else {
                                var regE = /[0-2][0-9]:[0-5][0-9]/;
                                if (!regE.test(mt_time.value) && mt_time.value != '') {
                                    errortime = '1';
                                    mt_time.style.border = "1px solid red";
                                } else {
                                    mt_time.style.border = "1px solid #C0C0C0";
                                }
                            }
                        }

                        if (errortime) {
                            alert("<?php echo JText::_('BLBE_JSMDNOT7'); ?>");
                            return;
                        } else {
                            submitform(pressbutton);
                            return;
                        }

                    } else {
                        submitform(pressbutton);
                        return;
                    }
                }

                function bl_add_match() {
                    var team1 = getObj('teams1');
                    var team2 = getObj('teams2');
                    var score1 = getObj('add_score1').value;
                    var score2 = getObj('add_score2').value;
                    var venue_id = getObj('venue_id_new');
                    if ('<?php echo $lists['jsmr_mark_played'] ?>' == 1) {
                        var tm_played = getObj('tm_played').checked;
                    }

                    if (team1.value == 0 || team2.value == 0) {
                        alert("<?php echo JText::_('BLFA_JSMDNOT1') ?>");
                        return false;
                    }
                    if ('<?php echo $lists['jsmr_mark_played'] ?>' == 1) {
                        if (((score1) == '' || (score2) == '') && tm_played) {
                            alert("<?php echo JText::_('BLFA_JSMDNOT1') ?>");
                            return;
                        }
                    }
                    if ('<?php echo $this->acl ?>' == 1) {
                        if (team1.value == team2.value) {
                            alert("<?php echo ($lists['t_single'] == 1) ? JText::_('BLFA_JSMDNOTPL2') : JText::_('BLFA_JSMDNOT2') ?>");
                            return false;
                        }
                    } else {
                        if (team1.value == team2.value || (team1.value != '<?php echo isset($lists['tid']) ? $lists['tid'] : 0 ?>' && team2.value != '<?php echo isset($lists['tid']) ? $lists['tid'] : 0 ?>')) {

                            alert("<?php echo ($this->acl == 3) ? JText::_('BLFA_JSMDNOTPART') : JText::_('BLFA_JSMDNOTPART') ?>");
                            return false;

                        }
                    }

                    var regE = /[0-2][0-9]:[0-5][0-9]/;
                    if (!regE.test(getObj('match_time_new').value) && getObj('match_time_new').value != "") {
                        alert("<?php echo JText::_('BLBE_JSMDNOT7') ?>");
                        return false;
                    }
                    var tbl_elem = getObj('new_matches');
                    var row = tbl_elem.insertRow(tbl_elem.rows.length);

                    var cell1 = document.createElement("td");
                    var cell2 = document.createElement("td");
                    var cell3 = document.createElement("td");
                    var cell4 = document.createElement("td");
                    var cell5 = document.createElement("td");

                    var input_hidden = document.createElement("input");
                    input_hidden.type = "hidden";
                    input_hidden.name = "match_id[]";
                    input_hidden.value = 0;
                    cell1.appendChild(input_hidden);
                    cell1.innerHTML = '<button type="button" onclick="Delete_tbl_row_md(this); return false;" class="closerem"><i class="glyphicon glyphicon-remove-circle"></i><span class="sr-only"><?php echo JText::_('BLFA_DELETE'); ?></span></button>';
                    cell1.setAttribute("rowspan", 2);
                    var input_hidden = document.createElement("input");
                    input_hidden.type = "hidden";
                    input_hidden.name = "home_team[]";
                    input_hidden.value = team1.value;
                    cell2.innerHTML = team1.options[team1.selectedIndex].text;
                    cell2.className = "js_mteam";
                    cell2.appendChild(input_hidden);

                    var score_box = document.createElement("div");
                    var input_hidden = document.createElement("input");
                    input_hidden.type = "text";
                    input_hidden.className = "form-control score";
                    input_hidden.name = "home_score[]";
                    input_hidden.value = score1;
                    input_hidden.size = 3;
                    input_hidden.setAttribute("maxlength", 5);
                    input_hidden.onblur = function() {
                        extractNumber(this, 0, false);
                    };
                    input_hidden.onkeyup = function() {
                        extractNumber(this, 0, false);
                    };
                    input_hidden.onkeypress = function() {
                        return blockNonNumbers(this, event, true, false);
                    };
                    score_box.appendChild(input_hidden);

                    var txtnode = document.createTextNode(" : ");
                    score_box.appendChild(txtnode);

                    var input_hidden = document.createElement("input");
                    input_hidden.type = "text";
                    input_hidden.className = "form-control score";
                    input_hidden.name = "away_score[]";
                    input_hidden.value = score2;
                    input_hidden.size = 3;
                    input_hidden.setAttribute("maxlength", 5);
                    input_hidden.onblur = function() {
                        extractNumber(this, 0, false);
                    };
                    input_hidden.onkeyup = function() {
                        extractNumber(this, 0, false);
                    };
                    input_hidden.onkeypress = function() {
                        return blockNonNumbers(this, event, true, false);
                    };
                    score_box.appendChild(input_hidden);
                    cell3.appendChild(score_box);

                    if ('<?php echo $lists['s_enbl_extra'] ?>' == '1') {
                        var et_box = document.createElement("div");
                        et_box.className = "js_extra_time";
                        var check_block = document.createElement("span");
                        check_block.className = "js_checkbox js_checkbox-warning";
                        et_box.appendChild(check_block);
                        var input_hidden = document.createElement("input");
                        input_hidden.type = "checkbox";
                        input_hidden.id = "et_add";
                        input_hidden.name = "extra_time[]";

                        if (getObj('extra_timez').checked) {
                            input_hidden.checked = true;
                            input_hidden.value = '1';
                        } else {
                            input_hidden.value = '0';
                        }
                        check_block.appendChild(input_hidden);

                        var iiinn = document.createElement("label");
                        iiinn.setAttribute('for', "et_add");
                        var innn = document.createElement("span");
                        innn.className = "glyphicon glyphicon-ok";
                        iiinn.appendChild(innn);
                        check_block.appendChild(iiinn);
                        var check_block = document.createElement("span");
                        check_block.innerHTML = "<?php echo JText::_('BLFA_ET'); ?>";
                        et_box.appendChild(check_block);

                        cell3.appendChild(et_box);
                    }

                    var input_hidden = document.createElement("input");
                    input_hidden.type = "hidden";
                    input_hidden.name = "away_team[]";
                    input_hidden.value = team2.value;
                    cell4.innerHTML = team2.options[team2.selectedIndex].text;
                    cell4.className = "js_mteam";
                    cell4.appendChild(input_hidden);

                    if ('<?php echo $lists['jsmr_mark_played'] ?>' == 1) {
                        var jstmplayedclone = jQuery('#jstmplayedclone').children(0).clone();
                        var jstmplayedclone2 = jQuery('#jstmplayedclone').children(':first-child').next().clone();
                        var rand = Math.floor((Math.random() * 10000) + 1);
                        jstmplayedclone.removeAttr("tabindex");
                        jstmplayedclone.removeAttr("aria-hidden");
                        jstmplayedclone.prop({id:"match_played"+rand, name:"match_played[]", class:""});

                        //cell10.innerHTML = jstmplayedclone;
                        cell5.appendChild(jstmplayedclone.get(0));
                        cell5.setAttribute("rowspan", 2);
                        cell5.className = "jsSelecWidth";

                        //cell10.appendChild(jstmplayedclone2.get(0));
                    }

                    ////-------------new---------------////

                    var cell7 = document.createElement("td");
                    var cell8 = document.createElement("td");
                    var cell9 = document.createElement("td");

                    var input_hidden = document.createElement("input");
                    input_hidden.type = "date";
                    input_hidden.className = "form-control jsdtime";
                    input_hidden.name = "match_data[]";
                    input_hidden.value = getObj('tm_date').value;
                    //input_hidden.size = 10;
                    input_hidden.setAttribute("maxlength", 10);
                    cell7.appendChild(input_hidden);

                    var input_hidden = document.createElement("input");
                    input_hidden.type = "text";
                    input_hidden.className = "form-control jstime";
                    input_hidden.name = "match_time[]";
                    input_hidden.value = getObj('match_time_new').value;
                    //input_hidden.size = 5;
                    input_hidden.setAttribute("maxlength", 5);
                    cell8.appendChild(input_hidden);

                    var input_hidden = document.createElement("input");
                    input_hidden.type = "hidden";
                    input_hidden.name = "venue_id[]";
                    input_hidden.value = venue_id.value;
                    cell9.innerHTML = venue_id.selectedIndex != 0 ? venue_id.options[venue_id.selectedIndex].text : '';
                    cell9.appendChild(input_hidden);

                    ////------------/new---------------////

                    row.appendChild(cell1);
                    row.appendChild(cell2);
                    row.appendChild(cell3);
                    row.appendChild(cell4);
                    row.appendChild(cell5);
                    var row2 = tbl_elem.insertRow(tbl_elem.rows.length);

                    row2.className='jsmfirstTR';
                    row2.appendChild(cell7);
                    row2.appendChild(cell8);
                    row2.appendChild(cell9);
                    if ('<?php echo $lists['jsmr_mark_played'] ?>' == 1) {
                        jQuery("#match_played"+rand).val(jQuery("#tm_played").val());
                        jQuery("#match_played"+rand).select2({minimumResultsForSearch: 20});

                    }

                    getObj('teams1').value = 0;
                    getObj('teams2').value = 0;
                    getObj('add_score1').value = '';
                    getObj('add_score2').value = '';
                    getObj('venue_id_new').value = 0;
                    if ('<?php echo $lists['s_enbl_extra'] ?>' == '1') {
                        getObj('extra_timez').checked = false;
                    }
                    return false;
                }
//-->
</script>