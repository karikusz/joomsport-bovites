<?php
/*------------------------------------------------------------------------
# JoomSport Professional 
# ------------------------------------------------------------------------
# BearDev development company 
# Copyright (C) 2011 JoomSport.com. All Rights Reserved.
# @license - http://joomsport.com/news/license.html GNU/GPL
# Websites: http://www.JoomSport.com 
# Technical Support:  Forum - http://joomsport.com/helpdesk/
-------------------------------------------------------------------------*/
// no direct access
defined('_JEXEC') or die;


if(classJsportRequest::get('jsformat') == 'json' && classJsportRequest::get('sid') && is_file(JPATH_ROOT.'/media/bearleague/json/calendar_'.classJsportRequest::get('sid').'.json')){
    ob_clean();
    $str = file_get_contents(JPATH_ROOT.'/media/bearleague/json/calendar_'.classJsportRequest::get('sid').'.json');
    header('Content-type:application/json;charset=utf-8');
    echo $str;
    die();
}else{
    echo $this->slObject->execute();
}
